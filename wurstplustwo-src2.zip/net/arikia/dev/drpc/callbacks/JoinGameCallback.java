package net.arikia.dev.drpc.callbacks;

import com.sun.jna.*;

public interface JoinGameCallback extends Callback
{
    void apply(final String p0);
}
