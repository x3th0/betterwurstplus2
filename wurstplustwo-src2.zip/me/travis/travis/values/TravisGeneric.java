package me.travis.travis.values;

public class TravisGeneric<S>
{
    S value;
    
    public TravisGeneric(final S value) {
        this.value = value;
    }
    
    public void set_value(final S value) {
        this.value = value;
    }
    
    public S get_value() {
        return this.value;
    }
}
