package me.travis.travis.values;

public class TravisBoolean
{
    private String name;
    private String tag;
    private TravisGeneric<Boolean> value;
    
    public TravisBoolean(final String name, final String tag, final boolean travis_bool) {
        this.name = name;
        this.tag = tag;
        this.value = new TravisGeneric<Boolean>(travis_bool);
    }
    
    public void set_value(final boolean travis_bool) {
        this.value.set_value(travis_bool);
    }
    
    public String get_name() {
        return this.name;
    }
    
    public String get_tag() {
        return this.tag;
    }
    
    public boolean get_value() {
        return this.value.get_value();
    }
}
