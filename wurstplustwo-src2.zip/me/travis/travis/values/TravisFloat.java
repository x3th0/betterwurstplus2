package me.travis.travis.values;

public class TravisFloat
{
    private String name;
    private String tag;
    private float value;
    private float max;
    private float min;
    
    public TravisFloat(final String name, final String tag, final float travis_float, final float min, final float max) {
        this.name = name;
        this.tag = tag;
        this.value = this.value;
        this.max = max;
        this.min = min;
    }
    
    public void set_value(final float travis_float) {
        this.value = travis_float;
    }
    
    public void set_slider_value(final float travis_float) {
        if (travis_float >= this.max) {
            this.value = this.max;
        }
        else if (travis_float <= this.min) {
            this.value = this.min;
        }
        else {
            this.value = travis_float;
        }
    }
    
    public String get_name() {
        return this.name;
    }
    
    public String get_tag() {
        return this.tag;
    }
    
    public float get_value() {
        return this.value;
    }
}
