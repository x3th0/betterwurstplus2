package me.travis.travis.values;

public class TravisEnum
{
    Class<? extends Enum> value;
    
    public TravisEnum(final Class<? extends Enum> travis_enum) {
        this.value = travis_enum;
    }
}
