package me.travis.travis.values;

public class TravisInt
{
    private String name;
    private String tag;
    private int value;
    private int max;
    private int min;
    
    public TravisInt(final String name, final String tag, final int travis_int, final int min, final int max) {
        this.name = name;
        this.tag = tag;
        this.value = travis_int;
        this.max = max;
        this.min = min;
    }
    
    public void set_value(final int travis_int) {
        this.value = travis_int;
    }
    
    public void set_slider_value(final int travis_int) {
        if (travis_int >= this.max) {
            this.value = this.max;
        }
        else if (travis_int <= this.min) {
            this.value = this.min;
        }
        else {
            this.value = travis_int;
        }
    }
    
    public String get_name() {
        return this.name;
    }
    
    public String get_tag() {
        return this.tag;
    }
    
    public int get_value() {
        return this.value;
    }
}
