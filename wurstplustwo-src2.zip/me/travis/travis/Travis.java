package me.travis.travis;

import me.travis.travis.task.*;
import me.travis.travis.draw.*;

public class Travis
{
    private String tag;
    private TravisFont font_manager;
    
    public Travis(final String tag) {
        this.tag = tag;
    }
    
    public void resize(final int x, final int y, final float size) {
        TravisGL.resize(x, y, size);
    }
    
    public void resize(final int x, final int y, final float size, final String tag) {
        TravisGL.resize(x, y, size, "end");
    }
    
    public TravisFont get_font_manager() {
        return this.font_manager;
    }
}
