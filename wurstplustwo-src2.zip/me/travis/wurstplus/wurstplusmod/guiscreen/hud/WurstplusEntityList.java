package me.travis.wurstplus.wurstplusmod.guiscreen.hud;

import me.travis.wurstplus.wurstplusmod.guiscreen.render.pinnables.*;
import me.travis.wurstplus.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import java.util.function.*;
import java.util.stream.*;
import com.mojang.realmsclient.gui.*;
import java.util.*;
import javax.annotation.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.projectile.*;

public class WurstplusEntityList extends WurstplusPinnable
{
    public WurstplusEntityList() {
        super("Entity List", "EntityList", 1.0f, 0, 0);
    }
    
    @Override
    public void render() {
        int counter = 12;
        final int nl_r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
        final int nl_g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
        final int nl_b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);
        final int nl_a = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorA").get_value(1);
        final List<Entity> entity_list = new ArrayList<Entity>(this.mc.world.loadedEntityList);
        if (entity_list.size() <= 1) {
            return;
        }
        final Map<String, Integer> entity_counts = entity_list.stream().filter(Objects::nonNull).filter(e -> !(e instanceof EntityPlayer)).collect(Collectors.groupingBy((Function<? super Object, ? extends String>)WurstplusEntityList::get_entity_name, (Collector<? super Object, ?, Integer>)Collectors.reducing((D)0, ent -> {
            if (ent instanceof EntityItem) {
                return ent.getItem().getCount();
            }
            else {
                return 1;
            }
        }, Integer::sum)));
        for (final Map.Entry<String, Integer> entity : entity_counts.entrySet()) {
            final String e2 = entity.getKey() + " " + ChatFormatting.DARK_GRAY + "x" + entity.getValue();
            this.create_line(e2, this.docking(1, e2), 1 * counter, nl_r, nl_g, nl_b, nl_a);
            counter += 12;
        }
        this.set_width(this.get("aaaaaaaaaaaaaaa", "width") + 2);
        this.set_height(this.get("aaaaaaaaaaaaaaa", "height") * 5);
    }
    
    private static String get_entity_name(@Nonnull final Entity entity) {
        if (entity instanceof EntityItem) {
            return ((EntityItem)entity).getItem().getItem().getItemStackDisplayName(((EntityItem)entity).getItem());
        }
        if (entity instanceof EntityWitherSkull) {
            return "Wither skull";
        }
        if (entity instanceof EntityEnderCrystal) {
            return "End crystal";
        }
        if (entity instanceof EntityEnderPearl) {
            return "Thrown ender pearl";
        }
        if (entity instanceof EntityMinecart) {
            return "Minecart";
        }
        if (entity instanceof EntityItemFrame) {
            return "Item frame";
        }
        if (entity instanceof EntityEgg) {
            return "Thrown egg";
        }
        if (entity instanceof EntitySnowball) {
            return "Thrown snowball";
        }
        return entity.getName();
    }
}
