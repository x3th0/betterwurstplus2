package me.travis.wurstplus.wurstplusmod.guiscreen.hud;

import me.travis.wurstplus.wurstplusmod.guiscreen.render.pinnables.*;
import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.entity.*;
import java.util.*;

public class WurstplusFriendList extends WurstplusPinnable
{
    int passes;
    public static ChatFormatting bold;
    
    public WurstplusFriendList() {
        super("Friends", "Friends", 1.0f, 0, 0);
    }
    
    @Override
    public void render() {
        final int nl_r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
        final int nl_g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
        final int nl_b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);
        final int nl_a = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorA").get_value(1);
        final String line1 = WurstplusFriendList.bold + "the_fellas: ";
        this.passes = 0;
        this.create_line(line1, this.docking(1, line1), 2, nl_r, nl_g, nl_b, nl_a);
        if (!WurstplusOnlineFriends.getFriends().isEmpty()) {
            for (final Entity e : WurstplusOnlineFriends.getFriends()) {
                ++this.passes;
                this.create_line(e.getName(), this.docking(1, e.getName()), this.get(line1, "height") * this.passes, nl_r, nl_g, nl_b, nl_a);
            }
        }
        this.set_width(this.get(line1, "width") + 2);
        this.set_height(this.get(line1, "height") + 2);
    }
    
    static {
        WurstplusFriendList.bold = ChatFormatting.BOLD;
    }
}
