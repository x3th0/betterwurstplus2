package me.travis.wurstplus.wurstplusmod.guiscreen.hud;

import me.travis.wurstplus.wurstplusmod.guiscreen.render.pinnables.*;
import me.travis.wurstplus.*;
import net.minecraft.client.*;
import java.text.*;
import net.minecraft.util.math.*;

public class WurstplusSpeedometer extends WurstplusPinnable
{
    public WurstplusSpeedometer() {
        super("Speedometer", "Speedometer", 1.0f, 0, 0);
    }
    
    @Override
    public void render() {
        final int nl_r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
        final int nl_g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
        final int nl_b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);
        final int nl_a = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorA").get_value(1);
        final double x = Minecraft.getMinecraft().player.posX - Minecraft.getMinecraft().player.prevPosX;
        final double z = Minecraft.getMinecraft().player.posZ - Minecraft.getMinecraft().player.prevPosZ;
        final float tr = Minecraft.getMinecraft().timer.tickLength / 1000.0f;
        final String bps = "M/s: " + new DecimalFormat("#.#").format(MathHelper.sqrt(x * x + z * z) / tr);
        this.create_line(bps, this.docking(1, bps), 2, nl_r, nl_g, nl_b, nl_a);
        this.set_width(this.get(bps, "width") + 2);
        this.set_height(this.get(bps, "height") + 2);
    }
}
