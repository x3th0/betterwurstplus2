package me.travis.wurstplus.wurstplusmod.guiscreen.hud;

import me.travis.wurstplus.wurstplusmod.guiscreen.render.pinnables.*;
import me.travis.wurstplus.*;

public class WurstplusPing extends WurstplusPinnable
{
    public WurstplusPing() {
        super("Ping", "Ping", 1.0f, 0, 0);
    }
    
    @Override
    public void render() {
        final int nl_r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
        final int nl_g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
        final int nl_b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);
        final int nl_a = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorA").get_value(1);
        final String line = "Ping: " + this.get_ping();
        this.create_line(line, this.docking(1, line), 2, nl_r, nl_g, nl_b, nl_a);
        this.set_width(this.get(line, "width") + 2);
        this.set_height(this.get(line, "height") + 2);
    }
    
    public String get_ping() {
        try {
            final int ping = this.mc.getConnection().getPlayerInfo(this.mc.player.getUniqueID()).getResponseTime();
            if (ping <= 50) {
                return "�a" + Integer.toString(ping);
            }
            if (ping <= 150) {
                return "�3" + Integer.toString(ping);
            }
            return "�4" + Integer.toString(ping);
        }
        catch (Exception e) {
            return "oh no";
        }
    }
}
