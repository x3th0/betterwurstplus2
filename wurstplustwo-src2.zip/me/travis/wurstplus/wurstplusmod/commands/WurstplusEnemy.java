package me.travis.wurstplus.wurstplusmod.commands;

import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import java.util.*;

public class WurstplusEnemy extends WurstplusCommand
{
    public static ChatFormatting red;
    public static ChatFormatting green;
    public static ChatFormatting bold;
    public static ChatFormatting reset;
    
    public WurstplusEnemy() {
        super("enemy", "To add enemy");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        if (message.length == 1) {
            WurstplusMessage.send_client_message("Add - add enemy");
            WurstplusMessage.send_client_message("Del - delete enemy");
            WurstplusMessage.send_client_message("List - list enemies");
            return true;
        }
        if (message.length != 2) {
            if (message.length >= 3) {
                if (message[1].equalsIgnoreCase("add")) {
                    if (WurstplusEnemyManager.isEnemy(message[2])) {
                        WurstplusMessage.send_client_message("Player " + WurstplusEnemy.green + WurstplusEnemy.bold + message[2] + WurstplusEnemy.reset + " is already your Enemy D:");
                        return true;
                    }
                    final WurstplusEnemyManager.Enemy f = WurstplusEnemyManager.get_enemy_object(message[2]);
                    if (f == null) {
                        WurstplusMessage.send_client_error_message("Cannot find " + WurstplusEnemy.red + WurstplusEnemy.bold + "UUID" + WurstplusEnemy.reset + " for that player :(");
                        return true;
                    }
                    WurstplusEnemyManager.enemies.add(f);
                    WurstplusMessage.send_client_message("Player " + WurstplusEnemy.green + WurstplusEnemy.bold + message[2] + WurstplusEnemy.reset + " is now your Enemy D:");
                    return true;
                }
                else if (message[1].equalsIgnoreCase("del") || message[1].equalsIgnoreCase("remove") || message[1].equalsIgnoreCase("delete")) {
                    if (!WurstplusEnemyManager.isEnemy(message[2])) {
                        WurstplusMessage.send_client_message("Player " + WurstplusEnemy.red + WurstplusEnemy.bold + message[2] + WurstplusEnemy.reset + " is already not your Enemy :/");
                        return true;
                    }
                    final WurstplusEnemyManager.Enemy f = WurstplusEnemyManager.enemies.stream().filter(Enemy -> Enemy.getUsername().equalsIgnoreCase(message[2])).findFirst().get();
                    WurstplusEnemyManager.enemies.remove(f);
                    WurstplusMessage.send_client_message("Player " + WurstplusEnemy.red + WurstplusEnemy.bold + message[2] + WurstplusEnemy.reset + " is now not your Enemy :)");
                    return true;
                }
            }
            return true;
        }
        if (message[1].equalsIgnoreCase("list")) {
            if (WurstplusEnemyManager.enemies.isEmpty()) {
                WurstplusMessage.send_client_message("You appear to have " + WurstplusEnemy.red + WurstplusEnemy.bold + "no" + WurstplusEnemy.reset + " enemies :)");
            }
            else {
                for (final WurstplusEnemyManager.Enemy Enemy2 : WurstplusEnemyManager.enemies) {
                    WurstplusMessage.send_client_message("" + WurstplusEnemy.green + WurstplusEnemy.bold + Enemy2.getUsername());
                }
            }
            return true;
        }
        if (WurstplusEnemyManager.isEnemy(message[1])) {
            WurstplusMessage.send_client_message("Player " + WurstplusEnemy.green + WurstplusEnemy.bold + message[1] + WurstplusEnemy.reset + " is your Enemy D:");
            return true;
        }
        WurstplusMessage.send_client_error_message("Player " + WurstplusEnemy.red + WurstplusEnemy.bold + message[1] + WurstplusEnemy.reset + " is not your Enemy :)");
        return true;
    }
    
    static {
        WurstplusEnemy.red = ChatFormatting.GREEN;
        WurstplusEnemy.green = ChatFormatting.RED;
        WurstplusEnemy.bold = ChatFormatting.BOLD;
        WurstplusEnemy.reset = ChatFormatting.RESET;
    }
}
