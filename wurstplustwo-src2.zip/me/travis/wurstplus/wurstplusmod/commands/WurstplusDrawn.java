package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.manager.*;
import me.travis.wurstplus.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.util.*;

public class WurstplusDrawn extends WurstplusCommand
{
    public WurstplusDrawn() {
        super("drawn", "Hide elements of the array list");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        if (message.length == 1) {
            WurstplusMessage.send_client_error_message("module name needed");
            return true;
        }
        if (message.length != 2) {
            return false;
        }
        if (this.is_module(message[1])) {
            WurstplusDrawnManager.add_remove_item(message[1]);
            return true;
        }
        WurstplusMessage.send_client_error_message("cannot find module by name: " + message[1]);
        return true;
    }
    
    public boolean is_module(final String s) {
        final List<WurstplusModule> modules = Wurstplus.get_module_manager().get_array_modules();
        for (final WurstplusModule module : modules) {
            if (module.get_tag().equalsIgnoreCase(s)) {
                return true;
            }
        }
        return false;
    }
}
