package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.*;
import java.util.*;

public class WurstplusHelp extends WurstplusCommand
{
    public WurstplusHelp() {
        super("help", "A help util.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String type = "null";
        if (message.length > 1) {
            type = message[1];
        }
        if (message.length > 2) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "help <List/NameCommand>");
            return true;
        }
        if (type.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "help <List/NameCommand>");
            return true;
        }
        if (type.equalsIgnoreCase("list")) {
            int commands_length = 0;
            for (final WurstplusCommand commands : WurstplusListCommand.get_pure_command_list()) {
                WurstplusMessage.send_client_message(commands.get_name());
                ++commands_length;
            }
            return true;
        }
        final WurstplusCommand command_requested = WurstplusListCommand.get_command_with_name(type);
        if (command_requested == null) {
            WurstplusMessage.send_client_error_message("This command does not exist.");
            return true;
        }
        WurstplusMessage.send_client_message(command_requested.get_name() + " - " + command_requested.get_description());
        return true;
    }
}
