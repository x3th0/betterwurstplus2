package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.manager.*;
import me.travis.wurstplus.*;
import me.travis.wurstplus.wurstplusmod.*;

public class WurstplusToggle extends WurstplusCommand
{
    public WurstplusToggle() {
        super("t", "For toggle module.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String module = "null";
        if (message.length > 1) {
            module = message[1];
        }
        if (message.length > 2) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "t <ModuleNameNoSpace>");
            return true;
        }
        if (module.equals("null")) {
            WurstplusMessage.send_client_error_message(WurstplusCommandManager.get_prefix() + "t <ModuleNameNoSpace>");
            return true;
        }
        final WurstplusModule module_requested = Wurstplus.module_manager.get_module_with_tag(module);
        if (module_requested != null) {
            module_requested.toggle();
            WurstplusMessage.send_client_message("[" + module_requested.get_tag() + "] - Toggled to " + module_requested.is_active() + ".");
        }
        else {
            WurstplusMessage.send_client_error_message("Module does not exist.");
        }
        return true;
    }
}
