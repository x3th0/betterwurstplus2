package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.*;
import me.travis.wurstplus.wurstplusmod.*;

public class WurstplusToggleMessage extends WurstplusCommand
{
    public WurstplusToggleMessage() {
        super("alert", "For set alert if a module does active.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String module = "null";
        String state = "null";
        if (message.length > 1) {
            module = message[1];
        }
        if (message.length > 2) {
            state = message[2];
        }
        if (message.length > 3) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "t <ModuleName> <True/On/False/Off>");
            return true;
        }
        if (module.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "t <ModuleName> <True/On/False/Off>");
            return true;
        }
        if (state.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "t <ModuleName> <True/On/False/Off>");
            return true;
        }
        module = module.toLowerCase();
        state = state.toLowerCase();
        final WurstplusModule module_requested = Wurstplus.get_module_manager().get_module_with_tag(module);
        if (module_requested == null) {
            WurstplusMessage.send_client_error_message("This module does not exist.");
            return true;
        }
        boolean value = true;
        if (state.equals("true") || state.equals("on")) {
            value = true;
        }
        else {
            if (!state.equals("false") && !state.equals("off")) {
                WurstplusMessage.send_client_error_message("This value does not exist. <True/On/False/Off>");
                return true;
            }
            value = false;
        }
        module_requested.set_if_can_send_message_toggle(value);
        WurstplusMessage.send_client_message("The actual value of " + module_requested.get_name() + " is " + Boolean.toString(module_requested.can_send_message_when_toggle()) + ".");
        return true;
    }
}
