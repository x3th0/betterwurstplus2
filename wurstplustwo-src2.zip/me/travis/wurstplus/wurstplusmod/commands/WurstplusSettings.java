package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.*;
import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.*;

public class WurstplusSettings extends WurstplusCommand
{
    public WurstplusSettings() {
        super("settings", "To save/load settings.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String what = "null";
        if (message.length > 1) {
            what = message[1];
        }
        if (what.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "settings <save/load>");
            return true;
        }
        final ChatFormatting c = ChatFormatting.GRAY;
        if (what.equalsIgnoreCase("save")) {
            Wurstplus.get_config_manager().save_values();
            Wurstplus.get_config_manager().save_binds();
            Wurstplus.get_config_manager().save_client();
            WurstplusMessage.send_client_message(ChatFormatting.GREEN + "Successfully " + c + "saved!");
        }
        else {
            if (!what.equalsIgnoreCase("load")) {
                WurstplusMessage.send_client_error_message(this.current_prefix() + "settings <save/load>");
                return true;
            }
            Wurstplus.get_config_manager().load();
            WurstplusMessage.send_client_message(ChatFormatting.GREEN + "Successfully " + c + "loaded!");
        }
        return true;
    }
}
