package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import com.mojang.realmsclient.gui.*;

public class WurstplusEzMessage extends WurstplusCommand
{
    public WurstplusEzMessage() {
        super("ezmessage", "Set ez mode");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        if (message.length == 1) {
            WurstplusMessage.send_client_error_message("message needed");
            return true;
        }
        if (message.length >= 2) {
            final StringBuilder ez = new StringBuilder();
            boolean flag = true;
            for (final String word : message) {
                if (flag) {
                    flag = false;
                }
                else {
                    ez.append(word).append(" ");
                }
            }
            WurstplusEzMessageManager.message = ez.toString();
            WurstplusMessage.send_client_message("ez message changed to " + ChatFormatting.BOLD + ez.toString());
            return true;
        }
        return false;
    }
}
