package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.*;
import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;

public class WurstplusLabel extends WurstplusCommand
{
    public WurstplusLabel() {
        super("label", "For change a custom label widget from a module.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String module = "null";
        String label = "null";
        String change_1 = "null";
        String change_2 = "null";
        int syntax = 3;
        boolean is_to_suffix = false;
        if (message.length > 1) {
            module = message[1];
        }
        if (message.length > 2) {
            label = message[2];
        }
        if (message.length > 3) {
            change_1 = message[3];
            ++syntax;
        }
        if (message.length > 4) {
            change_2 = message[4];
            ++syntax;
        }
        if (message.length > syntax) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "label <ModuleName> <ModuleNameLabel> <change1> <change2>");
            return true;
        }
        if (module.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "label <ModuleName> <ModuleNameLabel> <change1> <change2>");
            return true;
        }
        if (label.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "label <ModuleName> <ModuleNameLabel> <change1> <change2>");
            return true;
        }
        if (change_1.equals("null") && change_2.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "label <ModuleName> <ModuleNameLabel> <change1> <change2>");
            return true;
        }
        if (change_2.equals("null")) {
            change_2 = "";
        }
        module = module.toLowerCase();
        final WurstplusModule module_requested = Wurstplus.get_module_manager().get_module_with_tag(module);
        if (module == null) {
            WurstplusMessage.send_client_error_message("This module does not exist.");
            return true;
        }
        if (module_requested.get_tag().equalsIgnoreCase("WurstplusChatSuffix")) {
            is_to_suffix = true;
        }
        label = module_requested.get_tag().toLowerCase() + label.toLowerCase();
        final WurstplusSetting setting_requested = Wurstplus.get_setting_manager().get_setting_with_tag(module, label);
        if (setting_requested == null) {
            WurstplusMessage.send_client_error_message("This label does not exist.");
            return true;
        }
        if (setting_requested.is_info()) {
            WurstplusMessage.send_client_error_message("You can't change a info.");
            return true;
        }
        String new_value = (syntax == 4) ? change_1 : (change_1 + " " + change_2);
        if (is_to_suffix) {
            if (change_1.length() >= 16) {
                change_1.substring(0, 16);
            }
            new_value = change_1.toLowerCase();
        }
        setting_requested.set_value(new_value);
        WurstplusMessage.send_client_message("The label " + setting_requested.get_name() + " is now " + setting_requested.get_value("") + ".");
        return true;
    }
}
