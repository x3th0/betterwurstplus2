package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.travis.values.*;
import net.minecraft.util.text.*;
import java.util.*;
import java.util.function.*;

public class WurstplusListCommand
{
    public static ArrayList<WurstplusCommand> command_list;
    static HashMap<String, WurstplusCommand> list_command;
    public static final TravisString prefix;
    public final Style style;
    
    public WurstplusListCommand(final Style style_) {
        this.style = style_;
        add_command(new WurstplusBind());
        add_command(new WurstplusLabel());
        add_command(new WurstplusPrefix());
        add_command(new WurstplusSettings());
        add_command(new WurstplusToggle());
        add_command(new WurstplusToggleMessage());
        add_command(new WurstplusHelp());
        add_command(new WurstplusFriend());
        add_command(new WurstplusDrawn());
        add_command(new WurstplusEzMessage());
        add_command(new WurstplusEnemy());
        WurstplusListCommand.command_list.sort(Comparator.comparing((Function<? super WurstplusCommand, ? extends Comparable>)WurstplusCommand::get_name));
    }
    
    public static void add_command(final WurstplusCommand command) {
        WurstplusListCommand.command_list.add(command);
        WurstplusListCommand.list_command.put(command.get_name().toLowerCase(), command);
    }
    
    public String[] get_message(final String message) {
        String[] arguments = new String[0];
        if (this.has_prefix(message)) {
            arguments = message.replaceFirst(WurstplusListCommand.prefix.get_value(), "").split(" ");
        }
        return arguments;
    }
    
    public boolean has_prefix(final String message) {
        return message.startsWith(WurstplusListCommand.prefix.get_value());
    }
    
    public void set_prefix(final String new_prefix) {
        WurstplusListCommand.prefix.set_value(new_prefix);
    }
    
    public String get_prefix() {
        return WurstplusListCommand.prefix.get_value();
    }
    
    public static ArrayList<WurstplusCommand> get_pure_command_list() {
        return WurstplusListCommand.command_list;
    }
    
    public static WurstplusCommand get_command_with_name(final String name) {
        return WurstplusListCommand.list_command.get(name.toLowerCase());
    }
    
    static {
        WurstplusListCommand.command_list = new ArrayList<WurstplusCommand>();
        WurstplusListCommand.list_command = new HashMap<String, WurstplusCommand>();
        prefix = new TravisString("Prefix", "Prefix", ".");
    }
}
