package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.*;
import org.lwjgl.input.*;
import me.travis.wurstplus.wurstplusmod.*;

public class WurstplusBind extends WurstplusCommand
{
    public WurstplusBind() {
        super("bind", "To bind module.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String module = "null;";
        String key = "null";
        if (message.length > 1) {
            module = message[1];
        }
        if (message.length > 2) {
            key = message[2].toUpperCase();
        }
        if (message.length > 3) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "bind <ModuleNameNoSpace> <key>");
            return true;
        }
        if (module.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "bind <ModuleNameNoSpace> <key>");
            return true;
        }
        if (key.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "bind <ModuleNameNoSpace> <key>");
            return true;
        }
        module = module.toUpperCase();
        final WurstplusModule module_requested = Wurstplus.get_module_manager().get_module_with_tag(module);
        if (module_requested == null) {
            WurstplusMessage.send_client_error_message("Module does not exist.");
            return true;
        }
        if (key.equalsIgnoreCase("NONE")) {
            module_requested.set_bind(0);
            WurstplusMessage.send_client_message(module_requested.get_tag() + " is bound to None.");
            return true;
        }
        final int new_bind = Keyboard.getKeyIndex(key.toUpperCase());
        if (new_bind == 0) {
            WurstplusMessage.send_client_error_message("Key does not exist.");
            return true;
        }
        if (new_bind == module_requested.get_bind(0)) {
            WurstplusMessage.send_client_error_message("The " + module_requested.get_tag() + " already have it key.");
            return true;
        }
        module_requested.set_bind(new_bind);
        WurstplusMessage.send_client_message(module_requested.get_tag() + " is bound to " + module_requested.get_bind(""));
        return true;
    }
}
