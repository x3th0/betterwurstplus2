package me.travis.wurstplus.wurstplusmod.commands;

import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import java.util.*;

public class WurstplusFriend extends WurstplusCommand
{
    public static ChatFormatting red;
    public static ChatFormatting green;
    public static ChatFormatting bold;
    public static ChatFormatting reset;
    
    public WurstplusFriend() {
        super("friend", "To add friends");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        if (message.length == 1) {
            WurstplusMessage.send_client_message("Add - add friend");
            WurstplusMessage.send_client_message("Del - delete friend");
            WurstplusMessage.send_client_message("List - list friends");
            return true;
        }
        if (message.length != 2) {
            if (message.length >= 3) {
                if (message[1].equalsIgnoreCase("add")) {
                    if (WurstplusFriendManager.isFriend(message[2])) {
                        WurstplusMessage.send_client_message("Player " + WurstplusFriend.green + WurstplusFriend.bold + message[2] + WurstplusFriend.reset + " is already your friend :D");
                        return true;
                    }
                    final WurstplusFriendManager.Friend f = WurstplusFriendManager.get_friend_object(message[2]);
                    if (f == null) {
                        WurstplusMessage.send_client_error_message("Cannot find " + WurstplusFriend.red + WurstplusFriend.bold + "UUID" + WurstplusFriend.reset + " for that player :(");
                        return true;
                    }
                    WurstplusFriendManager.friends.add(f);
                    WurstplusMessage.send_client_message("Player " + WurstplusFriend.green + WurstplusFriend.bold + message[2] + WurstplusFriend.reset + " is now your friend :D");
                    return true;
                }
                else if (message[1].equalsIgnoreCase("del") || message[1].equalsIgnoreCase("remove") || message[1].equalsIgnoreCase("delete")) {
                    if (!WurstplusFriendManager.isFriend(message[2])) {
                        WurstplusMessage.send_client_message("Player " + WurstplusFriend.red + WurstplusFriend.bold + message[2] + WurstplusFriend.reset + " is already not your friend :/");
                        return true;
                    }
                    final WurstplusFriendManager.Friend f = WurstplusFriendManager.friends.stream().filter(friend -> friend.getUsername().equalsIgnoreCase(message[2])).findFirst().get();
                    WurstplusFriendManager.friends.remove(f);
                    WurstplusMessage.send_client_message("Player " + WurstplusFriend.red + WurstplusFriend.bold + message[2] + WurstplusFriend.reset + " is now not your friend :(");
                    return true;
                }
            }
            return true;
        }
        if (message[1].equalsIgnoreCase("list")) {
            if (WurstplusFriendManager.friends.isEmpty()) {
                WurstplusMessage.send_client_message("You appear to have " + WurstplusFriend.red + WurstplusFriend.bold + "no" + WurstplusFriend.reset + " friends :(");
            }
            else {
                for (final WurstplusFriendManager.Friend friend2 : WurstplusFriendManager.friends) {
                    WurstplusMessage.send_client_message("" + WurstplusFriend.green + WurstplusFriend.bold + friend2.getUsername());
                }
            }
            return true;
        }
        if (WurstplusFriendManager.isFriend(message[1])) {
            WurstplusMessage.send_client_message("Player " + WurstplusFriend.green + WurstplusFriend.bold + message[1] + WurstplusFriend.reset + " is your friend :D");
            return true;
        }
        WurstplusMessage.send_client_error_message("Player " + WurstplusFriend.red + WurstplusFriend.bold + message[1] + WurstplusFriend.reset + " is not your friend :(");
        return true;
    }
    
    static {
        WurstplusFriend.red = ChatFormatting.RED;
        WurstplusFriend.green = ChatFormatting.GREEN;
        WurstplusFriend.bold = ChatFormatting.BOLD;
        WurstplusFriend.reset = ChatFormatting.RESET;
    }
}
