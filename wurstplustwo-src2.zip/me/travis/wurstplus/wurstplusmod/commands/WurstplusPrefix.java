package me.travis.wurstplus.wurstplusmod.commands;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.manager.*;

public class WurstplusPrefix extends WurstplusCommand
{
    public WurstplusPrefix() {
        super("prefix", "Change prefix.");
    }
    
    @Override
    public boolean get_message(final String[] message) {
        String prefix = "null";
        if (message.length > 1) {
            prefix = message[1];
        }
        if (message.length > 2) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "prefix <character>");
            return true;
        }
        if (prefix.equals("null")) {
            WurstplusMessage.send_client_error_message(this.current_prefix() + "prefix <character>");
            return true;
        }
        WurstplusCommandManager.set_prefix(prefix);
        WurstplusMessage.send_client_message("The new prefix is " + prefix);
        return true;
    }
}
