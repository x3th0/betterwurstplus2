package me.travis.wurstplus.wurstplusmod;

import net.minecraft.client.*;
import com.mojang.realmsclient.gui.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.util.text.event.*;
import me.travis.wurstplus.*;
import net.minecraft.util.text.*;
import java.util.regex.*;

public class WurstplusMessage
{
    public static Minecraft mc;
    public static ChatFormatting g;
    public static ChatFormatting b;
    public static ChatFormatting a;
    public static ChatFormatting r;
    public static String opener;
    
    public static void toggle_message(final WurstplusModule module) {
        if (module.is_active()) {
            if (module.get_tag().equals("AutoCrystal")) {
                client_message(WurstplusMessage.opener + "we" + ChatFormatting.DARK_GREEN + " gaming ");
            }
            else {
                client_message(WurstplusMessage.opener + WurstplusMessage.r + module.get_name() + ChatFormatting.DARK_GREEN + " Enabled");
            }
        }
        else if (module.get_tag().equals("AutoCrystal")) {
            client_message(WurstplusMessage.opener + "we aint" + ChatFormatting.RED + " gaming " + WurstplusMessage.r + "no more");
        }
        else {
            client_message(WurstplusMessage.opener + WurstplusMessage.r + module.get_name() + ChatFormatting.RED + " Disabled");
        }
    }
    
    public static void user_send_message(final String message) {
        if (WurstplusMessage.mc.player != null) {
            WurstplusMessage.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(message));
        }
    }
    
    public static void client_message(final String message) {
        if (WurstplusMessage.mc.player != null) {
            final ITextComponent itc = new TextComponentString(message).setStyle(new Style().setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, (ITextComponent)new TextComponentString("frank alachi"))));
            WurstplusMessage.mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(itc, 5936);
        }
    }
    
    public static void send_client_message(final String message) {
        client_message(ChatFormatting.GOLD + "Wurst+ 2" + ChatFormatting.GRAY + " > " + WurstplusMessage.r + message);
        Wurstplus.send_client_log(" > " + message);
    }
    
    public static void send_client_error_message(final String message) {
        client_message(ChatFormatting.RED + "Wurst+ 2" + ChatFormatting.GRAY + " < " + WurstplusMessage.r + message);
        Wurstplus.send_client_log(" < " + message);
    }
    
    static {
        WurstplusMessage.mc = Minecraft.getMinecraft();
        WurstplusMessage.g = ChatFormatting.GOLD;
        WurstplusMessage.b = ChatFormatting.BLUE;
        WurstplusMessage.a = ChatFormatting.DARK_AQUA;
        WurstplusMessage.r = ChatFormatting.RESET;
        WurstplusMessage.opener = WurstplusMessage.g + "Wurst+ 2" + ChatFormatting.GRAY + " > " + WurstplusMessage.r;
    }
    
    public static class ChatMessage extends TextComponentBase
    {
        String message_input;
        
        public ChatMessage(final String message) {
            final Pattern p = Pattern.compile("&[0123456789abcdefrlosmk]");
            final Matcher m = p.matcher(message);
            final StringBuffer sb = new StringBuffer();
            while (m.find()) {
                final String replacement = "�" + m.group().substring(1);
                m.appendReplacement(sb, replacement);
            }
            m.appendTail(sb);
            this.message_input = sb.toString();
        }
        
        public String getUnformattedComponentText() {
            return this.message_input;
        }
        
        public ITextComponent createCopy() {
            return (ITextComponent)new ChatMessage(this.message_input);
        }
    }
}
