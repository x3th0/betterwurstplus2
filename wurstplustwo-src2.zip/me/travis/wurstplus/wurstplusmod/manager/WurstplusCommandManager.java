package me.travis.wurstplus.wurstplusmod.manager;

import me.travis.wurstplus.wurstplusmod.commands.*;
import net.minecraft.util.text.*;

public class WurstplusCommandManager
{
    private String tag;
    public static WurstplusListCommand command_list;
    
    public WurstplusCommandManager(final String tag) {
        this.tag = tag;
        WurstplusCommandManager.command_list = new WurstplusListCommand(new Style().setColor(TextFormatting.BLUE));
    }
    
    public void init_commands() {
    }
    
    public static void set_prefix(final String new_prefix) {
        WurstplusCommandManager.command_list.set_prefix(new_prefix);
    }
    
    public static String get_prefix() {
        return WurstplusCommandManager.command_list.get_prefix();
    }
    
    public String get_tag() {
        return this.tag;
    }
}
