package me.travis.wurstplus.wurstplusmod.manager;

import me.travis.wurstplus.wurstplusmod.guiscreen.render.pinnables.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.hud.*;
import java.util.function.*;
import java.util.*;

public class WurstplusHUDManager
{
    private final String tag;
    public static ArrayList<WurstplusPinnable> array_hud;
    
    public WurstplusHUDManager(final String tag) {
        this.tag = tag;
        this.add_component_pinnable(new WurstplusWatermark());
        this.add_component_pinnable(new WurstplusArrayList());
        this.add_component_pinnable(new WurstplusCoordinates());
        this.add_component_pinnable(new WurstplusInventoryPreview());
        this.add_component_pinnable(new WurstplusInventoryXCarryPreview());
        this.add_component_pinnable(new WurstplusArmorPreview());
        this.add_component_pinnable(new WurstplusUser());
        this.add_component_pinnable(new WurstplusTotemCount());
        this.add_component_pinnable(new WurstplusCrystalCount());
        this.add_component_pinnable(new WurstplusEXPCount());
        this.add_component_pinnable(new WurstplusGappleCount());
        this.add_component_pinnable(new WurstplusTime());
        this.add_component_pinnable(new WurstplusLogo());
        this.add_component_pinnable(new WurstplusFPS());
        this.add_component_pinnable(new WurstplusPing());
        this.add_component_pinnable(new WurstplusSurroundBlocks());
        this.add_component_pinnable(new WurstplusFriendList());
        this.add_component_pinnable(new WurstplusArmorDurabilityWarner());
        this.add_component_pinnable(new WurstplusPvpHud());
        this.add_component_pinnable(new WurstplusCompass());
        this.add_component_pinnable(new WurstplusEffectHud());
        this.add_component_pinnable(new WurstplusSpeedometer());
        this.add_component_pinnable(new WurstplusEntityList());
        this.add_component_pinnable(new WurstplusTPS());
        this.add_component_pinnable(new WurstplusPlayerList());
        this.add_component_pinnable(new WurstplusDirection());
        WurstplusHUDManager.array_hud.sort(Comparator.comparing((Function<? super WurstplusPinnable, ? extends Comparable>)WurstplusPinnable::get_title));
    }
    
    public void add_component_pinnable(final WurstplusPinnable module) {
        WurstplusHUDManager.array_hud.add(module);
    }
    
    public ArrayList<WurstplusPinnable> get_array_huds() {
        return WurstplusHUDManager.array_hud;
    }
    
    public void render() {
        for (final WurstplusPinnable pinnables : this.get_array_huds()) {
            if (pinnables.is_active()) {
                pinnables.render();
            }
        }
    }
    
    public WurstplusPinnable get_pinnable_with_tag(final String tag) {
        WurstplusPinnable pinnable_requested = null;
        for (final WurstplusPinnable pinnables : this.get_array_huds()) {
            if (pinnables.get_tag().equalsIgnoreCase(tag)) {
                pinnable_requested = pinnables;
            }
        }
        return pinnable_requested;
    }
    
    public String get_tag() {
        return this.tag;
    }
    
    static {
        WurstplusHUDManager.array_hud = new ArrayList<WurstplusPinnable>();
    }
}
