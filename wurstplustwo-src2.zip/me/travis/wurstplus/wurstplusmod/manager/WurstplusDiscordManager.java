package me.travis.wurstplus.wurstplusmod.manager;

import net.minecraft.client.*;
import net.minecraft.client.multiplayer.*;
import me.travis.wurstplus.*;
import net.arikia.dev.drpc.*;

public class WurstplusDiscordManager
{
    public static Minecraft mc;
    public static String details;
    public static String state;
    public static int players;
    public static int maxPlayers;
    public static int players2;
    public static int maxPlayers2;
    public static ServerData svr;
    public static String[] popInfo;
    
    public WurstplusDiscordManager Get() {
        return Wurstplus.discord_manager;
    }
    
    public static void start() {
        final String applicationId = "705741263470723093";
        final String steamId = "";
        final DiscordRichPresence presence = new DiscordRichPresence();
        final DiscordEventHandlers handlers = new DiscordEventHandlers();
        DiscordRPC.discordInitialize(applicationId, handlers, true, steamId);
        DiscordRPC.discordUpdatePresence(presence);
        presence.startTimestamp = System.currentTimeMillis() / 1000L;
        presence.details = "Vibin' RN. NR";
        presence.state = "Wurstplus Two";
        presence.largeImageKey = "large";
        final DiscordRichPresence presence2;
        new Thread(() -> {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    WurstplusDiscordManager.details = "";
                    WurstplusDiscordManager.state = "";
                    WurstplusDiscordManager.players = 0;
                    WurstplusDiscordManager.maxPlayers = 0;
                    if (WurstplusDiscordManager.mc.isIntegratedServerRunning()) {
                        WurstplusDiscordManager.details = "on his tod";
                    }
                    else if (WurstplusDiscordManager.mc.getCurrentServerData() != null) {
                        WurstplusDiscordManager.svr = WurstplusDiscordManager.mc.getCurrentServerData();
                        if (!WurstplusDiscordManager.svr.serverIP.equals("")) {
                            WurstplusDiscordManager.details = "with the fellas";
                            WurstplusDiscordManager.state = WurstplusDiscordManager.svr.serverIP;
                            if (WurstplusDiscordManager.svr.populationInfo != null) {
                                WurstplusDiscordManager.popInfo = WurstplusDiscordManager.svr.populationInfo.split("/");
                                if (WurstplusDiscordManager.popInfo.length > 2) {
                                    WurstplusDiscordManager.players2 = Integer.parseInt(WurstplusDiscordManager.popInfo[0]);
                                    WurstplusDiscordManager.maxPlayers2 = Integer.parseInt(WurstplusDiscordManager.popInfo[1]);
                                }
                            }
                        }
                    }
                    else {
                        WurstplusDiscordManager.details = "Vibin' RN. NR";
                        WurstplusDiscordManager.state = "Listening to mr. worldwide";
                    }
                    if (!WurstplusDiscordManager.details.equals(presence2.details) || !WurstplusDiscordManager.state.equals(presence2.state)) {
                        presence2.startTimestamp = System.currentTimeMillis() / 1000L;
                    }
                    presence2.details = WurstplusDiscordManager.details;
                    presence2.state = WurstplusDiscordManager.state;
                    DiscordRPC.discordUpdatePresence(presence2);
                }
                catch (Exception e2) {
                    e2.printStackTrace();
                }
                try {
                    Thread.sleep(5000L);
                }
                catch (InterruptedException e3) {
                    e3.printStackTrace();
                }
            }
        }, "RPC-Callback-Handler").start();
    }
    
    static {
        WurstplusDiscordManager.mc = Minecraft.getMinecraft();
    }
}
