package me.travis.wurstplus.wurstplusmod.manager;

public class WurstplusEzMessageManager
{
    private String tag;
    public static String message;
    
    public WurstplusEzMessageManager(final String tag) {
        this.tag = tag;
    }
    
    public void set_message(final String message) {
        WurstplusEzMessageManager.message = message;
    }
}
