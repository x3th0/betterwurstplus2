package me.travis.wurstplus.wurstplusmod.manager;

import me.travis.wurstplus.wurstplusmod.*;
import java.util.*;

public class WurstplusDrawnManager
{
    private String tag;
    public static List<String> hidden_tags;
    
    public WurstplusDrawnManager(final String tag) {
        this.tag = tag;
    }
    
    public static void add_remove_item(String s) {
        s = s.toLowerCase();
        if (WurstplusDrawnManager.hidden_tags.contains(s)) {
            WurstplusMessage.send_client_message("Added " + s);
            WurstplusDrawnManager.hidden_tags.remove(s);
        }
        else {
            WurstplusMessage.send_client_message("Removed " + s);
            WurstplusDrawnManager.hidden_tags.add(s);
        }
    }
    
    static {
        WurstplusDrawnManager.hidden_tags = new ArrayList<String>();
    }
}
