package me.travis.wurstplus.wurstplusmod.manager;

import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.client.*;
import me.travis.wurstplus.wurstplusmod.hacks.chat.*;
import me.travis.wurstplus.wurstplusmod.hacks.combat.*;
import me.travis.wurstplus.wurstplusmod.hacks.movement.*;
import me.travis.wurstplus.wurstplusmod.hacks.render.*;
import me.travis.wurstplus.wurstplusmod.hacks.misc.*;
import me.travis.wurstplus.wurstplusmod.hacks.exploit.*;
import me.travis.wurstplus.wurstplusmod.hacks.dev.*;
import java.util.function.*;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraftforge.client.event.*;
import me.travis.travis.draw.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import net.minecraft.client.renderer.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusModuleManager
{
    private String tag;
    public static ArrayList<WurstplusModule> array_module;
    public static Minecraft mc;
    
    public WurstplusModuleManager(final String tag) {
        this.tag = tag;
        this.add_module(new WurstplusClickGUI());
        this.add_module(new WurstplusClickHUD());
        this.add_module(new WurstplusChatSuffix());
        this.add_module(new WurstplusVisualRange());
        this.add_module(new WurstplusTotempop());
        this.add_module(new WurstplusClearChat());
        this.add_module(new WurstplusChatMods());
        this.add_module(new WurstplusAutoEz());
        this.add_module(new WurstplusAntiRacist());
        this.add_module(new WurstplusAnnouncer());
        this.add_module(new WurstplusCriticals());
        this.add_module(new WurstplusKillAura());
        this.add_module(new WurstplusSurround());
        this.add_module(new WurstplusVelocity());
        this.add_module(new WurstplusAutoCrystal());
        this.add_module(new WurstplusHoleFill());
        this.add_module(new WurstplusTrap());
        this.add_module(new WurstplusSocks());
        this.add_module(new WurstplusSelfTrap());
        this.add_module(new WurstplusAutoArmour());
        this.add_module(new WurstplusAuto32k());
        this.add_module(new WurstplusWebfill());
        this.add_module(new WurstplusAutoWeb());
        this.add_module(new WurstplusBedAura());
        this.add_module(new WurstplusOffhand());
        this.add_module(new WurstplusAutoGapple());
        this.add_module(new WurstplusAutoTotem());
        this.add_module(new WurstplusXCarry());
        this.add_module(new WurstplusNoSwing());
        this.add_module(new WurstplusBlink());
        this.add_module(new WurstplusPortalGodMode());
        this.add_module(new WurstplusAutoMount());
        this.add_module(new WurstplusPacketMine());
        this.add_module(new WurstplusEntityMine());
        this.add_module(new WurstplusBuildHeight());
        this.add_module(new WurstplusCoordExploit());
        this.add_module(new WurstplusNoHandshake());
        this.add_module(new WurstplusStrafe());
        this.add_module(new WurstplusStep());
        this.add_module(new WurstplusElytaFly());
        this.add_module(new WurstplusSprint());
        this.add_module(new WurstplusHighlight());
        this.add_module(new WurstplusHoleESP());
        this.add_module(new WurstplusLogSpots());
        this.add_module(new WurstplusShulkerPreview());
        this.add_module(new WurstplusViewmodleChanger());
        this.add_module(new WurstplusVoidESP());
        this.add_module(new WurstplusAntifog());
        this.add_module(new WurstplusNameTags());
        this.add_module(new WurstplusFuckedDetector());
        this.add_module(new WurstplusTracers());
        this.add_module(new WurstplusSkyColour());
        this.add_module(new WurstplusChams());
        this.add_module(new WurstplusCapes());
        this.add_module(new WurstplusAlwaysNight());
        this.add_module(new WurstplusMiddleClickFriends());
        this.add_module(new WurstplusStopEXP());
        this.add_module(new WurstplusAutoReplenish());
        this.add_module(new WurstplusAutoNomadHut());
        this.add_module(new WurstplusFastUtil());
        this.add_module(new WurstplusSpeedmine());
        this.add_module(new WurstplusFakePlayer());
        WurstplusModuleManager.array_module.sort(Comparator.comparing((Function<? super WurstplusModule, ? extends Comparable>)WurstplusModule::get_name));
    }
    
    public void add_module(final WurstplusModule module) {
        WurstplusModuleManager.array_module.add(module);
    }
    
    public ArrayList<WurstplusModule> get_array_modules() {
        return WurstplusModuleManager.array_module;
    }
    
    public ArrayList<WurstplusModule> get_array_active_modules() {
        final ArrayList<WurstplusModule> actived_modules = new ArrayList<WurstplusModule>();
        for (final WurstplusModule modules : this.get_array_modules()) {
            if (modules.is_active()) {
                actived_modules.add(modules);
            }
        }
        return actived_modules;
    }
    
    public Vec3d process(final Entity entity, final double x, final double y, final double z) {
        return new Vec3d((entity.posX - entity.lastTickPosX) * x, (entity.posY - entity.lastTickPosY) * y, (entity.posZ - entity.lastTickPosZ) * z);
    }
    
    public Vec3d get_interpolated_pos(final Entity entity, final double ticks) {
        return new Vec3d(entity.lastTickPosX, entity.lastTickPosY, entity.lastTickPosZ).add(this.process(entity, ticks, ticks, ticks));
    }
    
    public void render(final RenderWorldLastEvent event) {
        WurstplusModuleManager.mc.profiler.startSection("wurstplus");
        WurstplusModuleManager.mc.profiler.startSection("setup");
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        GlStateManager.disableDepth();
        GlStateManager.glLineWidth(1.0f);
        final Vec3d pos = this.get_interpolated_pos((Entity)WurstplusModuleManager.mc.player, event.getPartialTicks());
        final WurstplusEventRender event_render = new WurstplusEventRender(TravisRenderHelp.INSTANCE, pos);
        event_render.reset_translation();
        WurstplusModuleManager.mc.profiler.endSection();
        for (final WurstplusModule modules : this.get_array_modules()) {
            if (modules.is_active()) {
                WurstplusModuleManager.mc.profiler.startSection(modules.get_tag());
                modules.render(event_render);
                WurstplusModuleManager.mc.profiler.endSection();
            }
        }
        WurstplusModuleManager.mc.profiler.startSection("release");
        GlStateManager.glLineWidth(1.0f);
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        TravisRenderHelp.release_gl();
        WurstplusModuleManager.mc.profiler.endSection();
        WurstplusModuleManager.mc.profiler.endSection();
    }
    
    public void update() {
        for (final WurstplusModule modules : this.get_array_modules()) {
            if (modules.is_active()) {
                modules.update();
            }
        }
    }
    
    public void render() {
        for (final WurstplusModule modules : this.get_array_modules()) {
            if (modules.is_active()) {
                modules.render();
            }
        }
    }
    
    public void bind(final int event_key) {
        if (event_key == 0) {
            return;
        }
        for (final WurstplusModule modules : this.get_array_modules()) {
            if (modules.get_bind(0) == event_key) {
                modules.toggle();
            }
        }
    }
    
    public WurstplusModule get_module_with_tag(final String tag) {
        WurstplusModule module_requested = null;
        for (final WurstplusModule module : this.get_array_modules()) {
            if (module.get_tag().equalsIgnoreCase(tag)) {
                module_requested = module;
            }
        }
        return module_requested;
    }
    
    public ArrayList<WurstplusModule> get_modules_with_category(final WurstplusCategory category) {
        final ArrayList<WurstplusModule> module_requesteds = new ArrayList<WurstplusModule>();
        for (final WurstplusModule modules : this.get_array_modules()) {
            if (modules.get_category().equals(category)) {
                module_requesteds.add(modules);
            }
        }
        return module_requesteds;
    }
    
    public String get_tag() {
        return this.tag;
    }
    
    static {
        WurstplusModuleManager.array_module = new ArrayList<WurstplusModule>();
        WurstplusModuleManager.mc = Minecraft.getMinecraft();
    }
}
