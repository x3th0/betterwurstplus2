package me.travis.wurstplus.wurstplusmod.manager;

import java.text.*;
import me.travis.wurstplus.*;
import java.nio.file.attribute.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import java.nio.charset.*;
import com.google.gson.*;
import java.util.*;
import com.google.common.reflect.*;
import java.nio.file.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.io.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.render.components.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.render.pinnables.*;

public class WurstplusConfigManager
{
    public String tag;
    public String WURSTPLUS_FILE_COMBOBOXS;
    public String WURSTPLUS_FILE_INTEGERS;
    public String WURSTPLUS_FOLDER_CONFIG;
    public String WURSTPLUS_FILE_FRIENDS;
    public String WURSTPLUS_FILE_ENEMIES;
    public String WURSTPLUS_FILE_DRAWN;
    public String WURSTPLUS_FILE_EZMESSAGE;
    public String WURSTPLUS_FILE_BUTTONS;
    public String WURSTPLUS_FILE_DOUBLES;
    public String WURSTPLUS_FILE_CLIENT;
    public String WURSTPLUS_FILE_LABELS;
    public String WURSTPLUS_FOLDER_LOG;
    public String WURSTPLUS_FILE_BINDS;
    public String WURSTPLUS_FILE_HUD;
    public String WURSTPLUS_FILE_LOG;
    public String WURSTPLUS_ABS_FOLDER_LOG;
    public String WURSTPLUS_ABS_COMBOBOXS;
    public String WURSTPLUS_ABS_INTEGERS;
    public String WURSTPLUS_ABS_DOUBLES;
    public String WURSTPLUS_ABS_BUTTONS;
    public String WURSTPLUS_ABS_FRIENDS;
    public String WURSTPLUS_ABS_ENEMIES;
    public String WURSTPLUS_ABS_DRAWN;
    public String WURSTPLUS_ABS_EZMESSAGE;
    public String WURSTPLUS_ABS_LABELS;
    public String WURSTPLUS_ABS_FOLDER;
    public String WURSTPLUS_ABS_CLIENT;
    public String WURSTPLUS_ABS_BINDS;
    public String WURSTPLUS_ABS_HUD;
    public String WURSTPLUS_ABS_LOG;
    public Path PATH_FOLDER_LOG;
    public Path PATH_COMBOBOXS;
    public Path PATH_INTEGERS;
    public Path PATH_DOUBLES;
    public Path PATH_FRIENDS;
    public Path PATH_ENEMIES;
    public Path PATH_DRAWN;
    public Path PATH_EZMESSAGE;
    public Path PATH_BUTTONS;
    public Path PATH_CLIENT;
    public Path PATH_LABELS;
    public Path PATH_FOLDER;
    public Path PATH_BINDS;
    public Path PATH_HUD;
    public Path PATH_LOG;
    public StringBuilder log;
    
    public WurstplusConfigManager(final String tag) {
        this.WURSTPLUS_FILE_COMBOBOXS = "settings_2.bin";
        this.WURSTPLUS_FILE_INTEGERS = "settings_5.bin";
        this.WURSTPLUS_FOLDER_CONFIG = "WURSTPLUS/";
        this.WURSTPLUS_FILE_FRIENDS = "friends.json";
        this.WURSTPLUS_FILE_ENEMIES = "enemies.json";
        this.WURSTPLUS_FILE_DRAWN = "drawn.txt";
        this.WURSTPLUS_FILE_EZMESSAGE = "ez.txt";
        this.WURSTPLUS_FILE_BUTTONS = "settings_1.bin";
        this.WURSTPLUS_FILE_DOUBLES = "settings_4.bin";
        this.WURSTPLUS_FILE_CLIENT = "client.json";
        this.WURSTPLUS_FILE_LABELS = "settings_3.bin";
        this.WURSTPLUS_FOLDER_LOG = "logs/";
        this.WURSTPLUS_FILE_BINDS = "binds.txt";
        this.WURSTPLUS_FILE_HUD = "HUD.json";
        this.WURSTPLUS_FILE_LOG = "log";
        this.WURSTPLUS_ABS_FOLDER_LOG = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FOLDER_LOG;
        this.WURSTPLUS_ABS_COMBOBOXS = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_COMBOBOXS;
        this.WURSTPLUS_ABS_INTEGERS = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_INTEGERS;
        this.WURSTPLUS_ABS_DOUBLES = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_DOUBLES;
        this.WURSTPLUS_ABS_BUTTONS = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_BUTTONS;
        this.WURSTPLUS_ABS_FRIENDS = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_FRIENDS;
        this.WURSTPLUS_ABS_ENEMIES = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_ENEMIES;
        this.WURSTPLUS_ABS_DRAWN = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_DRAWN;
        this.WURSTPLUS_ABS_EZMESSAGE = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_EZMESSAGE;
        this.WURSTPLUS_ABS_LABELS = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_LABELS;
        this.WURSTPLUS_ABS_FOLDER = this.WURSTPLUS_FOLDER_CONFIG;
        this.WURSTPLUS_ABS_CLIENT = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_CLIENT;
        this.WURSTPLUS_ABS_BINDS = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_BINDS;
        this.WURSTPLUS_ABS_HUD = this.WURSTPLUS_FOLDER_CONFIG + this.WURSTPLUS_FILE_HUD;
        this.WURSTPLUS_ABS_LOG = this.WURSTPLUS_ABS_FOLDER_LOG + this.WURSTPLUS_FILE_LOG;
        this.PATH_FOLDER_LOG = Paths.get(this.WURSTPLUS_ABS_FOLDER_LOG, new String[0]);
        this.PATH_COMBOBOXS = Paths.get(this.WURSTPLUS_ABS_COMBOBOXS, new String[0]);
        this.PATH_INTEGERS = Paths.get(this.WURSTPLUS_ABS_INTEGERS, new String[0]);
        this.PATH_DOUBLES = Paths.get(this.WURSTPLUS_ABS_DOUBLES, new String[0]);
        this.PATH_FRIENDS = Paths.get(this.WURSTPLUS_ABS_FRIENDS, new String[0]);
        this.PATH_ENEMIES = Paths.get(this.WURSTPLUS_ABS_ENEMIES, new String[0]);
        this.PATH_DRAWN = Paths.get(this.WURSTPLUS_ABS_DRAWN, new String[0]);
        this.PATH_EZMESSAGE = Paths.get(this.WURSTPLUS_ABS_EZMESSAGE, new String[0]);
        this.PATH_BUTTONS = Paths.get(this.WURSTPLUS_ABS_BUTTONS, new String[0]);
        this.PATH_CLIENT = Paths.get(this.WURSTPLUS_ABS_CLIENT, new String[0]);
        this.PATH_LABELS = Paths.get(this.WURSTPLUS_ABS_LABELS, new String[0]);
        this.PATH_FOLDER = Paths.get(this.WURSTPLUS_ABS_FOLDER, new String[0]);
        this.PATH_BINDS = Paths.get(this.WURSTPLUS_ABS_BINDS, new String[0]);
        this.PATH_HUD = Paths.get(this.WURSTPLUS_ABS_HUD, new String[0]);
        this.tag = tag;
        this.log = new StringBuilder();
        final Date hora = new Date();
        final String data = new SimpleDateFormat("dd/MM/yyyy' - 'HH:mm:ss:").format(hora);
        this.send_log("****** Files have started. ******");
        this.send_log("- Any crash or problem its here.");
        this.send_log("****** File information. ******");
        this.send_log("- Client name: " + Wurstplus.get_name());
        this.send_log("- Client version: " + Wurstplus.get_version());
        this.send_log("- File created on: " + data);
        this.send_log("- ");
        this.send_log("- >");
    }
    
    public void WURSTPLUS_VERIFY_FOLDER(final Path path) throws IOException {
        if (!Files.exists(path, new LinkOption[0])) {
            Files.createDirectories(path, (FileAttribute<?>[])new FileAttribute[0]);
        }
    }
    
    public void WURSTPLUS_VERIFY_FILES(final Path path) throws IOException {
        if (!Files.exists(path, new LinkOption[0])) {
            Files.createFile(path, (FileAttribute<?>[])new FileAttribute[0]);
        }
    }
    
    public void WURSTPLUS_DELETE_FILES(final String abs_path) throws IOException {
        final File file = new File(abs_path);
        file.delete();
    }
    
    public void WURSTPLUS_SAVE_BUTTONS() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_BUTTONS = new JsonObject();
        for (final WurstplusSetting buttons : Wurstplus.get_setting_manager().get_array_settings()) {
            final boolean button = false;
            final JsonObject WURSTPLUS_BUTTON_SETTING = new JsonObject();
            if (!this.is(buttons, "button")) {
                continue;
            }
            WURSTPLUS_BUTTON_SETTING.add("master", (JsonElement)new JsonPrimitive(buttons.get_master().get_tag()));
            WURSTPLUS_BUTTON_SETTING.add("name", (JsonElement)new JsonPrimitive(buttons.get_name()));
            WURSTPLUS_BUTTON_SETTING.add("tag", (JsonElement)new JsonPrimitive(buttons.get_tag()));
            WURSTPLUS_BUTTON_SETTING.add("value", (JsonElement)new JsonPrimitive(buttons.get_value(button)));
            WURSTPLUS_BUTTON_SETTING.add("type", (JsonElement)new JsonPrimitive(buttons.get_type()));
            WURSTPLUS_MAIN_BUTTONS.add(buttons.get_tag(), (JsonElement)WURSTPLUS_BUTTON_SETTING);
        }
        WURSTPLUS_MAIN_JSON.add("buttons", (JsonElement)WURSTPLUS_MAIN_BUTTONS);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_BUTTONS);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_BUTTONS);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_BUTTONS), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_COMBOBOXS() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_COMBOBOXS = new JsonObject();
        for (final WurstplusSetting comboboxs : Wurstplus.get_setting_manager().get_array_settings()) {
            final JsonObject WURSTPLUS_COMBOBOX_SETTING = new JsonObject();
            if (!this.is(comboboxs, "combobox")) {
                continue;
            }
            WURSTPLUS_COMBOBOX_SETTING.add("master", (JsonElement)new JsonPrimitive(comboboxs.get_master().get_tag()));
            WURSTPLUS_COMBOBOX_SETTING.add("name", (JsonElement)new JsonPrimitive(comboboxs.get_name()));
            WURSTPLUS_COMBOBOX_SETTING.add("tag", (JsonElement)new JsonPrimitive(comboboxs.get_tag()));
            WURSTPLUS_COMBOBOX_SETTING.add("value", (JsonElement)new JsonPrimitive(comboboxs.get_current_value()));
            WURSTPLUS_COMBOBOX_SETTING.add("type", (JsonElement)new JsonPrimitive(comboboxs.get_type()));
            WURSTPLUS_MAIN_COMBOBOXS.add(comboboxs.get_tag(), (JsonElement)WURSTPLUS_COMBOBOX_SETTING);
        }
        WURSTPLUS_MAIN_JSON.add("comboboxs", (JsonElement)WURSTPLUS_MAIN_COMBOBOXS);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_COMBOBOXS);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_COMBOBOXS);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_COMBOBOXS), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_LABELS() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_LABELS = new JsonObject();
        for (final WurstplusSetting labels : Wurstplus.get_setting_manager().get_array_settings()) {
            final String label = "ue";
            final JsonObject WURSTPLUS_LABELS_SETTING = new JsonObject();
            if (!this.is(labels, "label")) {
                continue;
            }
            WURSTPLUS_LABELS_SETTING.add("master", (JsonElement)new JsonPrimitive(labels.get_master().get_tag()));
            WURSTPLUS_LABELS_SETTING.add("name", (JsonElement)new JsonPrimitive(labels.get_name()));
            WURSTPLUS_LABELS_SETTING.add("tag", (JsonElement)new JsonPrimitive(labels.get_tag()));
            WURSTPLUS_LABELS_SETTING.add("value", (JsonElement)new JsonPrimitive(labels.get_value(label)));
            WURSTPLUS_LABELS_SETTING.add("type", (JsonElement)new JsonPrimitive(labels.get_type()));
            WURSTPLUS_MAIN_LABELS.add(labels.get_tag(), (JsonElement)WURSTPLUS_LABELS_SETTING);
        }
        WURSTPLUS_MAIN_JSON.add("labels", (JsonElement)WURSTPLUS_MAIN_LABELS);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_LABELS);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_LABELS);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_LABELS), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_DOUBLES() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_SLIDERS_D = new JsonObject();
        for (final WurstplusSetting slider_doubles : Wurstplus.get_setting_manager().get_array_settings()) {
            final double double_ = 1.2;
            if (!this.is(slider_doubles, "doubleslider")) {
                continue;
            }
            final JsonObject WURSTPLUS_SLIDER_DOUBLES_SETTING = new JsonObject();
            WURSTPLUS_SLIDER_DOUBLES_SETTING.add("master", (JsonElement)new JsonPrimitive(slider_doubles.get_master().get_tag()));
            WURSTPLUS_SLIDER_DOUBLES_SETTING.add("name", (JsonElement)new JsonPrimitive(slider_doubles.get_name()));
            WURSTPLUS_SLIDER_DOUBLES_SETTING.add("tag", (JsonElement)new JsonPrimitive(slider_doubles.get_tag()));
            WURSTPLUS_SLIDER_DOUBLES_SETTING.add("value", (JsonElement)new JsonPrimitive((Number)slider_doubles.get_value(double_)));
            WURSTPLUS_SLIDER_DOUBLES_SETTING.add("type", (JsonElement)new JsonPrimitive(slider_doubles.get_type()));
            WURSTPLUS_MAIN_SLIDERS_D.add(slider_doubles.get_tag(), (JsonElement)WURSTPLUS_SLIDER_DOUBLES_SETTING);
        }
        WURSTPLUS_MAIN_JSON.add("sliders", (JsonElement)WURSTPLUS_MAIN_SLIDERS_D);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_DOUBLES);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_DOUBLES);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_DOUBLES), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_INTEGERS() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_SLIDERS_I = new JsonObject();
        for (final WurstplusSetting slider_integers : Wurstplus.get_setting_manager().get_array_settings()) {
            final double integer = 1.0;
            final JsonObject WURSTPLUS_SLIDER_INTEGERS_SETTING = new JsonObject();
            if (!this.is(slider_integers, "integerslider")) {
                continue;
            }
            WURSTPLUS_SLIDER_INTEGERS_SETTING.add("master", (JsonElement)new JsonPrimitive(slider_integers.get_master().get_tag()));
            WURSTPLUS_SLIDER_INTEGERS_SETTING.add("name", (JsonElement)new JsonPrimitive(slider_integers.get_name()));
            WURSTPLUS_SLIDER_INTEGERS_SETTING.add("tag", (JsonElement)new JsonPrimitive(slider_integers.get_tag()));
            WURSTPLUS_SLIDER_INTEGERS_SETTING.add("value", (JsonElement)new JsonPrimitive((Number)(int)Math.round(slider_integers.get_value(integer))));
            WURSTPLUS_SLIDER_INTEGERS_SETTING.add("type", (JsonElement)new JsonPrimitive(slider_integers.get_type()));
            WURSTPLUS_MAIN_SLIDERS_I.add(slider_integers.get_tag(), (JsonElement)WURSTPLUS_SLIDER_INTEGERS_SETTING);
        }
        WURSTPLUS_MAIN_JSON.add("sliders", (JsonElement)WURSTPLUS_MAIN_SLIDERS_I);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_INTEGERS);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_INTEGERS);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_INTEGERS), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_FRIENDS() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson((Object)WurstplusFriendManager.friends);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_FRIENDS), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_ENEMIES() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson((Object)WurstplusEnemyManager.enemies);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_ENEMIES), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_SAVE_DRAWN() throws IOException {
        final FileWriter WURSTPLUS_WRITER = new FileWriter(this.WURSTPLUS_ABS_DRAWN);
        for (final String s : WurstplusDrawnManager.hidden_tags) {
            WURSTPLUS_WRITER.write(s + System.lineSeparator());
        }
        WURSTPLUS_WRITER.close();
    }
    
    public void WURSTPLUS_SAVE_EZMESSAGE() throws IOException {
        final FileWriter WURSTPLUS_WRITER = new FileWriter(this.WURSTPLUS_ABS_EZMESSAGE);
        try {
            WURSTPLUS_WRITER.write(WurstplusEzMessageManager.message);
        }
        catch (Exception ignored) {
            WURSTPLUS_WRITER.write("test message");
        }
        WURSTPLUS_WRITER.close();
    }
    
    public void WURSTPLUS_LOAD_EZMESSAGE() throws IOException {
        WurstplusEzMessageManager.message = Files.readAllLines(Paths.get(this.WURSTPLUS_ABS_EZMESSAGE, new String[0])).toString();
    }
    
    public void WURSTPLUS_LOAD_DRAWN() throws IOException {
        WurstplusDrawnManager.hidden_tags = Files.readAllLines(Paths.get(this.WURSTPLUS_ABS_DRAWN, new String[0]));
    }
    
    public void WURSTPLUS_LOAD_FRIENDS() throws IOException {
        final Gson WURSTPLUS_GSON = new Gson();
        final Reader WURSTPLUS_READER = Files.newBufferedReader(Paths.get(this.WURSTPLUS_ABS_FRIENDS, new String[0]));
        WurstplusFriendManager.friends = (ArrayList<WurstplusFriendManager.Friend>)WURSTPLUS_GSON.fromJson(WURSTPLUS_READER, new TypeToken<ArrayList<WurstplusFriendManager.Friend>>() {}.getType());
        WURSTPLUS_READER.close();
    }
    
    public void WURSTPLUS_LOAD_ENEMIES() throws IOException {
        final Gson WURSTPLUS_GSON = new Gson();
        final Reader WURSTPLUS_READER = Files.newBufferedReader(Paths.get(this.WURSTPLUS_ABS_ENEMIES, new String[0]));
        WurstplusEnemyManager.enemies = (ArrayList<WurstplusEnemyManager.Enemy>)WURSTPLUS_GSON.fromJson(WURSTPLUS_READER, new TypeToken<ArrayList<WurstplusEnemyManager.Enemy>>() {}.getType());
        WURSTPLUS_READER.close();
    }
    
    public void WURSTPLUS_LOAD_BUTTONS() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_BUTTONS, new OpenOption[0]);
        final JsonObject WURSTPLUS_JSON = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_MAIN_BUTTONS = WURSTPLUS_JSON.get("buttons").getAsJsonObject();
        for (final WurstplusSetting buttons : Wurstplus.get_setting_manager().get_array_settings()) {
            if (!this.is(buttons, "button")) {
                continue;
            }
            final JsonObject WURSTPLUS_BUTTONS_INFO = WURSTPLUS_MAIN_BUTTONS.get(buttons.get_tag()).getAsJsonObject();
            final WurstplusSetting button_requested = Wurstplus.get_setting_manager().get_setting_with_tag(WURSTPLUS_BUTTONS_INFO.get("master").getAsString(), WURSTPLUS_BUTTONS_INFO.get("tag").getAsString());
            if (button_requested == null) {
                continue;
            }
            button_requested.set_value(WURSTPLUS_BUTTONS_INFO.get("value").getAsBoolean());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_LOAD_COMBOBOXS() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_COMBOBOXS, new OpenOption[0]);
        final JsonObject WURSTPLUS_JSON = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_COMBOBOXS_MAIN = WURSTPLUS_JSON.get("comboboxs").getAsJsonObject();
        for (final WurstplusSetting comboboxs : Wurstplus.get_setting_manager().get_array_settings()) {
            if (!this.is(comboboxs, "combobox")) {
                continue;
            }
            final JsonObject WURSTPLUS_COMBOBOX_INFO = WURSTPLUS_COMBOBOXS_MAIN.get(comboboxs.get_tag()).getAsJsonObject();
            final WurstplusSetting combobox_requested = Wurstplus.get_setting_manager().get_setting_with_tag(WURSTPLUS_COMBOBOX_INFO.get("master").getAsString(), WURSTPLUS_COMBOBOX_INFO.get("tag").getAsString());
            if (combobox_requested == null) {
                continue;
            }
            combobox_requested.set_current_value(WURSTPLUS_COMBOBOX_INFO.get("value").getAsString());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_LOAD_LABELS() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_LABELS, new OpenOption[0]);
        final JsonObject WURSTPLUS_JSON = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_LABELS_MAIN = WURSTPLUS_JSON.get("labels").getAsJsonObject();
        for (final WurstplusSetting labels : Wurstplus.get_setting_manager().get_array_settings()) {
            if (!this.is(labels, "label")) {
                continue;
            }
            final JsonObject WURSTPLUS_LABELS_INFO = WURSTPLUS_LABELS_MAIN.get(labels.get_tag()).getAsJsonObject();
            final WurstplusSetting label_requested = Wurstplus.get_setting_manager().get_setting_with_tag(WURSTPLUS_LABELS_INFO.get("master").getAsString(), WURSTPLUS_LABELS_INFO.get("tag").getAsString());
            if (label_requested == null) {
                continue;
            }
            label_requested.set_value(WURSTPLUS_LABELS_INFO.get("value").getAsString());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_LOAD_DOUBLES() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_DOUBLES, new OpenOption[0]);
        final JsonObject WURSTPLUS_JSON = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_SLIDER_D_MAIN = WURSTPLUS_JSON.get("sliders").getAsJsonObject();
        for (final WurstplusSetting slider_doubles : Wurstplus.get_setting_manager().get_array_settings()) {
            if (!this.is(slider_doubles, "doubleslider")) {
                continue;
            }
            final JsonObject WURSTPLUS_SLIDER_D_INFO = WURSTPLUS_SLIDER_D_MAIN.get(slider_doubles.get_tag()).getAsJsonObject();
            final WurstplusSetting slider_double_requested = Wurstplus.get_setting_manager().get_setting_with_tag(WURSTPLUS_SLIDER_D_INFO.get("master").getAsString(), WURSTPLUS_SLIDER_D_INFO.get("tag").getAsString());
            if (slider_double_requested == null) {
                continue;
            }
            slider_double_requested.set_value(WURSTPLUS_SLIDER_D_INFO.get("value").getAsDouble());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_LOAD_INTEGERS() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_INTEGERS, new OpenOption[0]);
        final JsonObject WURSTPLUS_JSON = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_SLIDER_I_MAIN = WURSTPLUS_JSON.get("sliders").getAsJsonObject();
        for (final WurstplusSetting slider_integers : Wurstplus.get_setting_manager().get_array_settings()) {
            if (!this.is(slider_integers, "integerslider")) {
                continue;
            }
            final JsonObject WURSTPLUS_SLIDER_I_INFO = WURSTPLUS_SLIDER_I_MAIN.get(slider_integers.get_tag()).getAsJsonObject();
            final WurstplusSetting slider_integer_requested = Wurstplus.get_setting_manager().get_setting_with_tag(WURSTPLUS_SLIDER_I_INFO.get("master").getAsString(), WURSTPLUS_SLIDER_I_INFO.get("tag").getAsString());
            if (slider_integer_requested == null) {
                continue;
            }
            slider_integer_requested.set_value(WURSTPLUS_SLIDER_I_INFO.get("value").getAsInt());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_SAVE_BINDS() throws IOException {
        try {
            this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_BINDS);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_BINDS);
            final File file = new File(this.WURSTPLUS_ABS_BINDS);
            final BufferedWriter buffer = new BufferedWriter(new FileWriter(file));
            for (final WurstplusModule modules : Wurstplus.get_module_manager().get_array_modules()) {
                buffer.write(modules.get_tag() + ":" + modules.get_bind(1) + ":" + modules.is_active() + "\r\n");
            }
            buffer.close();
        }
        catch (Exception ex) {}
    }
    
    public void WURSTPLUS_LOAD_BINDS() throws IOException {
        try {
            final File file = new File(this.WURSTPLUS_ABS_BINDS);
            final FileInputStream input_stream = new FileInputStream(file.getAbsolutePath());
            final DataInputStream data_stream = new DataInputStream(input_stream);
            final BufferedReader buffer = new BufferedReader(new InputStreamReader(data_stream));
            String line;
            while ((line = buffer.readLine()) != null) {
                try {
                    final String colune = line.trim();
                    final String tag = colune.split(":")[0];
                    final String bind = colune.split(":")[1];
                    final String active = colune.split(":")[2];
                    final WurstplusModule module = Wurstplus.get_module_manager().get_module_with_tag(tag);
                    module.set_bind(Integer.parseInt(bind));
                    module.set_active(Boolean.parseBoolean(active));
                }
                catch (Exception ex) {}
            }
            buffer.close();
        }
        catch (Exception ex2) {}
    }
    
    public void WURSTPLUS_SAVE_CLIENT() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_CONFIGS = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_GUI = new JsonObject();
        WURSTPLUS_MAIN_CONFIGS.add("name", (JsonElement)new JsonPrimitive(Wurstplus.get_name()));
        WURSTPLUS_MAIN_CONFIGS.add("version", (JsonElement)new JsonPrimitive(Wurstplus.get_version()));
        WURSTPLUS_MAIN_CONFIGS.add("user", (JsonElement)new JsonPrimitive(Wurstplus.get_actual_user()));
        WURSTPLUS_MAIN_CONFIGS.add("prefix", (JsonElement)new JsonPrimitive(WurstplusCommandManager.get_prefix()));
        for (final WurstplusFrame frames_gui : Wurstplus.click_gui.get_array_frames()) {
            final JsonObject WURSTPLUS_FRAMES_INFO = new JsonObject();
            WURSTPLUS_FRAMES_INFO.add("name", (JsonElement)new JsonPrimitive(frames_gui.get_name()));
            WURSTPLUS_FRAMES_INFO.add("tag", (JsonElement)new JsonPrimitive(frames_gui.get_tag()));
            WURSTPLUS_FRAMES_INFO.add("x", (JsonElement)new JsonPrimitive((Number)frames_gui.get_x()));
            WURSTPLUS_FRAMES_INFO.add("y", (JsonElement)new JsonPrimitive((Number)frames_gui.get_y()));
            WURSTPLUS_MAIN_GUI.add(frames_gui.get_tag(), (JsonElement)WURSTPLUS_FRAMES_INFO);
        }
        WURSTPLUS_MAIN_JSON.add("configuration", (JsonElement)WURSTPLUS_MAIN_CONFIGS);
        WURSTPLUS_MAIN_JSON.add("gui", (JsonElement)WURSTPLUS_MAIN_GUI);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_CLIENT);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_CLIENT);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_CLIENT), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_LOAD_CLIENT() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_CLIENT, new OpenOption[0]);
        final JsonObject WURSTPLUS_MAIN_CLIENT = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_MAIN_CONFIGURATION = WURSTPLUS_MAIN_CLIENT.get("configuration").getAsJsonObject();
        final JsonObject WURSTPLUS_MAIN_GUI = WURSTPLUS_MAIN_CLIENT.get("gui").getAsJsonObject();
        WurstplusCommandManager.set_prefix(WURSTPLUS_MAIN_CONFIGURATION.get("prefix").getAsString());
        for (final WurstplusFrame frames : Wurstplus.click_gui.get_array_frames()) {
            final JsonObject WURSTPLUS_FRAME_INFO = WURSTPLUS_MAIN_GUI.get(frames.get_tag()).getAsJsonObject();
            final WurstplusFrame frame_requested = Wurstplus.click_gui.get_frame_with_tag(WURSTPLUS_FRAME_INFO.get("tag").getAsString());
            frame_requested.set_x(WURSTPLUS_FRAME_INFO.get("x").getAsInt());
            frame_requested.set_y(WURSTPLUS_FRAME_INFO.get("y").getAsInt());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_SAVE_HUD() throws IOException {
        final Gson WURSTPLUS_GSON = new GsonBuilder().setPrettyPrinting().create();
        final JsonParser WURSTPLUS_PARSER = new JsonParser();
        final JsonObject WURSTPLUS_MAIN_JSON = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_FRAME = new JsonObject();
        final JsonObject WURSTPLUS_MAIN_HUD = new JsonObject();
        WURSTPLUS_MAIN_FRAME.add("name", (JsonElement)new JsonPrimitive(Wurstplus.click_hud.get_frame_hud().get_name()));
        WURSTPLUS_MAIN_FRAME.add("tag", (JsonElement)new JsonPrimitive(Wurstplus.click_hud.get_frame_hud().get_tag()));
        WURSTPLUS_MAIN_FRAME.add("x", (JsonElement)new JsonPrimitive((Number)Wurstplus.click_hud.get_frame_hud().get_x()));
        WURSTPLUS_MAIN_FRAME.add("y", (JsonElement)new JsonPrimitive((Number)Wurstplus.click_hud.get_frame_hud().get_y()));
        for (final WurstplusPinnable pinnables_hud : Wurstplus.get_hud_manager().get_array_huds()) {
            final JsonObject WURSTPLUS_FRAMES_INFO = new JsonObject();
            WURSTPLUS_FRAMES_INFO.add("title", (JsonElement)new JsonPrimitive(pinnables_hud.get_title()));
            WURSTPLUS_FRAMES_INFO.add("tag", (JsonElement)new JsonPrimitive(pinnables_hud.get_tag()));
            WURSTPLUS_FRAMES_INFO.add("state", (JsonElement)new JsonPrimitive(pinnables_hud.is_active()));
            WURSTPLUS_FRAMES_INFO.add("dock", (JsonElement)new JsonPrimitive(pinnables_hud.get_dock()));
            WURSTPLUS_FRAMES_INFO.add("x", (JsonElement)new JsonPrimitive((Number)pinnables_hud.get_x()));
            WURSTPLUS_FRAMES_INFO.add("y", (JsonElement)new JsonPrimitive((Number)pinnables_hud.get_y()));
            WURSTPLUS_MAIN_HUD.add(pinnables_hud.get_tag(), (JsonElement)WURSTPLUS_FRAMES_INFO);
        }
        WURSTPLUS_MAIN_JSON.add("frame", (JsonElement)WURSTPLUS_MAIN_FRAME);
        WURSTPLUS_MAIN_JSON.add("hud", (JsonElement)WURSTPLUS_MAIN_HUD);
        final JsonElement WURSTPLUS_MAIN_PRETTY_JSON = WURSTPLUS_PARSER.parse(WURSTPLUS_MAIN_JSON.toString());
        final String WURSTPLUS_JSON = WURSTPLUS_GSON.toJson(WURSTPLUS_MAIN_PRETTY_JSON);
        this.WURSTPLUS_DELETE_FILES(this.WURSTPLUS_ABS_HUD);
        this.WURSTPLUS_VERIFY_FILES(this.PATH_HUD);
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(this.WURSTPLUS_ABS_HUD), StandardCharsets.UTF_8);
        file.write(WURSTPLUS_JSON);
        file.close();
    }
    
    public void WURSTPLUS_LOAD_HUD() throws IOException {
        final InputStream WURSTPLUS_JSON_FILE = Files.newInputStream(this.PATH_HUD, new OpenOption[0]);
        final JsonObject WURSTPLUS_MAIN_HUD = new JsonParser().parse((Reader)new InputStreamReader(WURSTPLUS_JSON_FILE)).getAsJsonObject();
        final JsonObject WURSTPLUS_MAIN_FRAME = WURSTPLUS_MAIN_HUD.get("frame").getAsJsonObject();
        final JsonObject WURSTPLUS_MAIN_HUDS = WURSTPLUS_MAIN_HUD.get("hud").getAsJsonObject();
        Wurstplus.click_hud.get_frame_hud().set_x(WURSTPLUS_MAIN_FRAME.get("x").getAsInt());
        Wurstplus.click_hud.get_frame_hud().set_y(WURSTPLUS_MAIN_FRAME.get("y").getAsInt());
        for (final WurstplusPinnable pinnables : Wurstplus.get_hud_manager().get_array_huds()) {
            final JsonObject WURSTPLUS_HUD_INFO = WURSTPLUS_MAIN_HUDS.get(pinnables.get_tag()).getAsJsonObject();
            final WurstplusPinnable pinnable_requested = Wurstplus.get_hud_manager().get_pinnable_with_tag(WURSTPLUS_HUD_INFO.get("tag").getAsString());
            pinnable_requested.set_active(WURSTPLUS_HUD_INFO.get("state").getAsBoolean());
            pinnable_requested.set_dock(WURSTPLUS_HUD_INFO.get("dock").getAsBoolean());
            pinnable_requested.set_x(WURSTPLUS_HUD_INFO.get("x").getAsInt());
            pinnable_requested.set_y(WURSTPLUS_HUD_INFO.get("y").getAsInt());
        }
        WURSTPLUS_JSON_FILE.close();
    }
    
    public void WURSTPLUS_SAVE_LOG() throws IOException {
        final Date hora = new Date();
        final String cache = "-";
        final String year = new SimpleDateFormat("yyyy").format(hora);
        final String month = new SimpleDateFormat("MM").format(hora);
        final String day = new SimpleDateFormat("dd").format(hora);
        final String hour = new SimpleDateFormat("HH").format(hora);
        final String mm = new SimpleDateFormat("mm").format(hora);
        final String ss = new SimpleDateFormat("ss").format(hora);
        final String path = this.WURSTPLUS_ABS_LOG + cache + year + cache + month + cache + day + cache + hour + cache + mm + cache + ss + cache + ".txt";
        this.WURSTPLUS_VERIFY_FILES(this.PATH_LOG = Paths.get(path, new String[0]));
        final OutputStreamWriter file = new OutputStreamWriter(new FileOutputStream(path), StandardCharsets.UTF_8);
        file.write(this.log.toString());
        file.close();
    }
    
    public void save_values() {
        try {
            this.WURSTPLUS_VERIFY_FOLDER(this.PATH_FOLDER);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_BUTTONS);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_COMBOBOXS);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_LABELS);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_DOUBLES);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_INTEGERS);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_FRIENDS);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_DRAWN);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_EZMESSAGE);
            this.WURSTPLUS_VERIFY_FILES(this.PATH_ENEMIES);
            this.WURSTPLUS_SAVE_BUTTONS();
            this.WURSTPLUS_SAVE_COMBOBOXS();
            this.WURSTPLUS_SAVE_LABELS();
            this.WURSTPLUS_SAVE_DOUBLES();
            this.WURSTPLUS_SAVE_INTEGERS();
            this.WURSTPLUS_SAVE_FRIENDS();
            this.WURSTPLUS_SAVE_ENEMIES();
            this.WURSTPLUS_SAVE_DRAWN();
            this.WURSTPLUS_SAVE_EZMESSAGE();
        }
        catch (IOException exc) {
            exc.printStackTrace();
        }
    }
    
    public void save_binds() {
        try {
            this.WURSTPLUS_VERIFY_FOLDER(this.PATH_FOLDER);
            this.WURSTPLUS_SAVE_BINDS();
        }
        catch (IOException exc) {
            exc.printStackTrace();
        }
    }
    
    public void save_client() {
        try {
            this.WURSTPLUS_VERIFY_FOLDER(this.PATH_FOLDER);
            this.WURSTPLUS_SAVE_CLIENT();
            this.WURSTPLUS_SAVE_HUD();
        }
        catch (IOException exc) {
            exc.printStackTrace();
        }
    }
    
    public void save_log() {
        try {
            this.WURSTPLUS_VERIFY_FOLDER(this.PATH_FOLDER);
            this.WURSTPLUS_VERIFY_FOLDER(this.PATH_FOLDER_LOG);
            this.WURSTPLUS_SAVE_LOG();
        }
        catch (IOException exc) {
            exc.printStackTrace();
        }
    }
    
    public void load() {
        try {
            this.WURSTPLUS_LOAD_BUTTONS();
        }
        catch (Exception ex) {}
        try {
            this.WURSTPLUS_LOAD_FRIENDS();
        }
        catch (Exception ex2) {}
        try {
            this.WURSTPLUS_LOAD_ENEMIES();
        }
        catch (Exception ex3) {}
        try {
            this.WURSTPLUS_LOAD_DRAWN();
        }
        catch (Exception ex4) {}
        try {
            this.WURSTPLUS_LOAD_EZMESSAGE();
        }
        catch (Exception ex5) {}
        try {
            this.WURSTPLUS_LOAD_COMBOBOXS();
        }
        catch (Exception ex6) {}
        try {
            this.WURSTPLUS_LOAD_LABELS();
        }
        catch (Exception ex7) {}
        try {
            this.WURSTPLUS_LOAD_DOUBLES();
        }
        catch (Exception ex8) {}
        try {
            this.WURSTPLUS_LOAD_INTEGERS();
        }
        catch (Exception ex9) {}
        try {
            this.WURSTPLUS_LOAD_BINDS();
        }
        catch (Exception ex10) {}
        try {
            this.WURSTPLUS_LOAD_CLIENT();
        }
        catch (Exception ex11) {}
        try {
            this.WURSTPLUS_LOAD_HUD();
        }
        catch (Exception ex12) {}
    }
    
    public boolean is(final WurstplusSetting setting, final String type) {
        return setting.get_type().equalsIgnoreCase(type);
    }
    
    public void send_log(final String log) {
        this.log.append(log).append("\n");
    }
}
