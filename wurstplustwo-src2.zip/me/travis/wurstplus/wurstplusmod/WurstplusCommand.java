package me.travis.wurstplus.wurstplusmod;

import me.travis.wurstplus.*;
import me.travis.wurstplus.wurstplusmod.manager.*;

public class WurstplusCommand
{
    String name;
    String description;
    
    public WurstplusCommand(final String name, final String description) {
        this.name = name;
        this.description = description;
    }
    
    public boolean get_message(final String[] message) {
        return false;
    }
    
    public String get_name() {
        return this.name;
    }
    
    public String get_description() {
        return this.description;
    }
    
    public String current_prefix() {
        Wurstplus.get_command_manager();
        return WurstplusCommandManager.get_prefix();
    }
}
