package me.travis.wurstplus.wurstplusmod.hacks;

public enum WurstplusCategory
{
    WURSTPLUS_CHAT("Chat", "WurstplusChat", "y_sw", "y_bt"), 
    WURSTPLUS_COMBAT("Combat", "WurstplusCombat", "y_sw", "y_bt"), 
    WURSTPLUS_MOVEMENT("Movement", "WurstplusMovement", "y_sw", "y_bt"), 
    WURSTPLUS_RENDER("Render", "WurstplusRender", "y_sw", "y_bt"), 
    WURSTPLUS_EXPLOIT("Exploit", "WurstplusExploit", "y_sw", "y_bt"), 
    WURSTPLUS_MISC("Misc", "WurstplusMisc", "y_sw", "y_bt"), 
    WURSTPLUS_GUI("GUI", "WurstplusGUI", "y_sw", "y_bt"), 
    WURSTPLUS_BETA("Beta", "WurstplusBeta", "y_sw", "n_bt"), 
    WURSTPLUS_HIDDEN("Hidden", "WurstplusHidden", "n_sw", "y_bt");
    
    String name;
    String tag;
    String hidden;
    String beta;
    
    private WurstplusCategory(final String name, final String tag, final String hidden, final String beta) {
        this.name = name;
        this.tag = tag;
        this.hidden = hidden;
        this.beta = beta;
    }
    
    public boolean is_hidden() {
        return this.hidden.equals("n_sw");
    }
    
    public boolean is_beta() {
        return this.beta.equals("y_bt");
    }
    
    public String get_name() {
        return this.name;
    }
    
    public String get_tag() {
        return this.tag;
    }
}
