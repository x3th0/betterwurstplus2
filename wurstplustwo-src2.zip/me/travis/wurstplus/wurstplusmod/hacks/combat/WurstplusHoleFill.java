package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;

public class WurstplusHoleFill extends WurstplusModule
{
    WurstplusSetting hole_toggle;
    WurstplusSetting hole_rotate;
    WurstplusSetting hole_range;
    private final ArrayList<BlockPos> holes;
    private boolean sneak;
    
    public WurstplusHoleFill() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.hole_toggle = this.create("Toggle", "HoleFillToggle", true);
        this.hole_rotate = this.create("Rotate", "HoleFillRotate", true);
        this.hole_range = this.create("Range", "HoleFillRange", 4, 1, 6);
        this.holes = new ArrayList<BlockPos>();
        this.name = "Hole Fill";
        this.tag = "HoleFill";
        this.description = "Turn holes into floors";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    public void enable() {
        this.find_new_holes();
    }
    
    public void disable() {
        this.holes.clear();
    }
    
    @Override
    public void update() {
        if (this.find_in_hotbar() == -1) {
            this.disable();
            return;
        }
        if (this.holes.isEmpty()) {
            if (!this.hole_toggle.get_value(true)) {
                this.set_disable();
                WurstplusMessage.toggle_message(this);
                return;
            }
            this.find_new_holes();
        }
        BlockPos pos_to_fill = null;
        for (final BlockPos pos : new ArrayList<BlockPos>(this.holes)) {
            if (pos == null) {
                continue;
            }
            final WurstplusBlockInteractHelper.ValidResult result = WurstplusBlockInteractHelper.valid(pos);
            if (result == WurstplusBlockInteractHelper.ValidResult.Ok) {
                pos_to_fill = pos;
                break;
            }
            this.holes.remove(pos);
        }
        final int obi_slot = this.find_in_hotbar();
        if (this.find_in_hotbar() == -1) {
            this.disable();
            return;
        }
        if (pos_to_fill != null) {
            final int last_slot = WurstplusHoleFill.mc.player.inventory.currentItem;
            WurstplusHoleFill.mc.player.inventory.currentItem = obi_slot;
            WurstplusHoleFill.mc.playerController.updateController();
            if (this.place_blocks(pos_to_fill)) {
                this.holes.remove(pos_to_fill);
            }
            WurstplusHoleFill.mc.player.inventory.currentItem = last_slot;
        }
    }
    
    public void find_new_holes() {
        this.holes.clear();
        for (final BlockPos pos : WurstplusBlockInteractHelper.getSphere(WurstplusPlayerUtil.GetLocalPlayerPosFloored(), this.hole_range.get_value(1), this.hole_range.get_value(1), false, true, 0)) {
            if (!WurstplusHoleFill.mc.world.getBlockState(pos).getBlock().equals(Blocks.AIR)) {
                continue;
            }
            if (!WurstplusHoleFill.mc.world.getBlockState(pos.add(0, 1, 0)).getBlock().equals(Blocks.AIR)) {
                continue;
            }
            if (!WurstplusHoleFill.mc.world.getBlockState(pos.add(0, 2, 0)).getBlock().equals(Blocks.AIR)) {
                continue;
            }
            boolean possible = true;
            for (final BlockPos seems_blocks : new BlockPos[] { new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(-1, 0, 0) }) {
                final Block block = WurstplusHoleFill.mc.world.getBlockState(pos.add((Vec3i)seems_blocks)).getBlock();
                if (block != Blocks.BEDROCK && block != Blocks.OBSIDIAN && block != Blocks.ENDER_CHEST && block != Blocks.ANVIL) {
                    possible = false;
                    break;
                }
            }
            if (!possible) {
                continue;
            }
            this.holes.add(pos);
        }
    }
    
    private int find_in_hotbar() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusHoleFill.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stack.getItem()).getBlock();
                if (block instanceof BlockEnderChest) {
                    return i;
                }
                if (block instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    private boolean place_blocks(final BlockPos pos) {
        if (!WurstplusHoleFill.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
        }
        for (final EnumFacing side : EnumFacing.values()) {
            final BlockPos neighbor = pos.offset(side);
            final EnumFacing side2 = side.getOpposite();
            if (WurstplusBlockInteractHelper.canBeClicked(neighbor)) {
                final Block neighborPos;
                if (WurstplusBlockInteractHelper.blackList.contains(neighborPos = WurstplusHoleFill.mc.world.getBlockState(neighbor).getBlock())) {
                    WurstplusHoleFill.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusHoleFill.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    this.sneak = true;
                }
                final Vec3d hitVec = new Vec3d((Vec3i)neighbor).add(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                if (this.hole_rotate.get_value(true)) {
                    WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
                }
                WurstplusHoleFill.mc.playerController.processRightClickBlock(WurstplusHoleFill.mc.player, WurstplusHoleFill.mc.world, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                WurstplusHoleFill.mc.player.swingArm(EnumHand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }
}
