package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.*;
import java.util.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import me.travis.wurstplus.wurstplusmod.util.*;

public class WurstplusTrap extends WurstplusModule
{
    WurstplusSetting place_mode;
    WurstplusSetting blocks_per_tick;
    WurstplusSetting rotate;
    WurstplusSetting chad_mode;
    WurstplusSetting range;
    private final Vec3d[] offsets_default;
    private final Vec3d[] offsets_face;
    private final Vec3d[] offsets_feet;
    private final Vec3d[] offsets_extra;
    private String last_tick_target_name;
    private int player_hotbar_slot;
    private int last_hotbar_slot;
    private int offset_step;
    private int timeout_ticks;
    private int timeout_ticker;
    private int y_level;
    private boolean first_run;
    private boolean is_sneaking;
    
    public WurstplusTrap() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.place_mode = this.create("Place Mode", "TrapPlaceMode", "Extra", this.combobox("Extra", "Face", "Normal", "Feet"));
        this.blocks_per_tick = this.create("Speed", "TrapSpeed", 4, 0, 8);
        this.rotate = this.create("Rotation", "TrapRotation", true);
        this.chad_mode = this.create("Chad Mode", "TrapChadMode", true);
        this.range = this.create("Range", "TrapRange", 4, 1, 6);
        this.offsets_default = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 1.0), new Vec3d(1.0, 3.0, 0.0), new Vec3d(-1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 0.0) };
        this.offsets_face = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 1.0), new Vec3d(1.0, 3.0, 0.0), new Vec3d(-1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 0.0) };
        this.offsets_feet = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 1.0), new Vec3d(1.0, 3.0, 0.0), new Vec3d(-1.0, 3.0, 0.0), new Vec3d(0.0, 3.0, 0.0) };
        this.offsets_extra = new Vec3d[] { new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 2.0, -1.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(0.0, 2.0, 1.0), new Vec3d(-1.0, 2.0, 0.0), new Vec3d(0.0, 3.0, -1.0), new Vec3d(0.0, 3.0, 0.0), new Vec3d(0.0, 4.0, 0.0) };
        this.last_tick_target_name = "";
        this.player_hotbar_slot = -1;
        this.last_hotbar_slot = -1;
        this.offset_step = 0;
        this.timeout_ticks = 20;
        this.timeout_ticker = 0;
        this.first_run = true;
        this.is_sneaking = false;
        this.name = "Trap";
        this.tag = "Trap";
        this.description = "cover people in obsidian :o";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    public void enable() {
        this.timeout_ticker = 0;
        this.y_level = (int)Math.round(WurstplusTrap.mc.player.posY);
        this.first_run = true;
        this.player_hotbar_slot = WurstplusTrap.mc.player.inventory.currentItem;
        this.last_hotbar_slot = -1;
        if (this.find_obi_in_hotbar() == -1) {
            this.set_disable();
            WurstplusMessage.toggle_message(this);
        }
    }
    
    public void disable() {
        if (this.last_hotbar_slot != this.player_hotbar_slot && this.player_hotbar_slot != -1) {
            WurstplusTrap.mc.player.inventory.currentItem = this.player_hotbar_slot;
            if (this.is_sneaking) {
                WurstplusTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusTrap.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.is_sneaking = false;
            }
            this.player_hotbar_slot = -1;
            this.last_hotbar_slot = -1;
        }
    }
    
    @Override
    public void update() {
        if (this.timeout_ticker > this.timeout_ticks && this.chad_mode.get_value(true)) {
            this.timeout_ticker = 0;
            this.set_disable();
            return;
        }
        final EntityPlayer closest_target = this.find_closest_target();
        if (closest_target == null) {
            this.set_disable();
            WurstplusMessage.toggle_message(this);
            return;
        }
        if (this.chad_mode.get_value(true) && (int)Math.round(WurstplusTrap.mc.player.posY) != this.y_level) {
            this.set_disable();
            WurstplusMessage.toggle_message(this);
            return;
        }
        if (this.first_run) {
            this.first_run = false;
            this.last_tick_target_name = closest_target.getName();
        }
        else if (!this.last_tick_target_name.equals(closest_target.getName())) {
            this.last_tick_target_name = closest_target.getName();
            this.offset_step = 0;
        }
        final List<Vec3d> place_targets = new ArrayList<Vec3d>();
        if (this.place_mode.in("Normal")) {
            Collections.addAll(place_targets, this.offsets_default);
        }
        else if (this.place_mode.in("Extra")) {
            Collections.addAll(place_targets, this.offsets_extra);
        }
        else if (this.place_mode.in("Feet")) {
            Collections.addAll(place_targets, this.offsets_feet);
        }
        else {
            Collections.addAll(place_targets, this.offsets_face);
        }
        int blocks_placed = 0;
        while (blocks_placed < this.blocks_per_tick.get_value(1)) {
            if (this.offset_step >= place_targets.size()) {
                this.offset_step = 0;
                break;
            }
            final BlockPos offset_pos = new BlockPos((Vec3d)place_targets.get(this.offset_step));
            final BlockPos target_pos = new BlockPos(closest_target.getPositionVector()).down().add(offset_pos.getX(), offset_pos.getY(), offset_pos.getZ());
            boolean should_try_place = true;
            if (!WurstplusTrap.mc.world.getBlockState(target_pos).getMaterial().isReplaceable()) {
                should_try_place = false;
            }
            for (final Entity entity : WurstplusTrap.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(target_pos))) {
                if (!(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb)) {
                    should_try_place = false;
                    break;
                }
            }
            if (should_try_place && this.place_blocks(target_pos)) {
                ++blocks_placed;
            }
            ++this.offset_step;
        }
        if (blocks_placed > 0) {
            if (this.is_sneaking) {
                WurstplusTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusTrap.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.is_sneaking = false;
            }
            if (this.last_hotbar_slot != this.player_hotbar_slot && this.player_hotbar_slot != -1) {
                WurstplusTrap.mc.player.inventory.currentItem = this.player_hotbar_slot;
                this.last_hotbar_slot = this.player_hotbar_slot;
            }
        }
        ++this.timeout_ticker;
    }
    
    private boolean place_blocks(final BlockPos pos) {
        if (!WurstplusTrap.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
        }
        final Vec3d eye_pos = new Vec3d(WurstplusTrap.mc.player.posX, WurstplusTrap.mc.player.posY + WurstplusTrap.mc.player.getEyeHeight(), WurstplusTrap.mc.player.posZ);
        for (final EnumFacing side : EnumFacing.values()) {
            final BlockPos neighbor = pos.offset(side);
            final EnumFacing side2 = side.getOpposite();
            if (WurstplusBlockInteractHelper.canBeClicked(neighbor)) {
                final Vec3d hit_vec = new Vec3d((Vec3i)neighbor).add(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                if (eye_pos.distanceTo(hit_vec) <= this.range.get_value(1)) {
                    final int obi_slot = this.find_obi_in_hotbar();
                    if (obi_slot == -1) {
                        this.set_disable();
                        WurstplusMessage.toggle_message(this);
                        return false;
                    }
                    if (this.last_hotbar_slot != obi_slot) {
                        WurstplusTrap.mc.player.inventory.currentItem = obi_slot;
                        this.last_hotbar_slot = obi_slot;
                    }
                    final Block neighborPos;
                    if (WurstplusBlockInteractHelper.blackList.contains(neighborPos = WurstplusTrap.mc.world.getBlockState(neighbor).getBlock())) {
                        WurstplusTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusTrap.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                        this.is_sneaking = true;
                    }
                    final Vec3d hitVec = new Vec3d((Vec3i)neighbor).add(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                    if (this.rotate.get_value(true)) {
                        WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
                    }
                    WurstplusTrap.mc.playerController.processRightClickBlock(WurstplusTrap.mc.player, WurstplusTrap.mc.world, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                    WurstplusTrap.mc.player.swingArm(EnumHand.MAIN_HAND);
                    return true;
                }
            }
        }
        return false;
    }
    
    private int find_obi_in_hotbar() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusTrap.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stack.getItem()).getBlock();
                if (block instanceof BlockEnderChest) {
                    return i;
                }
                if (block instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public EntityPlayer find_closest_target() {
        if (WurstplusTrap.mc.world.playerEntities.isEmpty()) {
            return null;
        }
        EntityPlayer closestTarget = null;
        for (final EntityPlayer target : WurstplusTrap.mc.world.playerEntities) {
            if (target == WurstplusTrap.mc.player) {
                continue;
            }
            if (WurstplusFriendManager.isFriend(target.getName())) {
                continue;
            }
            if (!WurstplusEntityUtil.isLiving((Entity)target)) {
                continue;
            }
            if (target.getHealth() <= 0.0f) {
                continue;
            }
            if (closestTarget != null && WurstplusTrap.mc.player.getDistance((Entity)target) > WurstplusTrap.mc.player.getDistance((Entity)closestTarget)) {
                continue;
            }
            closestTarget = target;
        }
        return closestTarget;
    }
}
