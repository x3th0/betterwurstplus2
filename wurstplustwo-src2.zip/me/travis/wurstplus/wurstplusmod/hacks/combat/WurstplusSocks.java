package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.block.*;

public class WurstplusSocks extends WurstplusModule
{
    private boolean sneak;
    int new_slot;
    int old_slot;
    
    public WurstplusSocks() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.sneak = false;
        this.new_slot = 0;
        this.old_slot = 0;
        this.name = "Socks";
        this.tag = "Socks";
        this.description = "Protects your feet";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    public void enable() {
        if (WurstplusSocks.mc.player != null) {
            this.old_slot = WurstplusSocks.mc.player.inventory.currentItem;
            this.new_slot = this.find_in_hotbar();
            if (this.new_slot == -1) {
                this.set_active(false);
            }
        }
    }
    
    public void disable() {
        if (WurstplusSocks.mc.player != null) {
            if (this.new_slot != this.old_slot && this.old_slot != -1) {
                WurstplusSocks.mc.player.inventory.currentItem = this.old_slot;
            }
            if (this.sneak) {
                WurstplusSocks.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusSocks.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.sneak = false;
            }
            this.old_slot = -1;
            this.new_slot = -1;
        }
    }
    
    @Override
    public void update() {
        final int slot = this.find_in_hotbar();
        if (slot == -1) {
            return;
        }
        final BlockPos center_pos = WurstplusPlayerUtil.GetLocalPlayerPosFloored();
        final ArrayList<BlockPos> blocks_to_fill = new ArrayList<BlockPos>();
        switch (WurstplusPlayerUtil.GetFacing()) {
            case East: {
                blocks_to_fill.add(center_pos.east().east());
                blocks_to_fill.add(center_pos.east().east().up());
                blocks_to_fill.add(center_pos.east().east().east());
                blocks_to_fill.add(center_pos.east().east().east().up());
                break;
            }
            case North: {
                blocks_to_fill.add(center_pos.north().north());
                blocks_to_fill.add(center_pos.north().north().up());
                blocks_to_fill.add(center_pos.north().north().north());
                blocks_to_fill.add(center_pos.north().north().north().up());
                break;
            }
            case South: {
                blocks_to_fill.add(center_pos.south().south());
                blocks_to_fill.add(center_pos.south().south().up());
                blocks_to_fill.add(center_pos.south().south().south());
                blocks_to_fill.add(center_pos.south().south().south().up());
                break;
            }
            case West: {
                blocks_to_fill.add(center_pos.west().west());
                blocks_to_fill.add(center_pos.west().west().up());
                blocks_to_fill.add(center_pos.west().west().west());
                blocks_to_fill.add(center_pos.west().west().west().up());
                break;
            }
        }
        BlockPos pos_to_fill = null;
        for (final BlockPos pos : blocks_to_fill) {
            final WurstplusBlockInteractHelper.ValidResult result = WurstplusBlockInteractHelper.valid(pos);
            if (result != WurstplusBlockInteractHelper.ValidResult.Ok) {
                continue;
            }
            if (pos == null) {
                continue;
            }
            pos_to_fill = pos;
            break;
        }
        if (this.place_blocks(pos_to_fill) && this.new_slot != this.old_slot) {
            WurstplusSocks.mc.player.inventory.currentItem = this.old_slot;
        }
    }
    
    private boolean place_blocks(final BlockPos pos) {
        if (pos == null) {
            this.set_disable();
            WurstplusMessage.toggle_message(this);
            return false;
        }
        if (!WurstplusSocks.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
        }
        for (final EnumFacing side : EnumFacing.values()) {
            final BlockPos neighbor = pos.offset(side);
            final EnumFacing side2 = side.getOpposite();
            if (WurstplusBlockInteractHelper.canBeClicked(neighbor)) {
                WurstplusSocks.mc.player.inventory.currentItem = this.new_slot;
                final Block neighborPos;
                if (WurstplusBlockInteractHelper.blackList.contains(neighborPos = WurstplusSocks.mc.world.getBlockState(neighbor).getBlock())) {
                    WurstplusSocks.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusSocks.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    this.sneak = true;
                }
                final Vec3d hitVec = new Vec3d((Vec3i)neighbor).add(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
                WurstplusSocks.mc.playerController.processRightClickBlock(WurstplusSocks.mc.player, WurstplusSocks.mc.world, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                WurstplusSocks.mc.player.swingArm(EnumHand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }
    
    private int find_in_hotbar() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusSocks.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stack.getItem()).getBlock();
                if (block instanceof BlockEnderChest) {
                    return i;
                }
                if (block instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }
}
