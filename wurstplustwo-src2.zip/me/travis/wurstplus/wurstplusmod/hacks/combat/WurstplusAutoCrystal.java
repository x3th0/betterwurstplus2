package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import java.util.concurrent.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import java.util.function.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.play.server.*;
import me.travis.wurstplus.wurstplusmod.hacks.chat.*;
import java.awt.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import net.minecraft.world.*;
import net.minecraft.util.*;
import net.minecraft.init.*;
import net.minecraft.potion.*;
import java.util.*;
import net.minecraft.item.*;
import me.travis.wurstplus.*;
import net.minecraft.util.math.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.travis.draw.*;
import me.travis.wurstplus.wurstplusmod.util.*;

public class WurstplusAutoCrystal extends WurstplusModule
{
    WurstplusSetting debug;
    WurstplusSetting place_crystal;
    WurstplusSetting break_crystal;
    WurstplusSetting break_trys;
    WurstplusSetting anti_weakness;
    WurstplusSetting hit_range;
    WurstplusSetting place_range;
    WurstplusSetting hit_range_wall;
    WurstplusSetting place_delay;
    WurstplusSetting break_delay;
    WurstplusSetting min_player_place;
    WurstplusSetting min_player_break;
    WurstplusSetting max_self_damage;
    WurstplusSetting rotate_mode;
    WurstplusSetting raytrace;
    WurstplusSetting auto_switch;
    WurstplusSetting anti_suicide;
    WurstplusSetting fast_mode;
    WurstplusSetting client_side;
    WurstplusSetting jumpy_mode;
    WurstplusSetting anti_stuck;
    WurstplusSetting endcrystal;
    WurstplusSetting faceplace_mode;
    WurstplusSetting faceplace_mode_damage;
    WurstplusSetting fuck_armor_mode;
    WurstplusSetting fuck_armor_mode_precent;
    WurstplusSetting stop_while_mining;
    WurstplusSetting faceplace_check;
    WurstplusSetting swing;
    WurstplusSetting render_mode;
    WurstplusSetting old_render;
    WurstplusSetting r;
    WurstplusSetting g;
    WurstplusSetting b;
    WurstplusSetting a;
    WurstplusSetting a_out;
    WurstplusSetting rainbow_mode;
    WurstplusSetting sat;
    WurstplusSetting brightness;
    WurstplusSetting render_damage;
    WurstplusSetting attempt_chain;
    WurstplusSetting chain_length;
    private final ConcurrentHashMap<EntityEnderCrystal, Integer> attacked_crystals;
    private final WurstplusTimer remove_visual_timer;
    private final WurstplusTimer chain_timer;
    private EntityPlayer autoez_target;
    private String detail_name;
    private int detail_hp;
    private ArrayList<BlockPos> broken_pos;
    private BlockPos render_block;
    private double render_damage_value;
    private float yaw;
    private float pitch;
    private boolean already_attacking;
    private boolean place_timeout_flag;
    private boolean is_rotating;
    private boolean did_anything;
    private boolean outline;
    private boolean solid;
    private int chain_step;
    private int current_chain_index;
    private int place_timeout;
    private int break_timeout;
    private int break_delay_counter;
    private int place_delay_counter;
    @EventHandler
    private Listener<WurstplusEventEntityRemoved> on_entity_removed;
    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> send_listener;
    @EventHandler
    private Listener<WurstplusEventMotionUpdate> on_movement;
    @EventHandler
    private final Listener<WurstplusEventPacket.ReceivePacket> receive_listener;
    
    public WurstplusAutoCrystal() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.debug = this.create("Debug", "CaDebug", false);
        this.place_crystal = this.create("Place", "CaPlace", true);
        this.break_crystal = this.create("Break", "CaBreak", true);
        this.break_trys = this.create("Break Attempts", "CaBreakAttempts", 2, 1, 6);
        this.anti_weakness = this.create("Anti-Weakness", "CaAntiWeakness", true);
        this.hit_range = this.create("Hit Range", "CaHitRange", 5.5, 1.0, 6.0);
        this.place_range = this.create("Place Range", "CaPlaceRange", 5.5, 1.0, 6.0);
        this.hit_range_wall = this.create("Range Wall", "CaRangeWall", 4.0, 1.0, 6.0);
        this.place_delay = this.create("Place Delay", "CaPlaceDelay", 0, 0, 10);
        this.break_delay = this.create("Break Delay", "CaBreakDelay", 2, 0, 10);
        this.min_player_place = this.create("Min Enemy Place", "CaMinEnemyPlace", 8, 0, 20);
        this.min_player_break = this.create("Min Enemy Break", "CaMinEnemyBreak", 6, 0, 20);
        this.max_self_damage = this.create("Max Self Damage", "CaMaxSelfDamage", 6, 0, 20);
        this.rotate_mode = this.create("Rotate", "CaRotateMode", "Off", this.combobox("Off", "Old", "Const", "Good"));
        this.raytrace = this.create("Raytrace", "CaRaytrace", false);
        this.auto_switch = this.create("Auto Switch", "CaAutoSwitch", true);
        this.anti_suicide = this.create("Anti Suicide", "CaAntiSuicide", true);
        this.fast_mode = this.create("Fast Mode", "CaSpeed", true);
        this.client_side = this.create("Client Side", "CaClientSide", false);
        this.jumpy_mode = this.create("Jumpy Mode", "CaJumpyMode", false);
        this.anti_stuck = this.create("Anti Stuck", "CaAntiStuck", false);
        this.endcrystal = this.create("1.13 Mode", "CaThirteen", false);
        this.faceplace_mode = this.create("Tabbott Mode", "CaTabbottMode", true);
        this.faceplace_mode_damage = this.create("T Health", "CaTabbottModeHealth", 8, 0, 36);
        this.fuck_armor_mode = this.create("Armor Destroy", "CaArmorDestory", true);
        this.fuck_armor_mode_precent = this.create("Armor %", "CaArmorPercent", 10, 0, 100);
        this.stop_while_mining = this.create("Stop While Mining", "CaStopWhileMining", false);
        this.faceplace_check = this.create("No Sword FP", "CaJumpyFaceMode", false);
        this.swing = this.create("Swing", "CaSwing", "Mainhand", this.combobox("Mainhand", "Offhand", "Both", "None"));
        this.render_mode = this.create("Render", "CaRenderMode", "Pretty", this.combobox("Pretty", "Solid", "Outline", "None"));
        this.old_render = this.create("Old Render", "CaOldRender", false);
        this.r = this.create("R", "CaR", 255, 0, 255);
        this.g = this.create("G", "CaG", 255, 0, 255);
        this.b = this.create("B", "CaB", 255, 0, 255);
        this.a = this.create("A", "CaA", 100, 0, 255);
        this.a_out = this.create("Outline A", "CaOutlineA", 255, 0, 255);
        this.rainbow_mode = this.create("Rainbow", "CaRainbow", false);
        this.sat = this.create("Satiation", "CaSatiation", 0.8, 0.0, 1.0);
        this.brightness = this.create("Brightness", "CaBrightness", 0.8, 0.0, 1.0);
        this.render_damage = this.create("Render Damage", "RenderDamage", true);
        this.attempt_chain = this.create("Chain Mode", "CaChainMode", false);
        this.chain_length = this.create("Chain Length", "CaChainLength", 3, 1, 6);
        this.attacked_crystals = new ConcurrentHashMap<EntityEnderCrystal, Integer>();
        this.remove_visual_timer = new WurstplusTimer();
        this.chain_timer = new WurstplusTimer();
        this.autoez_target = null;
        this.detail_name = null;
        this.detail_hp = 0;
        this.already_attacking = false;
        this.place_timeout_flag = false;
        this.chain_step = 0;
        this.current_chain_index = 0;
        this.on_entity_removed = new Listener<WurstplusEventEntityRemoved>(event -> {
            if (event.get_entity() instanceof EntityEnderCrystal) {
                this.attacked_crystals.remove(event.get_entity());
            }
            return;
        }, (Predicate<WurstplusEventEntityRemoved>[])new Predicate[0]);
        final CPacketPlayer p;
        final CPacketPlayerTryUseItemOnBlock p2;
        this.send_listener = new Listener<WurstplusEventPacket.SendPacket>(event -> {
            if (event.get_packet() instanceof CPacketPlayer && this.is_rotating && this.rotate_mode.in("Old")) {
                if (this.debug.get_value(true)) {
                    WurstplusMessage.send_client_message("Rotating");
                }
                p = (CPacketPlayer)event.get_packet();
                p.yaw = this.yaw;
                p.pitch = this.pitch;
                this.is_rotating = false;
            }
            if (event.get_packet() instanceof CPacketPlayerTryUseItemOnBlock && this.is_rotating && this.rotate_mode.in("Old")) {
                if (this.debug.get_value(true)) {
                    WurstplusMessage.send_client_message("Rotating");
                }
                p2 = (CPacketPlayerTryUseItemOnBlock)event.get_packet();
                p2.facingX = this.render_block.getX();
                p2.facingY = this.render_block.getY();
                p2.facingZ = this.render_block.getZ();
                this.is_rotating = false;
            }
            return;
        }, (Predicate<WurstplusEventPacket.SendPacket>[])new Predicate[0]);
        this.on_movement = new Listener<WurstplusEventMotionUpdate>(event -> {
            if (event.stage == 0 && (this.rotate_mode.in("Good") || this.rotate_mode.in("Const"))) {
                if (this.debug.get_value(true)) {
                    WurstplusMessage.send_client_message("updating rotation");
                }
                WurstplusPosManager.updatePosition();
                WurstplusRotationUtil.updateRotations();
                this.do_ca();
            }
            if (event.stage == 1 && (this.rotate_mode.in("Good") || this.rotate_mode.in("Const"))) {
                if (this.debug.get_value(true)) {
                    WurstplusMessage.send_client_message("resetting rotation");
                }
                WurstplusPosManager.restorePosition();
                WurstplusRotationUtil.restoreRotations();
            }
            return;
        }, (Predicate<WurstplusEventMotionUpdate>[])new Predicate[0]);
        final SPacketSoundEffect packet;
        final Iterator<Entity> iterator;
        Entity e;
        final SPacketExplosion p3;
        final BlockPos pos;
        this.receive_listener = new Listener<WurstplusEventPacket.ReceivePacket>(event -> {
            if (event.get_packet() instanceof SPacketSoundEffect) {
                packet = (SPacketSoundEffect)event.get_packet();
                if (packet.getCategory() == SoundCategory.BLOCKS && packet.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE) {
                    WurstplusAutoCrystal.mc.world.loadedEntityList.iterator();
                    while (iterator.hasNext()) {
                        e = iterator.next();
                        if (e instanceof EntityEnderCrystal && e.getDistance(packet.getX(), packet.getY(), packet.getZ()) <= 6.0) {
                            e.setDead();
                        }
                    }
                }
            }
            if (event.get_packet() instanceof SPacketExplosion) {
                p3 = (SPacketExplosion)event.get_packet();
                pos = new BlockPos(p3.getX(), p3.getY(), p3.getZ()).down();
                this.broken_pos.remove(pos);
            }
            return;
        }, (Predicate<WurstplusEventPacket.ReceivePacket>[])new Predicate[0]);
        this.name = "Auto Crystal";
        this.tag = "AutoCrystal";
        this.description = "People go boom boom";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    public void do_ca() {
        this.did_anything = false;
        if (WurstplusAutoCrystal.mc.player == null || WurstplusAutoCrystal.mc.world == null) {
            return;
        }
        if (this.rainbow_mode.get_value(true)) {
            this.cycle_rainbow();
        }
        if (this.remove_visual_timer.passedMs(1000L)) {
            this.remove_visual_timer.reset();
            this.attacked_crystals.clear();
        }
        if (this.check_pause()) {
            return;
        }
        if (this.place_crystal.get_value(true) && this.place_delay_counter > this.place_timeout) {
            this.place_crystal();
        }
        if (this.break_crystal.get_value(true) && this.break_delay_counter > this.break_timeout) {
            this.break_crystal();
        }
        if (!this.did_anything) {
            if (this.old_render.get_value(true)) {
                this.render_block = null;
            }
            this.autoez_target = null;
            this.is_rotating = false;
        }
        if (this.autoez_target != null) {
            WurstplusAutoEz.add_target(this.autoez_target.getName());
            this.detail_name = this.autoez_target.getName();
            this.detail_hp = Math.round(this.autoez_target.getHealth() + this.autoez_target.getAbsorptionAmount());
        }
        if (this.chain_timer.passedMs(1000L)) {
            this.chain_timer.reset();
            this.chain_step = 0;
        }
        ++this.break_delay_counter;
        ++this.place_delay_counter;
    }
    
    @Override
    public void update() {
        if (this.rotate_mode.in("Off") || this.rotate_mode.in("Old")) {
            this.do_ca();
        }
    }
    
    public void cycle_rainbow() {
        final float[] tick_color = { System.currentTimeMillis() % 11520L / 11520.0f };
        final int color_rgb_o = Color.HSBtoRGB(tick_color[0], this.sat.get_value(1), this.brightness.get_value(1));
        this.r.set_value(color_rgb_o >> 16 & 0xFF);
        this.g.set_value(color_rgb_o >> 8 & 0xFF);
        this.b.set_value(color_rgb_o & 0xFF);
    }
    
    public EntityEnderCrystal get_best_crystal() {
        double best_damage = 0.0;
        final double maximum_damage_self = this.max_self_damage.get_value(1);
        double best_distance = 0.0;
        EntityEnderCrystal best_crystal = null;
        for (final Entity c : WurstplusAutoCrystal.mc.world.loadedEntityList) {
            if (!(c instanceof EntityEnderCrystal)) {
                continue;
            }
            final EntityEnderCrystal crystal = (EntityEnderCrystal)c;
            if (WurstplusAutoCrystal.mc.player.getDistance((Entity)crystal) > (WurstplusAutoCrystal.mc.player.canEntityBeSeen((Entity)crystal) ? this.hit_range.get_value(1) : this.hit_range_wall.get_value(1))) {
                continue;
            }
            if (!WurstplusAutoCrystal.mc.player.canEntityBeSeen((Entity)crystal) && this.raytrace.get_value(true)) {
                continue;
            }
            if (crystal.isDead) {
                continue;
            }
            if (this.attacked_crystals.containsKey(crystal) && this.attacked_crystals.get(crystal) > 5 && this.anti_stuck.get_value(true)) {
                continue;
            }
            for (final Entity player : WurstplusAutoCrystal.mc.world.playerEntities) {
                if (player != WurstplusAutoCrystal.mc.player) {
                    if (!(player instanceof EntityPlayer)) {
                        continue;
                    }
                    if (WurstplusFriendManager.isFriend(player.getName())) {
                        continue;
                    }
                    if (player.getDistance((Entity)WurstplusAutoCrystal.mc.player) >= 11.0f) {
                        continue;
                    }
                    final EntityPlayer target = (EntityPlayer)player;
                    if (target.isDead) {
                        continue;
                    }
                    if (target.getHealth() <= 0.0f) {
                        continue;
                    }
                    final boolean no_place = this.faceplace_check.get_value(true) && WurstplusAutoCrystal.mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_SWORD;
                    double minimum_damage;
                    if ((target.getHealth() < this.faceplace_mode_damage.get_value(1) && this.faceplace_mode.get_value(true) && !no_place) || (this.get_armor_fucker(target) && !no_place)) {
                        minimum_damage = 2.0;
                    }
                    else {
                        minimum_damage = this.min_player_break.get_value(1);
                    }
                    final double target_damage = WurstplusCrystalUtil.calculateDamage((World)WurstplusAutoCrystal.mc.world, crystal, (Entity)target);
                    if (target_damage < minimum_damage) {
                        continue;
                    }
                    final double self_damage = WurstplusCrystalUtil.calculateDamage((World)WurstplusAutoCrystal.mc.world, crystal, (Entity)WurstplusAutoCrystal.mc.player);
                    if (self_damage > maximum_damage_self) {
                        continue;
                    }
                    if (this.anti_suicide.get_value(true) && WurstplusAutoCrystal.mc.player.getHealth() + WurstplusAutoCrystal.mc.player.getAbsorptionAmount() - self_damage <= 0.5) {
                        continue;
                    }
                    if (target_damage <= best_damage || this.jumpy_mode.get_value(true)) {
                        continue;
                    }
                    this.autoez_target = target;
                    best_damage = target_damage;
                    best_crystal = crystal;
                }
            }
            if (!this.jumpy_mode.get_value(true) || WurstplusAutoCrystal.mc.player.getDistanceSq((Entity)crystal) <= best_distance) {
                continue;
            }
            best_distance = WurstplusAutoCrystal.mc.player.getDistanceSq((Entity)crystal);
            best_crystal = crystal;
        }
        return best_crystal;
    }
    
    public BlockPos get_best_block() {
        if (this.get_best_crystal() != null && !this.fast_mode.get_value(true)) {
            this.place_timeout_flag = true;
            return null;
        }
        if (this.place_timeout_flag) {
            this.place_timeout_flag = false;
            return null;
        }
        List<Pair<Double, BlockPos>> damage_blocks = new ArrayList<Pair<Double, BlockPos>>();
        double best_damage = 0.0;
        final double maximum_damage_self = this.max_self_damage.get_value(1);
        BlockPos best_block = null;
        final List<BlockPos> blocks = BlockUtil.possiblePlacePositions(this.place_range.get_value(1), this.endcrystal.get_value(true), true);
        for (final Entity player : WurstplusAutoCrystal.mc.world.playerEntities) {
            if (WurstplusFriendManager.isFriend(player.getName())) {
                continue;
            }
            for (final BlockPos block : blocks) {
                if (player != WurstplusAutoCrystal.mc.player) {
                    if (!(player instanceof EntityPlayer)) {
                        continue;
                    }
                    if (player.getDistance((Entity)WurstplusAutoCrystal.mc.player) >= 11.0f) {
                        continue;
                    }
                    if (!WurstplusBlockUtil.rayTracePlaceCheck(block, this.raytrace.get_value(true))) {
                        continue;
                    }
                    if (!WurstplusBlockUtil.canSeeBlock(block) && WurstplusAutoCrystal.mc.player.getDistance((double)block.getX(), (double)block.getY(), (double)block.getZ()) > this.hit_range_wall.get_value(1)) {
                        continue;
                    }
                    final EntityPlayer target = (EntityPlayer)player;
                    if (target.isDead) {
                        continue;
                    }
                    if (target.getHealth() <= 0.0f) {
                        continue;
                    }
                    final boolean no_place = this.faceplace_check.get_value(true) && WurstplusAutoCrystal.mc.player.getHeldItemMainhand().getItem() == Items.DIAMOND_SWORD;
                    double minimum_damage;
                    if ((target.getHealth() < this.faceplace_mode_damage.get_value(1) && this.faceplace_mode.get_value(true) && !no_place) || (this.get_armor_fucker(target) && !no_place)) {
                        minimum_damage = 2.0;
                    }
                    else {
                        minimum_damage = this.min_player_place.get_value(1);
                    }
                    final double target_damage = WurstplusCrystalUtil.calculateDamage((World)WurstplusAutoCrystal.mc.world, block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5, (Entity)target);
                    if (target_damage < minimum_damage) {
                        continue;
                    }
                    final double self_damage = WurstplusCrystalUtil.calculateDamage((World)WurstplusAutoCrystal.mc.world, block.getX() + 0.5, block.getY() + 1.0, block.getZ() + 0.5, (Entity)WurstplusAutoCrystal.mc.player);
                    if (self_damage > maximum_damage_self) {
                        continue;
                    }
                    if (this.anti_suicide.get_value(true) && WurstplusAutoCrystal.mc.player.getHealth() + WurstplusAutoCrystal.mc.player.getAbsorptionAmount() - self_damage <= 0.5) {
                        continue;
                    }
                    if (this.attempt_chain.get_value(true) && this.chain_step > 0) {
                        damage_blocks.add(new Pair<Double, BlockPos>(best_damage, best_block));
                        this.autoez_target = target;
                    }
                    else {
                        if (target_damage <= best_damage) {
                            continue;
                        }
                        best_damage = target_damage;
                        best_block = block;
                        this.autoez_target = target;
                    }
                }
            }
        }
        blocks.clear();
        if (this.chain_step == 1) {
            this.current_chain_index = this.chain_length.get_value(1);
        }
        else if (this.chain_step > 1) {
            --this.current_chain_index;
        }
        this.render_damage_value = best_damage;
        this.render_block = best_block;
        damage_blocks = this.sort_best_blocks(damage_blocks);
        if (!this.attempt_chain.get_value(true)) {
            return best_block;
        }
        if (damage_blocks.size() == 0) {
            return null;
        }
        if (damage_blocks.size() < this.current_chain_index) {
            return damage_blocks.get(0).getValue();
        }
        return damage_blocks.get(this.current_chain_index).getValue();
    }
    
    public List<Pair<Double, BlockPos>> sort_best_blocks(final List<Pair<Double, BlockPos>> list) {
        final List<Pair<Double, BlockPos>> new_list = new ArrayList<Pair<Double, BlockPos>>();
        double damage_cap = 1000.0;
        for (int i = 0; i < list.size(); ++i) {
            final double biggest_dam = 0.0;
            Pair<Double, BlockPos> best_pair = null;
            for (final Pair<Double, BlockPos> pair : list) {
                if (pair.getKey() > biggest_dam && pair.getKey() < damage_cap) {
                    best_pair = pair;
                }
            }
            if (best_pair != null) {
                damage_cap = best_pair.getKey();
                new_list.add(best_pair);
            }
        }
        return new_list;
    }
    
    public void place_crystal() {
        final BlockPos target_block = this.get_best_block();
        if (target_block == null) {
            return;
        }
        this.place_delay_counter = 0;
        this.already_attacking = false;
        boolean offhand_check = false;
        if (WurstplusAutoCrystal.mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL) {
            if (WurstplusAutoCrystal.mc.player.getHeldItemMainhand().getItem() != Items.END_CRYSTAL && this.auto_switch.get_value(true)) {
                if (this.find_crystals_hotbar() == -1) {
                    return;
                }
                WurstplusAutoCrystal.mc.player.inventory.currentItem = this.find_crystals_hotbar();
                return;
            }
        }
        else {
            offhand_check = true;
        }
        if (this.debug.get_value(true)) {
            WurstplusMessage.send_client_message("placing");
        }
        ++this.chain_step;
        this.did_anything = true;
        this.rotate_to_pos(target_block);
        this.chain_timer.reset();
        WurstplusBlockUtil.placeCrystalOnBlock(target_block, offhand_check ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
    }
    
    public boolean get_armor_fucker(final EntityPlayer p) {
        for (final ItemStack stack : p.getArmorInventoryList()) {
            if (stack == null || stack.getItem() == Items.AIR) {
                return false;
            }
            final float armor_percent = (stack.getMaxDamage() - stack.getItemDamage()) / stack.getMaxDamage() * 100.0f;
            if (this.fuck_armor_mode.get_value(true) && this.fuck_armor_mode_precent.get_value(1) >= armor_percent) {
                return true;
            }
        }
        return false;
    }
    
    public void break_crystal() {
        final EntityEnderCrystal crystal = this.get_best_crystal();
        if (crystal == null) {
            return;
        }
        if (this.anti_weakness.get_value(true) && WurstplusAutoCrystal.mc.player.isPotionActive(MobEffects.WEAKNESS)) {
            boolean should_weakness = true;
            if (WurstplusAutoCrystal.mc.player.isPotionActive(MobEffects.STRENGTH) && Objects.requireNonNull(WurstplusAutoCrystal.mc.player.getActivePotionEffect(MobEffects.STRENGTH)).getAmplifier() == 2) {
                should_weakness = false;
            }
            if (should_weakness) {
                if (!this.already_attacking) {
                    this.already_attacking = true;
                }
                int new_slot = -1;
                for (int i = 0; i < 9; ++i) {
                    final ItemStack stack = WurstplusAutoCrystal.mc.player.inventory.getStackInSlot(i);
                    if (stack.getItem() instanceof ItemSword || stack.getItem() instanceof ItemTool) {
                        new_slot = i;
                        WurstplusAutoCrystal.mc.playerController.updateController();
                        break;
                    }
                }
                if (new_slot != -1) {
                    WurstplusAutoCrystal.mc.player.inventory.currentItem = new_slot;
                }
            }
        }
        if (this.debug.get_value(true)) {
            WurstplusMessage.send_client_message("attacking");
        }
        this.did_anything = true;
        this.rotate_to((Entity)crystal);
        for (int j = 0; j < this.break_trys.get_value(1); ++j) {
            WurstplusEntityUtil.attackEntity((Entity)crystal, false, this.swing);
        }
        this.add_attacked_crystal(crystal);
        if (this.client_side.get_value(true) && crystal.isEntityAlive()) {
            crystal.setDead();
        }
        this.break_delay_counter = 0;
    }
    
    public boolean check_pause() {
        if (this.find_crystals_hotbar() == -1 && WurstplusAutoCrystal.mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL) {
            return true;
        }
        if (this.stop_while_mining.get_value(true) && WurstplusAutoCrystal.mc.gameSettings.keyBindAttack.isKeyDown() && WurstplusAutoCrystal.mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe) {
            if (this.old_render.get_value(true)) {
                this.render_block = null;
            }
            return true;
        }
        if (Wurstplus.get_module_manager().get_module_with_tag("Surround").is_active()) {
            if (this.old_render.get_value(true)) {
                this.render_block = null;
            }
            return true;
        }
        if (Wurstplus.get_module_manager().get_module_with_tag("HoleFill").is_active()) {
            if (this.old_render.get_value(true)) {
                this.render_block = null;
            }
            return true;
        }
        if (Wurstplus.get_module_manager().get_module_with_tag("Trap").is_active()) {
            if (this.old_render.get_value(true)) {
                this.render_block = null;
            }
            return true;
        }
        return false;
    }
    
    private int find_crystals_hotbar() {
        for (int i = 0; i < 9; ++i) {
            if (WurstplusAutoCrystal.mc.player.inventory.getStackInSlot(i).getItem() == Items.END_CRYSTAL) {
                return i;
            }
        }
        return -1;
    }
    
    private void add_attacked_crystal(final EntityEnderCrystal crystal) {
        if (this.attacked_crystals.containsKey(crystal)) {
            final int value = this.attacked_crystals.get(crystal);
            this.attacked_crystals.put(crystal, value + 1);
        }
        else {
            this.attacked_crystals.put(crystal, 1);
        }
    }
    
    public void rotate_to_pos(final BlockPos pos) {
        float[] angle;
        if (this.rotate_mode.in("Const")) {
            angle = WurstplusMathUtil.calcAngle(WurstplusAutoCrystal.mc.player.getPositionEyes(WurstplusAutoCrystal.mc.getRenderPartialTicks()), new Vec3d((double)(pos.getX() + 0.5f), (double)(pos.getY() + 0.5f), (double)(pos.getZ() + 0.5f)));
        }
        else {
            angle = WurstplusMathUtil.calcAngle(WurstplusAutoCrystal.mc.player.getPositionEyes(WurstplusAutoCrystal.mc.getRenderPartialTicks()), new Vec3d((double)(pos.getX() + 0.5f), (double)(pos.getY() - 0.5f), (double)(pos.getZ() + 0.5f)));
        }
        if (this.rotate_mode.in("Off")) {
            this.is_rotating = false;
        }
        if (this.rotate_mode.in("Good") || this.rotate_mode.in("Const")) {
            WurstplusRotationUtil.setPlayerRotations(angle[0], angle[1]);
        }
        if (this.rotate_mode.in("Old")) {
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.is_rotating = true;
        }
    }
    
    public void rotate_to(final Entity entity) {
        final float[] angle = WurstplusMathUtil.calcAngle(WurstplusAutoCrystal.mc.player.getPositionEyes(WurstplusAutoCrystal.mc.getRenderPartialTicks()), entity.getPositionVector());
        if (this.rotate_mode.in("Off")) {
            this.is_rotating = false;
        }
        if (this.rotate_mode.in("Good")) {
            WurstplusRotationUtil.setPlayerRotations(angle[0], angle[1]);
        }
        if (this.rotate_mode.in("Old") || this.rotate_mode.in("Cont")) {
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.is_rotating = true;
        }
    }
    
    @Override
    public void render(final WurstplusEventRender event) {
        if (this.render_block == null) {
            return;
        }
        if (this.render_mode.in("None")) {
            return;
        }
        if (this.render_mode.in("Pretty")) {
            this.outline = true;
            this.solid = true;
        }
        if (this.render_mode.in("Solid")) {
            this.outline = false;
            this.solid = true;
        }
        if (this.render_mode.in("Outline")) {
            this.outline = true;
            this.solid = false;
        }
        if (this.solid) {
            TravisRenderHelp.prepare("quads");
            TravisRenderHelp.draw_cube(TravisRenderHelp.get_buffer_build(), this.render_block.getX(), this.render_block.getY(), this.render_block.getZ(), 1.0f, 1.0f, 1.0f, this.r.get_value(1), this.g.get_value(1), this.b.get_value(1), this.a.get_value(1), "all");
            TravisRenderHelp.release();
        }
        if (this.outline) {
            TravisRenderHelp.prepare("lines");
            TravisRenderHelp.draw_cube_line(TravisRenderHelp.get_buffer_build(), this.render_block.getX(), this.render_block.getY(), this.render_block.getZ(), 1.0f, 1.0f, 1.0f, this.r.get_value(1), this.g.get_value(1), this.b.get_value(1), this.a_out.get_value(1), "all");
            TravisRenderHelp.release();
        }
        if (this.render_damage.get_value(true)) {
            WurstplusRenderUtil.drawText(this.render_block, ((Math.floor(this.render_damage_value) == this.render_damage_value) ? ((int)this.render_damage_value) : String.format("%.1f", this.render_damage_value)) + "");
        }
    }
    
    public void enable() {
        this.place_timeout = this.place_delay.get_value(1);
        this.break_timeout = this.break_delay.get_value(1);
        this.place_timeout_flag = false;
        this.is_rotating = false;
        this.autoez_target = null;
        this.chain_step = 0;
        this.current_chain_index = 0;
        this.chain_timer.reset();
        this.remove_visual_timer.reset();
        this.broken_pos = new ArrayList<BlockPos>();
        this.detail_name = null;
        this.detail_hp = 20;
    }
    
    public void disable() {
        this.render_block = null;
        this.autoez_target = null;
    }
    
    @Override
    public String detail_option() {
        return (this.detail_name != null) ? (this.detail_name + " | " + this.detail_hp) : "None";
    }
}
