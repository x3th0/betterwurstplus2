package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import java.util.function.*;

public class WurstplusCriticals extends WurstplusModule
{
    WurstplusSetting mode;
    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> listener;
    
    public WurstplusCriticals() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.mode = this.create("Mode", "CriticalsMode", "Packet", this.combobox("Packet", "Jump"));
        final CPacketUseEntity event_entity;
        this.listener = new Listener<WurstplusEventPacket.SendPacket>(event -> {
            if (event.get_packet() instanceof CPacketUseEntity) {
                event_entity = (CPacketUseEntity)event.get_packet();
                if (event_entity.getAction() == CPacketUseEntity.Action.ATTACK && WurstplusCriticals.mc.player.onGround) {
                    if (this.mode.in("Packet")) {
                        WurstplusCriticals.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusCriticals.mc.player.posX, WurstplusCriticals.mc.player.posY + 0.10000000149011612, WurstplusCriticals.mc.player.posZ, false));
                        WurstplusCriticals.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusCriticals.mc.player.posX, WurstplusCriticals.mc.player.posY, WurstplusCriticals.mc.player.posZ, false));
                    }
                    else if (this.mode.in("Jump")) {
                        WurstplusCriticals.mc.player.jump();
                    }
                }
            }
            return;
        }, (Predicate<WurstplusEventPacket.SendPacket>[])new Predicate[0]);
        this.name = "Criticals";
        this.tag = "Criticals";
        this.description = "You can hit with criticals when attack.";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public String detail_option() {
        return this.mode.get_current_value();
    }
}
