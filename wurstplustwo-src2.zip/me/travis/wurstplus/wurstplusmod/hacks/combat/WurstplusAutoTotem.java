package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;

public class WurstplusAutoTotem extends WurstplusModule
{
    WurstplusSetting delay;
    private boolean switching;
    private int last_slot;
    
    public WurstplusAutoTotem() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.delay = this.create("Delay", "TotemDelay", false);
        this.switching = false;
        this.name = "Auto Totem";
        this.tag = "AutoTotem";
        this.description = "put totem in offhand";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public void update() {
        if (WurstplusAutoTotem.mc.currentScreen == null || WurstplusAutoTotem.mc.currentScreen instanceof GuiInventory) {
            if (this.switching) {
                this.swap_items(this.last_slot, 2);
                return;
            }
            if (WurstplusAutoTotem.mc.player.getHeldItemOffhand().getItem() == Items.AIR) {
                this.swap_items(this.get_item_slot(), this.delay.get_value(true) ? 1 : 0);
            }
        }
    }
    
    private int get_item_slot() {
        if (Items.TOTEM_OF_UNDYING == WurstplusAutoTotem.mc.player.getHeldItemOffhand().getItem()) {
            return -1;
        }
        int i = 36;
        while (i >= 0) {
            final Item item = WurstplusAutoTotem.mc.player.inventory.getStackInSlot(i).getItem();
            if (item == Items.TOTEM_OF_UNDYING) {
                if (i < 9) {
                    return -1;
                }
                return i;
            }
            else {
                --i;
            }
        }
        return -1;
    }
    
    public void swap_items(final int slot, final int step) {
        if (slot == -1) {
            return;
        }
        if (step == 0) {
            WurstplusAutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)WurstplusAutoTotem.mc.player);
            WurstplusAutoTotem.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)WurstplusAutoTotem.mc.player);
            WurstplusAutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)WurstplusAutoTotem.mc.player);
        }
        if (step == 1) {
            WurstplusAutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)WurstplusAutoTotem.mc.player);
            this.switching = true;
            this.last_slot = slot;
        }
        if (step == 2) {
            WurstplusAutoTotem.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)WurstplusAutoTotem.mc.player);
            WurstplusAutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)WurstplusAutoTotem.mc.player);
            this.switching = false;
        }
        WurstplusAutoTotem.mc.playerController.updateController();
    }
}
