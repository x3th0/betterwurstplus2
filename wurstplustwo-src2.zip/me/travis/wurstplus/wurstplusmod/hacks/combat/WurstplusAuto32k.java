package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.util.math.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.client.gui.*;
import net.minecraft.entity.player.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import net.minecraft.enchantment.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.client.gui.inventory.*;

public class WurstplusAuto32k extends WurstplusModule
{
    private BlockPos pos;
    private int hopper_slot;
    private int redstone_slot;
    private int shulker_slot;
    private int ticks_past;
    private int[] rot;
    private boolean setup;
    private boolean place_redstone;
    private boolean dispenser_done;
    WurstplusSetting place_mode;
    WurstplusSetting delay;
    WurstplusSetting rotate;
    WurstplusSetting debug;
    
    public WurstplusAuto32k() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.place_mode = this.create("Place Mode", "AutotkPlaceMode", "Auto", this.combobox("Auto", "Looking", "Hopper"));
        this.delay = this.create("Delay", "AutotkDelay", 4, 0, 10);
        this.rotate = this.create("Rotate", "Autotkrotate", false);
        this.debug = this.create("Debug", "AutotkDebug", false);
        this.name = "Auto TTk";
        this.tag = "AutoTTk";
        this.description = "fastest in the west";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    protected void enable() {
        this.ticks_past = 0;
        this.setup = false;
        this.dispenser_done = false;
        this.place_redstone = false;
        this.hopper_slot = -1;
        int dispenser_slot = -1;
        this.redstone_slot = -1;
        this.shulker_slot = -1;
        int block_slot = -1;
        for (int i = 0; i < 9; ++i) {
            final Item item = WurstplusAuto32k.mc.player.inventory.getStackInSlot(i).getItem();
            if (item == Item.getItemFromBlock((Block)Blocks.HOPPER)) {
                this.hopper_slot = i;
            }
            else if (item == Item.getItemFromBlock(Blocks.DISPENSER)) {
                dispenser_slot = i;
            }
            else if (item == Item.getItemFromBlock(Blocks.REDSTONE_BLOCK)) {
                this.redstone_slot = i;
            }
            else if (item instanceof ItemShulkerBox) {
                this.shulker_slot = i;
            }
            else if (item instanceof ItemBlock) {
                block_slot = i;
            }
        }
        if ((this.hopper_slot == -1 || dispenser_slot == -1 || this.redstone_slot == -1 || this.shulker_slot == -1 || block_slot == -1) && !this.place_mode.in("Hopper")) {
            WurstplusMessage.send_client_message("missing item");
            this.set_disable();
            return;
        }
        if (this.hopper_slot == -1 || this.shulker_slot == -1) {
            WurstplusMessage.send_client_message("missing item");
            this.set_disable();
            return;
        }
        if (this.place_mode.in("Looking")) {
            final RayTraceResult r = WurstplusAuto32k.mc.player.rayTrace(5.0, WurstplusAuto32k.mc.getRenderPartialTicks());
            this.pos = Objects.requireNonNull(r).getBlockPos().up();
            final double pos_x = this.pos.getX() - WurstplusAuto32k.mc.player.posX;
            final double pos_z = this.pos.getZ() - WurstplusAuto32k.mc.player.posZ;
            int[] rot;
            if (Math.abs(pos_x) > Math.abs(pos_z)) {
                if (pos_x > 0.0) {
                    final int[] array = rot = new int[2];
                    array[0] = -1;
                    array[1] = 0;
                }
                else {
                    final int[] array2 = rot = new int[2];
                    array2[array2[0] = 1] = 0;
                }
            }
            else if (pos_z > 0.0) {
                final int[] array3 = rot = new int[2];
                array3[0] = 0;
                array3[1] = -1;
            }
            else {
                final int[] array4 = rot = new int[2];
                array4[0] = 0;
                array4[1] = 1;
            }
            this.rot = rot;
            if (WurstplusBlockUtil.canPlaceBlock(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(this.rot[0], 0, this.rot[1])) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(0, 1, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(0, 2, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(this.rot[0], 1, this.rot[1]))) {
                WurstplusBlockUtil.placeBlock(this.pos, block_slot, this.rotate.get_value(true), false);
                WurstplusBlockUtil.rotatePacket(this.pos.add(-this.rot[0], 1, -this.rot[1]).getX() + 0.5, this.pos.getY() + 1, this.pos.add(-this.rot[0], 1, -this.rot[1]).getZ() + 0.5);
                WurstplusBlockUtil.placeBlock(this.pos.up(), dispenser_slot, false, false);
                WurstplusBlockUtil.openBlock(this.pos.up());
                this.setup = true;
            }
            else {
                WurstplusMessage.send_client_message("unable to place");
                this.set_disable();
            }
        }
        else if (this.place_mode.in("Auto")) {
            for (int x = -2; x <= 2; ++x) {
                for (int y = -1; y <= 1; ++y) {
                    for (int z = -2; z <= 2; ++z) {
                        int[] rot2;
                        if (Math.abs(x) > Math.abs(z)) {
                            if (x > 0) {
                                final int[] array5 = rot2 = new int[2];
                                array5[0] = -1;
                                array5[1] = 0;
                            }
                            else {
                                final int[] array6 = rot2 = new int[2];
                                array6[array6[0] = 1] = 0;
                            }
                        }
                        else if (z > 0) {
                            final int[] array7 = rot2 = new int[2];
                            array7[0] = 0;
                            array7[1] = -1;
                        }
                        else {
                            final int[] array8 = rot2 = new int[2];
                            array8[0] = 0;
                            array8[1] = 1;
                        }
                        this.rot = rot2;
                        this.pos = WurstplusAuto32k.mc.player.getPosition().add(x, y, z);
                        if (WurstplusAuto32k.mc.player.getPositionEyes(WurstplusAuto32k.mc.getRenderPartialTicks()).distanceTo(WurstplusAuto32k.mc.player.getPositionVector().add((double)(x - this.rot[0] / 2), y + 0.5, (double)(z + this.rot[1] / 2))) <= 4.5 && WurstplusAuto32k.mc.player.getPositionEyes(WurstplusAuto32k.mc.getRenderPartialTicks()).distanceTo(WurstplusAuto32k.mc.player.getPositionVector().add(x + 0.5, y + 2.5, z + 0.5)) <= 4.5 && WurstplusBlockUtil.canPlaceBlock(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(this.rot[0], 0, this.rot[1])) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(0, 1, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(0, 2, 0)) && WurstplusBlockUtil.isBlockEmpty(this.pos.add(this.rot[0], 1, this.rot[1]))) {
                            WurstplusBlockUtil.placeBlock(this.pos, block_slot, this.rotate.get_value(true), false);
                            WurstplusBlockUtil.rotatePacket(this.pos.add(-this.rot[0], 1, -this.rot[1]).getX() + 0.5, this.pos.getY() + 1, this.pos.add(-this.rot[0], 1, -this.rot[1]).getZ() + 0.5);
                            WurstplusBlockUtil.placeBlock(this.pos.up(), dispenser_slot, false, false);
                            WurstplusBlockUtil.openBlock(this.pos.up());
                            this.setup = true;
                            return;
                        }
                    }
                }
            }
            WurstplusMessage.send_client_message("unable to place");
            this.set_disable();
        }
        else {
            for (int z2 = -2; z2 <= 2; ++z2) {
                for (int y = -1; y <= 2; ++y) {
                    for (int x2 = -2; x2 <= 2; ++x2) {
                        if ((z2 != 0 || y != 0 || x2 != 0) && (z2 != 0 || y != 1 || x2 != 0) && WurstplusBlockUtil.isBlockEmpty(WurstplusAuto32k.mc.player.getPosition().add(z2, y, x2)) && WurstplusAuto32k.mc.player.getPositionEyes(WurstplusAuto32k.mc.getRenderPartialTicks()).distanceTo(WurstplusAuto32k.mc.player.getPositionVector().add(z2 + 0.5, y + 0.5, x2 + 0.5)) < 4.5 && WurstplusBlockUtil.isBlockEmpty(WurstplusAuto32k.mc.player.getPosition().add(z2, y + 1, x2)) && WurstplusAuto32k.mc.player.getPositionEyes(WurstplusAuto32k.mc.getRenderPartialTicks()).distanceTo(WurstplusAuto32k.mc.player.getPositionVector().add(z2 + 0.5, y + 1.5, x2 + 0.5)) < 4.5) {
                            WurstplusBlockUtil.placeBlock(WurstplusAuto32k.mc.player.getPosition().add(z2, y, x2), this.hopper_slot, this.rotate.get_value(true), false);
                            WurstplusBlockUtil.placeBlock(WurstplusAuto32k.mc.player.getPosition().add(z2, y + 1, x2), this.shulker_slot, this.rotate.get_value(true), false);
                            WurstplusBlockUtil.openBlock(WurstplusAuto32k.mc.player.getPosition().add(z2, y, x2));
                            this.pos = WurstplusAuto32k.mc.player.getPosition().add(z2, y, x2);
                            this.dispenser_done = true;
                            this.place_redstone = true;
                            this.setup = true;
                            return;
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public void update() {
        if (this.ticks_past > 50 && !(WurstplusAuto32k.mc.currentScreen instanceof GuiHopper)) {
            WurstplusMessage.send_client_message("inactive too long, disabling");
            this.set_disable();
            return;
        }
        if (this.setup && this.ticks_past > this.delay.get_value(1)) {
            if (!this.dispenser_done) {
                try {
                    WurstplusAuto32k.mc.playerController.windowClick(WurstplusAuto32k.mc.player.openContainer.windowId, 36 + this.shulker_slot, 0, ClickType.QUICK_MOVE, (EntityPlayer)WurstplusAuto32k.mc.player);
                    this.dispenser_done = true;
                    if (this.debug.get_value(true)) {
                        WurstplusMessage.send_client_message("sent item");
                    }
                }
                catch (Exception ex) {}
            }
            if (!this.place_redstone) {
                WurstplusBlockUtil.placeBlock(this.pos.add(0, 2, 0), this.redstone_slot, this.rotate.get_value(true), false);
                if (this.debug.get_value(true)) {
                    WurstplusMessage.send_client_message("placed redstone");
                }
                this.place_redstone = true;
                return;
            }
            if (!this.place_mode.in("Hopper") && WurstplusAuto32k.mc.world.getBlockState(this.pos.add(this.rot[0], 1, this.rot[1])).getBlock() instanceof BlockShulkerBox && WurstplusAuto32k.mc.world.getBlockState(this.pos.add(this.rot[0], 0, this.rot[1])).getBlock() != Blocks.HOPPER && this.place_redstone && this.dispenser_done && !(WurstplusAuto32k.mc.currentScreen instanceof GuiInventory)) {
                WurstplusBlockUtil.placeBlock(this.pos.add(this.rot[0], 0, this.rot[1]), this.hopper_slot, this.rotate.get_value(true), false);
                WurstplusBlockUtil.openBlock(this.pos.add(this.rot[0], 0, this.rot[1]));
                if (this.debug.get_value(true)) {
                    WurstplusMessage.send_client_message("in the hopper");
                }
            }
            if (WurstplusAuto32k.mc.currentScreen instanceof GuiHopper) {
                final GuiHopper gui = (GuiHopper)WurstplusAuto32k.mc.currentScreen;
                for (int slot = 32; slot <= 40; ++slot) {
                    if (EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, gui.inventorySlots.getSlot(slot).getStack()) > 5) {
                        WurstplusAuto32k.mc.player.inventory.currentItem = slot - 32;
                        break;
                    }
                }
                if (!(gui.inventorySlots.inventorySlots.get(0).getStack().getItem() instanceof ItemAir)) {
                    boolean swapReady = true;
                    if (((GuiContainer)WurstplusAuto32k.mc.currentScreen).inventorySlots.getSlot(0).getStack().isEmpty) {
                        swapReady = false;
                    }
                    if (!((GuiContainer)WurstplusAuto32k.mc.currentScreen).inventorySlots.getSlot(this.shulker_slot + 32).getStack().isEmpty) {
                        swapReady = false;
                    }
                    if (swapReady) {
                        WurstplusAuto32k.mc.playerController.windowClick(((GuiContainer)WurstplusAuto32k.mc.currentScreen).inventorySlots.windowId, 0, this.shulker_slot, ClickType.SWAP, (EntityPlayer)WurstplusAuto32k.mc.player);
                        this.disable();
                    }
                }
            }
        }
        ++this.ticks_past;
    }
}
