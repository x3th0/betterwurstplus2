package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.external.*;
import net.minecraft.network.play.server.*;
import java.util.function.*;

public class WurstplusVelocity extends WurstplusModule
{
    @EventHandler
    private Listener<WurstplusEventPacket.ReceivePacket> damage;
    @EventHandler
    private Listener<WurstplusEventEntity.WurstplusEventColision> explosion;
    
    public WurstplusVelocity() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        final SPacketEntityVelocity knockback;
        final SPacketEntityVelocity sPacketEntityVelocity;
        final SPacketEntityVelocity sPacketEntityVelocity2;
        final SPacketEntityVelocity sPacketEntityVelocity3;
        final SPacketExplosion sPacketExplosion;
        final SPacketExplosion knockback2;
        final SPacketExplosion sPacketExplosion2;
        final SPacketExplosion sPacketExplosion3;
        this.damage = new Listener<WurstplusEventPacket.ReceivePacket>(event -> {
            if (event.get_era() == WurstplusEventCancellable.Era.EVENT_PRE) {
                if (event.get_packet() instanceof SPacketEntityVelocity) {
                    knockback = (SPacketEntityVelocity)event.get_packet();
                    if (knockback.getEntityID() == WurstplusVelocity.mc.player.getEntityId()) {
                        event.cancel();
                        sPacketEntityVelocity.motionX *= (int)0.0f;
                        sPacketEntityVelocity2.motionY *= (int)0.0f;
                        sPacketEntityVelocity3.motionZ *= (int)0.0f;
                    }
                }
                else if (event.get_packet() instanceof SPacketExplosion) {
                    event.cancel();
                    knockback2 = (sPacketExplosion = (SPacketExplosion)event.get_packet());
                    sPacketExplosion.motionX *= 0.0f;
                    sPacketExplosion2.motionY *= 0.0f;
                    sPacketExplosion3.motionZ *= 0.0f;
                }
            }
            return;
        }, (Predicate<WurstplusEventPacket.ReceivePacket>[])new Predicate[0]);
        this.explosion = new Listener<WurstplusEventEntity.WurstplusEventColision>(event -> {
            if (event.get_entity() == WurstplusVelocity.mc.player) {
                event.cancel();
            }
            return;
        }, (Predicate<WurstplusEventEntity.WurstplusEventColision>[])new Predicate[0]);
        this.name = "Velocity";
        this.tag = "Velocity";
        this.description = "No kockback";
        this.release("Wurst+2 - Module - Wurst+2");
    }
}
