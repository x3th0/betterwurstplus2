package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.entity.item.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.block.*;

public class WurstplusSurround extends WurstplusModule
{
    WurstplusSetting rotate;
    WurstplusSetting hybrid;
    WurstplusSetting triggerable;
    WurstplusSetting center;
    WurstplusSetting swing;
    WurstplusSetting block_head;
    WurstplusSetting tick_for_place;
    WurstplusSetting tick_timeout;
    WurstplusSetting retries;
    int new_slot;
    int old_slot;
    int y_level;
    int tick_runs;
    int blocks_placed;
    int offset_step;
    int retry_timer;
    private Vec3d center_block;
    boolean sneak;
    Vec3d[] surround_targets;
    Vec3d[] surround_targets_face;
    
    public WurstplusSurround() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.rotate = this.create("Rotate", "SurroundSmoth", true);
        this.hybrid = this.create("Hybrid", "SurroundHybrid", true);
        this.triggerable = this.create("Toggle", "SurroundToggle", true);
        this.center = this.create("Center", "SurroundCenter", false);
        this.swing = this.create("Swing", "SurroundSwing", false);
        this.block_head = this.create("Block Face", "SurroundBlockFace", false);
        this.tick_for_place = this.create("Blocks per tick", "SurroundTickToPlace", 2, 1, 8);
        this.tick_timeout = this.create("Ticks til timeout", "SurroundTicks", 20, 10, 50);
        this.retries = this.create("Retries", "SurroundRetries", 4, 1, 10);
        this.new_slot = 0;
        this.old_slot = 0;
        this.y_level = 0;
        this.tick_runs = 0;
        this.blocks_placed = 0;
        this.offset_step = 0;
        this.retry_timer = 0;
        this.center_block = Vec3d.ZERO;
        this.sneak = false;
        this.surround_targets = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0), new Vec3d(0.0, -1.0, 0.0) };
        this.surround_targets_face = new Vec3d[] { new Vec3d(1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, 1.0), new Vec3d(-1.0, 1.0, 0.0), new Vec3d(0.0, 1.0, -1.0), new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0), new Vec3d(1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, 1.0), new Vec3d(-1.0, -1.0, 0.0), new Vec3d(0.0, -1.0, -1.0), new Vec3d(0.0, -1.0, 0.0) };
        this.name = "Surround";
        this.tag = "Surround";
        this.description = "A barrier into player with obsidian.";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    public void enable() {
        if (WurstplusSurround.mc.player != null) {
            this.old_slot = WurstplusSurround.mc.player.inventory.currentItem;
            this.new_slot = this.find_in_hotbar();
            if (this.new_slot == -1) {
                WurstplusMessage.send_client_error_message("cannot find obi in hotbar");
                this.set_active(false);
            }
            this.y_level = (int)Math.round(WurstplusSurround.mc.player.posY);
            this.center_block = this.get_center(WurstplusSurround.mc.player.posX, WurstplusSurround.mc.player.posY, WurstplusSurround.mc.player.posZ);
            if (this.center.get_value(true)) {
                WurstplusSurround.mc.player.motionX = 0.0;
                WurstplusSurround.mc.player.motionZ = 0.0;
            }
        }
    }
    
    public void disable() {
        if (WurstplusSurround.mc.player != null) {
            if (this.new_slot != this.old_slot && this.old_slot != -1) {
                WurstplusSurround.mc.player.inventory.currentItem = this.old_slot;
            }
            if (this.sneak) {
                WurstplusSurround.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusSurround.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                this.sneak = false;
            }
            this.old_slot = -1;
            this.new_slot = -1;
        }
    }
    
    @Override
    public void update() {
        if (WurstplusSurround.mc.player != null) {
            if (this.center_block != Vec3d.ZERO && this.center.get_value(true)) {
                final double x_diff = Math.abs(this.center_block.x - WurstplusSurround.mc.player.posX);
                final double z_diff = Math.abs(this.center_block.z - WurstplusSurround.mc.player.posZ);
                if (x_diff <= 0.1 && z_diff <= 0.1) {
                    this.center_block = Vec3d.ZERO;
                }
                else {
                    final double motion_x = this.center_block.x - WurstplusSurround.mc.player.posX;
                    final double motion_z = this.center_block.z - WurstplusSurround.mc.player.posZ;
                    WurstplusSurround.mc.player.motionX = motion_x / 2.0;
                    WurstplusSurround.mc.player.motionZ = motion_z / 2.0;
                }
            }
            if ((int)Math.round(WurstplusSurround.mc.player.posY) != this.y_level && this.hybrid.get_value(true)) {
                this.set_active(!this.is_active());
                return;
            }
            if (!this.triggerable.get_value(true) && this.tick_runs >= this.tick_timeout.get_value(1)) {
                this.tick_runs = 0;
                this.set_active(false);
                return;
            }
            this.blocks_placed = 0;
            while (this.blocks_placed < this.tick_for_place.get_value(1)) {
                if (this.offset_step >= (this.block_head.get_value(true) ? this.surround_targets_face.length : this.surround_targets.length)) {
                    this.offset_step = 0;
                    break;
                }
                final BlockPos offsetPos = new BlockPos(this.block_head.get_value(true) ? this.surround_targets_face[this.offset_step] : this.surround_targets[this.offset_step]);
                final BlockPos targetPos = new BlockPos(WurstplusSurround.mc.player.getPositionVector()).add(offsetPos.getX(), offsetPos.getY(), offsetPos.getZ());
                boolean try_to_place = true;
                if (!WurstplusSurround.mc.world.getBlockState(targetPos).getMaterial().isReplaceable()) {
                    try_to_place = false;
                }
                for (final Entity entity : WurstplusSurround.mc.world.getEntitiesWithinAABBExcludingEntity((Entity)null, new AxisAlignedBB(targetPos))) {
                    if (!(entity instanceof EntityItem)) {
                        if (entity instanceof EntityXPOrb) {
                            continue;
                        }
                        try_to_place = false;
                        break;
                    }
                }
                if (try_to_place && this.place_blocks(targetPos)) {
                    ++this.blocks_placed;
                }
                ++this.offset_step;
            }
            if (this.blocks_placed > 0 && this.new_slot != this.old_slot) {
                WurstplusSurround.mc.player.inventory.currentItem = this.old_slot;
            }
            ++this.tick_runs;
        }
    }
    
    private boolean place_blocks(final BlockPos pos) {
        if (!WurstplusSurround.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
        }
        for (final EnumFacing side : EnumFacing.values()) {
            final BlockPos neighbor = pos.offset(side);
            final EnumFacing side2 = side.getOpposite();
            if (WurstplusBlockInteractHelper.canBeClicked(neighbor)) {
                WurstplusSurround.mc.player.inventory.currentItem = this.new_slot;
                if (WurstplusBlockInteractHelper.blackList.contains(WurstplusSurround.mc.world.getBlockState(neighbor).getBlock())) {
                    WurstplusSurround.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusSurround.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    this.sneak = true;
                }
                final Vec3d hitVec = new Vec3d((Vec3i)neighbor).add(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                if (this.rotate.get_value(true)) {
                    WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
                }
                WurstplusSurround.mc.playerController.processRightClickBlock(WurstplusSurround.mc.player, WurstplusSurround.mc.world, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                if (this.swing.get_value(true)) {
                    WurstplusSurround.mc.player.swingArm(EnumHand.MAIN_HAND);
                }
                return true;
            }
        }
        return false;
    }
    
    private int find_in_hotbar() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusSurround.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stack.getItem()).getBlock();
                if (block instanceof BlockEnderChest) {
                    return i;
                }
                if (block instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public Vec3d get_center(final double posX, final double posY, final double posZ) {
        final double x = Math.floor(posX) + 0.5;
        final double y = Math.floor(posY);
        final double z = Math.floor(posZ) + 0.5;
        return new Vec3d(x, y, z);
    }
}
