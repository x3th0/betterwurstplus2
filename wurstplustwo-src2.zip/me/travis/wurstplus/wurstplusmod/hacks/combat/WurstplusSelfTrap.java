package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.init.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;
import net.minecraft.block.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;

public class WurstplusSelfTrap extends WurstplusModule
{
    WurstplusSetting toggle;
    WurstplusSetting rotate;
    private BlockPos trap_pos;
    private boolean sneak;
    
    public WurstplusSelfTrap() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.toggle = this.create("Toggle", "SelfTrapToggle", false);
        this.rotate = this.create("Rotate", "SelfTrapRotate", false);
        this.name = "Self Trap";
        this.tag = "SelfTrap";
        this.description = "oh 'eck, ive trapped me sen again";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    protected void disable() {
        if (this.sneak) {
            this.sneak = false;
            WurstplusSelfTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusSelfTrap.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
        }
    }
    
    @Override
    public void update() {
        final Vec3d pos = WurstplusMathUtil.interpolateEntity((Entity)WurstplusSelfTrap.mc.player, WurstplusSelfTrap.mc.getRenderPartialTicks());
        this.trap_pos = new BlockPos(pos.x, pos.y + 2.0, pos.z);
        if (this.is_trapped() && !this.toggle.get_value(true)) {
            this.toggle();
            return;
        }
        final int last_slot = WurstplusSelfTrap.mc.player.inventory.currentItem;
        final int slot = this.find_in_hotbar();
        if (slot == -1) {
            this.toggle();
            return;
        }
        WurstplusSelfTrap.mc.player.inventory.currentItem = slot;
        WurstplusSelfTrap.mc.playerController.updateController();
        final WurstplusBlockInteractHelper.ValidResult result = WurstplusBlockInteractHelper.valid(this.trap_pos);
        if (result == WurstplusBlockInteractHelper.ValidResult.AlreadyBlockThere && !WurstplusSelfTrap.mc.world.getBlockState(this.trap_pos).getMaterial().isReplaceable()) {
            WurstplusSelfTrap.mc.player.inventory.currentItem = last_slot;
            return;
        }
        if (result == WurstplusBlockInteractHelper.ValidResult.NoNeighbors) {
            final BlockPos[] array;
            final BlockPos[] tests = array = new BlockPos[] { this.trap_pos.north(), this.trap_pos.south(), this.trap_pos.east(), this.trap_pos.west(), this.trap_pos.up(), this.trap_pos.down().west() };
            for (final BlockPos pos_ : array) {
                final WurstplusBlockInteractHelper.ValidResult result_ = WurstplusBlockInteractHelper.valid(pos_);
                if (result_ != WurstplusBlockInteractHelper.ValidResult.NoNeighbors) {
                    if (result_ != WurstplusBlockInteractHelper.ValidResult.NoEntityCollision) {
                        if (this.place_blocks(pos_)) {
                            WurstplusSelfTrap.mc.player.inventory.currentItem = last_slot;
                            return;
                        }
                    }
                }
            }
            WurstplusSelfTrap.mc.player.inventory.currentItem = last_slot;
            return;
        }
        this.place_blocks(this.trap_pos);
        WurstplusSelfTrap.mc.player.inventory.currentItem = last_slot;
    }
    
    public boolean is_trapped() {
        if (this.trap_pos == null) {
            return false;
        }
        final IBlockState state = WurstplusSelfTrap.mc.world.getBlockState(this.trap_pos);
        return state.getBlock() != Blocks.AIR && state.getBlock() != Blocks.WATER && state.getBlock() != Blocks.LAVA;
    }
    
    private int find_in_hotbar() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusSelfTrap.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stack.getItem()).getBlock();
                if (block instanceof BlockEnderChest) {
                    return i;
                }
                if (block instanceof BlockObsidian) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    private boolean place_blocks(final BlockPos pos) {
        if (pos == null) {
            this.set_disable();
            WurstplusMessage.toggle_message(this);
            return false;
        }
        if (!WurstplusSelfTrap.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            return false;
        }
        if (!WurstplusBlockInteractHelper.checkForNeighbours(pos)) {
            return false;
        }
        for (final EnumFacing side : EnumFacing.values()) {
            final BlockPos neighbor = pos.offset(side);
            final EnumFacing side2 = side.getOpposite();
            if (WurstplusBlockInteractHelper.canBeClicked(neighbor)) {
                final Block neighborPos;
                if (WurstplusBlockInteractHelper.blackList.contains(neighborPos = WurstplusSelfTrap.mc.world.getBlockState(neighbor).getBlock())) {
                    WurstplusSelfTrap.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusSelfTrap.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    this.sneak = true;
                }
                final Vec3d hitVec = new Vec3d((Vec3i)neighbor).add(0.5, 0.5, 0.5).add(new Vec3d(side2.getDirectionVec()).scale(0.5));
                if (this.rotate.get_value(true)) {
                    WurstplusBlockInteractHelper.faceVectorPacketInstant(hitVec);
                }
                WurstplusSelfTrap.mc.playerController.processRightClickBlock(WurstplusSelfTrap.mc.player, WurstplusSelfTrap.mc.world, neighbor, side2, hitVec, EnumHand.MAIN_HAND);
                WurstplusSelfTrap.mc.player.swingArm(EnumHand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }
}
