package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import net.minecraft.util.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.util.math.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.player.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import net.minecraft.nbt.*;

public class WurstplusKillAura extends WurstplusModule
{
    WurstplusSetting mode;
    WurstplusSetting player;
    WurstplusSetting friends;
    WurstplusSetting range;
    WurstplusSetting delay;
    EnumHand actual_hand;
    double tick;
    
    public WurstplusKillAura() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.mode = this.create("Mode", "KillAuraMode", "A32k", this.combobox("A32k", "Normal"));
        this.player = this.create("Player", "KillAuraPlayer", true);
        this.friends = this.create("Friends", "KillAuraFriends", false);
        this.range = this.create("Range", "KillAuraRange", 5.0, 0.5, 6.0);
        this.delay = this.create("Delay", "KillAuraDelay", 2, 0, 10);
        this.actual_hand = EnumHand.MAIN_HAND;
        this.tick = 0.0;
        this.name = "Kill Aura";
        this.tag = "KillAura";
        this.description = "To able hit enemies in a range.";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    protected void enable() {
        this.tick = 0.0;
    }
    
    @Override
    public void update() {
        if (WurstplusKillAura.mc.player != null && WurstplusKillAura.mc.world != null) {
            ++this.tick;
            if (WurstplusKillAura.mc.player.isDead | WurstplusKillAura.mc.player.getHealth() <= 0.0f) {
                return;
            }
            if (this.mode.in("Normal")) {
                if (WurstplusKillAura.mc.playerController.blockHitDelay > 0) {
                    return;
                }
            }
            else {
                if (!(WurstplusKillAura.mc.player.getHeldItemMainhand().getItem() instanceof ItemSword)) {
                    return;
                }
                if (this.tick < this.delay.get_value(1)) {
                    return;
                }
                this.tick = 0.0;
                final Entity entity = this.find_entity();
                if (entity != null) {
                    this.attack_entity(entity);
                }
            }
        }
    }
    
    public void attack_entity(final Entity entity) {
        if (this.mode.in("A32k")) {
            int newSlot = -1;
            for (int i = 0; i < 9; ++i) {
                final ItemStack stack = WurstplusKillAura.mc.player.inventory.getStackInSlot(i);
                if (stack != ItemStack.EMPTY) {
                    if (this.checkSharpness(stack)) {
                        newSlot = i;
                        break;
                    }
                }
            }
            if (newSlot == -1) {
                return;
            }
            WurstplusKillAura.mc.player.inventory.currentItem = newSlot;
        }
        final ItemStack off_hand_item = WurstplusKillAura.mc.player.getHeldItemOffhand();
        if (off_hand_item.getItem() == Items.SHIELD) {
            WurstplusKillAura.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, WurstplusKillAura.mc.player.getHorizontalFacing()));
        }
        WurstplusKillAura.mc.player.connection.sendPacket((Packet)new CPacketUseEntity(entity));
        WurstplusKillAura.mc.player.swingArm(this.actual_hand);
        WurstplusKillAura.mc.player.resetCooldown();
    }
    
    public Entity find_entity() {
        Entity entity_requested = null;
        for (final Entity entity : WurstplusKillAura.mc.world.playerEntities) {
            final EntityPlayer player = (EntityPlayer)entity;
            if (player != null && this.is_compatible((Entity)player) && WurstplusKillAura.mc.player.getDistance((Entity)player) <= this.range.get_value(1.0)) {
                entity_requested = (Entity)player;
            }
        }
        return entity_requested;
    }
    
    public boolean is_compatible(final Entity entity) {
        if (this.player.get_value(true) && entity instanceof EntityPlayer) {
            final EntityPlayer player_entity = (EntityPlayer)entity;
            return player_entity != WurstplusKillAura.mc.player && WurstplusFriendManager.isFriend(player_entity.getName()) && player_entity.getHealth() > 0.0f;
        }
        return false;
    }
    
    private boolean checkSharpness(final ItemStack stack) {
        if (stack.getTagCompound() == null) {
            return false;
        }
        final NBTTagList enchants = (NBTTagList)stack.getTagCompound().getTag("ench");
        int i = 0;
        while (i < enchants.tagCount()) {
            final NBTTagCompound enchant = enchants.getCompoundTagAt(i);
            if (enchant.getInteger("id") == 16) {
                final int lvl = enchant.getInteger("lvl");
                if (lvl > 5) {
                    return true;
                }
                break;
            }
            else {
                ++i;
            }
        }
        return false;
    }
}
