package me.travis.wurstplus.wurstplusmod.hacks.combat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import net.minecraft.util.math.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import java.util.stream.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.travis.draw.*;

public class WurstplusBedAura extends WurstplusModule
{
    WurstplusSetting delay;
    WurstplusSetting range;
    WurstplusSetting rotate;
    private BlockPos render_pos;
    private int counter;
    private spoof_face spoof_looking;
    
    public WurstplusBedAura() {
        super(WurstplusCategory.WURSTPLUS_COMBAT);
        this.delay = this.create("Delay", "BedAuraDelay", 2, 0, 10);
        this.range = this.create("Range", "BedAuraRange", 5, 0, 6);
        this.rotate = this.create("Rotate", "BedAuraRotate", false);
        this.name = "Bed Aura";
        this.tag = "BedAura";
        this.description = "fucking endcrystal.me";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    protected void enable() {
        this.render_pos = null;
        this.counter = 0;
    }
    
    @Override
    protected void disable() {
        this.render_pos = null;
    }
    
    @Override
    public void update() {
        if (WurstplusBedAura.mc.player == null) {
            return;
        }
        if (this.counter > this.delay.get_value(1)) {
            this.counter = 0;
            this.place_bed();
            this.break_bed();
        }
        ++this.counter;
    }
    
    public void place_bed() {
        int bed_slot = -1;
        if (this.find_bed() == -1) {
            WurstplusMessage.send_client_message("no beds");
            return;
        }
        bed_slot = this.find_bed();
        BlockPos best_pos = null;
        EntityPlayer best_target = null;
        float best_distance = this.range.get_value(1);
        for (final EntityPlayer player : (List)WurstplusBedAura.mc.world.playerEntities.stream().filter(entityPlayer -> !WurstplusFriendManager.isFriend(entityPlayer.getName())).collect(Collectors.toList())) {
            if (player == WurstplusBedAura.mc.player) {
                continue;
            }
            if (best_distance < WurstplusBedAura.mc.player.getDistance((Entity)player)) {
                continue;
            }
            boolean face_place = true;
            final BlockPos pos = get_pos_floor(player).down();
            final BlockPos pos2 = this.check_side_block(pos);
            if (pos2 != null) {
                best_pos = pos2.up();
                best_target = player;
                best_distance = WurstplusBedAura.mc.player.getDistance((Entity)player);
                face_place = false;
            }
            if (!face_place) {
                continue;
            }
            final BlockPos upos = get_pos_floor(player);
            final BlockPos upos2 = this.check_side_block(upos);
            if (upos2 == null) {
                continue;
            }
            best_pos = upos2.up();
            best_target = player;
            best_distance = WurstplusBedAura.mc.player.getDistance((Entity)player);
        }
        if (best_target == null) {
            WurstplusMessage.send_client_message("cant find best player");
            return;
        }
        this.render_pos = best_pos;
        WurstplusMessage.send_client_message("placing");
        switch (this.spoof_looking) {
            case NORTH: {
                WurstplusBedAura.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(180.0f, 0.0f, WurstplusBedAura.mc.player.onGround));
            }
            case SOUTH: {
                WurstplusBedAura.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(0.0f, 0.0f, WurstplusBedAura.mc.player.onGround));
            }
            case WEST: {
                WurstplusBedAura.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(90.0f, 0.0f, WurstplusBedAura.mc.player.onGround));
            }
            case EAST: {
                WurstplusBedAura.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(-90.0f, 0.0f, WurstplusBedAura.mc.player.onGround));
                break;
            }
        }
        WurstplusBlockUtil.placeBlock(best_pos, bed_slot, this.rotate.get_value(true), false);
        WurstplusMessage.send_client_message("pass");
    }
    
    public void break_bed() {
        for (final BlockPos pos : WurstplusBlockInteractHelper.getSphere(get_pos_floor((EntityPlayer)WurstplusBedAura.mc.player), this.range.get_value(1), this.range.get_value(1), false, true, 0).stream().filter((Predicate<? super Object>)WurstplusBedAura::is_bed).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())) {
            WurstplusMessage.send_client_message("breaking bed");
            if (WurstplusBedAura.mc.player.isSneaking()) {
                WurstplusBedAura.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusBedAura.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            }
            WurstplusBlockUtil.openBlock(pos);
        }
    }
    
    public int find_bed() {
        for (int i = 0; i < 9; ++i) {
            if (WurstplusBedAura.mc.player.inventory.getStackInSlot(i).getItem() == Items.BED) {
                return i;
            }
        }
        return -1;
    }
    
    public BlockPos check_side_block(final BlockPos pos) {
        if (WurstplusBedAura.mc.world.getBlockState(pos.east()).getBlock() != Blocks.AIR && WurstplusBedAura.mc.world.getBlockState(pos.east().up()).getBlock() == Blocks.AIR) {
            this.spoof_looking = spoof_face.WEST;
            return pos.east();
        }
        if (WurstplusBedAura.mc.world.getBlockState(pos.north()).getBlock() != Blocks.AIR && WurstplusBedAura.mc.world.getBlockState(pos.north().up()).getBlock() == Blocks.AIR) {
            this.spoof_looking = spoof_face.SOUTH;
            return pos.north();
        }
        if (WurstplusBedAura.mc.world.getBlockState(pos.west()).getBlock() != Blocks.AIR && WurstplusBedAura.mc.world.getBlockState(pos.west().up()).getBlock() == Blocks.AIR) {
            this.spoof_looking = spoof_face.EAST;
            return pos.west();
        }
        if (WurstplusBedAura.mc.world.getBlockState(pos.south()).getBlock() != Blocks.AIR && WurstplusBedAura.mc.world.getBlockState(pos.south().up()).getBlock() == Blocks.AIR) {
            this.spoof_looking = spoof_face.NORTH;
            return pos.south();
        }
        WurstplusMessage.send_client_message("cannot find side");
        return null;
    }
    
    public static BlockPos get_pos_floor(final EntityPlayer player) {
        return new BlockPos(Math.floor(player.posX), Math.floor(player.posY), Math.floor(player.posZ));
    }
    
    public static boolean is_bed(final BlockPos pos) {
        final Block block = WurstplusBedAura.mc.world.getBlockState(pos).getBlock();
        return block == Blocks.BED;
    }
    
    @Override
    public void render(final WurstplusEventRender event) {
        if (this.render_pos == null) {
            return;
        }
        TravisRenderHelp.prepare("lines");
        TravisRenderHelp.draw_cube_line(TravisRenderHelp.get_buffer_build(), this.render_pos.getX(), this.render_pos.getY(), this.render_pos.getZ(), 1.0f, 0.2f, 1.0f, 255, 20, 20, 180, "all");
        TravisRenderHelp.release();
    }
    
    enum spoof_face
    {
        EAST, 
        WEST, 
        NORTH, 
        SOUTH;
    }
}
