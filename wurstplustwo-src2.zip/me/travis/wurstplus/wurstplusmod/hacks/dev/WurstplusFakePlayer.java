package me.travis.wurstplus.wurstplusmod.hacks.dev;

import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.client.entity.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import java.util.*;
import com.mojang.authlib.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;

public class WurstplusFakePlayer extends WurstplusModule
{
    private EntityOtherPlayerMP fake_player;
    
    public WurstplusFakePlayer() {
        super(WurstplusCategory.WURSTPLUS_BETA);
        this.name = "Fake Player";
        this.tag = "FakePlayer";
        this.description = "used for debugging";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    protected void enable() {
        (this.fake_player = new EntityOtherPlayerMP((World)WurstplusFakePlayer.mc.world, new GameProfile(UUID.fromString("a07208c2-01e5-4eac-a3cf-a5f5ef2a4700"), "travis"))).copyLocationAndAnglesFrom((Entity)WurstplusFakePlayer.mc.player);
        this.fake_player.rotationYawHead = WurstplusFakePlayer.mc.player.rotationYawHead;
        WurstplusFakePlayer.mc.world.addEntityToWorld(-100, (Entity)this.fake_player);
    }
    
    @Override
    protected void disable() {
        try {
            WurstplusFakePlayer.mc.world.removeEntity((Entity)this.fake_player);
        }
        catch (Exception ex) {}
    }
}
