package me.travis.wurstplus.wurstplusmod.hacks.dev;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusDebug extends WurstplusModule
{
    public WurstplusDebug() {
        super(WurstplusCategory.WURSTPLUS_BETA);
        this.name = "Debug";
        this.tag = "Debug";
        this.description = "used for debugging";
        this.release("Wurst+2 - Module - Wurst+2");
    }
}
