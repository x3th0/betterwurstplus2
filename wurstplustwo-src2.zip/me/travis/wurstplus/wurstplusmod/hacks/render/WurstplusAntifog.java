package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.client.renderer.*;
import java.util.function.*;

public class WurstplusAntifog extends WurstplusModule
{
    @EventHandler
    private Listener<WurstplusEventSetupFog> setup_fog;
    
    public WurstplusAntifog() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.setup_fog = new Listener<WurstplusEventSetupFog>(event -> {
            event.cancel();
            WurstplusAntifog.mc.entityRenderer.setupFogColor(false);
            GlStateManager.glNormal3f(0.0f, -1.0f, 0.0f);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.colorMaterial(1028, 4608);
            return;
        }, (Predicate<WurstplusEventSetupFog>[])new Predicate[0]);
        this.name = "Anti Fog";
        this.tag = "AntiFog";
        this.description = "see even more";
        this.release("Wurst+2 - WURSTPLUS - Wurst+2");
    }
}
