package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusCapes extends WurstplusModule
{
    WurstplusSetting cape;
    
    public WurstplusCapes() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.cape = this.create("Cape", "CapeCape", "New", this.combobox("New", "OG"));
        this.name = "Capes";
        this.tag = "Capes";
        this.description = "see epic capes behind epic dudes";
        this.release("Wurst+2 - WURSTPLUS - Wurst+2");
    }
}
