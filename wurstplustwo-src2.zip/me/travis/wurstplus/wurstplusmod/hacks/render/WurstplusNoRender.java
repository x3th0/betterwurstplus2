package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusNoRender extends WurstplusModule
{
    WurstplusSetting fire;
    WurstplusSetting hurtcam;
    WurstplusSetting pumpkin;
    WurstplusSetting blindness;
    WurstplusSetting totem;
    WurstplusSetting skylight;
    WurstplusSetting armor;
    WurstplusSetting maps;
    WurstplusSetting bossbar;
    WurstplusSetting hand;
    
    public WurstplusNoRender() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.fire = this.create("Fire", "NoFire", true);
        this.hurtcam = this.create("Hurt Cam", "NoHurtCam", true);
        this.pumpkin = this.create("Pumpkin", "NoPumpkin", true);
        this.blindness = this.create("Blindness", "NoBlindness", true);
        this.totem = this.create("Totem Animation", "NoTotem", true);
        this.skylight = this.create("SkyLight", "NoSkyLight", true);
        this.armor = this.create("Armor", "NoArmor", true);
        this.maps = this.create("Maps", "NoMaps", true);
        this.bossbar = this.create("Wither Bar", "NoWitherBar", true);
        this.hand = this.create("OffHand", "NoOffHand", true);
        this.name = "No Render";
        this.tag = "NoRender";
        this.description = "stop    ok";
        this.release("Wurst+2 - module - Wurst+2");
    }
}
