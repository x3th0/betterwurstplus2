package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusNoBlur extends WurstplusModule
{
    public WurstplusNoBlur() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.name = "No Blur";
        this.tag = "NoBlur";
        this.description = "just for chae";
        this.release("Wurst+2 - module - Wurst+2");
    }
}
