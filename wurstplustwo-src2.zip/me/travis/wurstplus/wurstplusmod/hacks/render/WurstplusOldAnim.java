package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import me.travis.wurstplus.mixins.accessor.*;
import net.minecraft.util.*;

public class WurstplusOldAnim extends WurstplusModule
{
    public WurstplusOldAnim() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.name = "1.8 Animation";
        this.tag = "1.8Animation";
        this.description = "pull shit out faster";
        this.release("Wurst+2 - module - Wurst+2");
    }
    
    @Override
    public void update() {
        if (((IItemRenderer)WurstplusOldAnim.mc.entityRenderer.itemRenderer).getPrevEquippedProgressMainHand() >= 0.9) {
            ((IItemRenderer)WurstplusOldAnim.mc.entityRenderer.itemRenderer).setEquippedProgressMainHand(1.0f);
            ((IItemRenderer)WurstplusOldAnim.mc.entityRenderer.itemRenderer).setItemStackMainHand(WurstplusOldAnim.mc.player.getHeldItem(EnumHand.MAIN_HAND));
        }
        if (((IItemRenderer)WurstplusOldAnim.mc.entityRenderer.itemRenderer).getPrevEquippedProgressOffHand() >= 0.9) {
            ((IItemRenderer)WurstplusOldAnim.mc.entityRenderer.itemRenderer).setEquippedProgressOffHand(1.0f);
            ((IItemRenderer)WurstplusOldAnim.mc.entityRenderer.itemRenderer).setItemStackOffHand(WurstplusOldAnim.mc.player.getHeldItem(EnumHand.OFF_HAND));
        }
    }
}
