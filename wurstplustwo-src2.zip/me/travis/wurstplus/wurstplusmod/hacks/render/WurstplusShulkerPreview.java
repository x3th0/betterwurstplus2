package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusShulkerPreview extends WurstplusModule
{
    public WurstplusShulkerPreview() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.name = "Shulker Preview";
        this.tag = "ShulkerPreview";
        this.description = "See what's inside a shulker via hovering over it";
        this.release("Wurst+2 - module - Wurst+2");
    }
}
