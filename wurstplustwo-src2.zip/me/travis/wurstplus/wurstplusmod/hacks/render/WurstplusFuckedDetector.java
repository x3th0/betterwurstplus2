package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import net.minecraft.util.math.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.entity.player.*;
import net.minecraft.entity.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import java.util.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.init.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.travis.draw.*;

public class WurstplusFuckedDetector extends WurstplusModule
{
    WurstplusSetting draw_own;
    WurstplusSetting draw_friends;
    WurstplusSetting render_mode;
    WurstplusSetting r;
    WurstplusSetting g;
    WurstplusSetting b;
    WurstplusSetting a;
    private boolean solid;
    private boolean outline;
    public Set<BlockPos> fucked_players;
    
    public WurstplusFuckedDetector() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.draw_own = this.create("Draw Own", "FuckedDrawOwn", false);
        this.draw_friends = this.create("Draw Friends", "FuckedDrawFriends", false);
        this.render_mode = this.create("Render Mode", "FuckedRenderMode", "Pretty", this.combobox("Pretty", "Solid", "Outline"));
        this.r = this.create("R", "FuckedR", 255, 0, 255);
        this.g = this.create("G", "FuckedG", 255, 0, 255);
        this.b = this.create("B", "FuckedB", 255, 0, 255);
        this.a = this.create("A", "FuckedA", 100, 0, 255);
        this.fucked_players = new HashSet<BlockPos>();
        this.name = "Fucked Detector";
        this.tag = "FuckedDetector";
        this.description = "see if people are hecked";
        this.release("Wurst+2 - WURSTPLUS - Wurst+2");
    }
    
    @Override
    protected void enable() {
        this.fucked_players.clear();
    }
    
    @Override
    public void update() {
        if (WurstplusFuckedDetector.mc.world == null) {
            return;
        }
        this.set_fucked_players();
    }
    
    public void set_fucked_players() {
        this.fucked_players.clear();
        for (final EntityPlayer player : WurstplusFuckedDetector.mc.world.playerEntities) {
            if (WurstplusEntityUtil.isLiving((Entity)player)) {
                if (player.getHealth() <= 0.0f) {
                    continue;
                }
                if (!this.is_fucked(player)) {
                    continue;
                }
                if (WurstplusFriendManager.isFriend(player.getName()) && !this.draw_friends.get_value(true)) {
                    continue;
                }
                if (player == WurstplusFuckedDetector.mc.player && !this.draw_own.get_value(true)) {
                    continue;
                }
                this.fucked_players.add(new BlockPos(player.posX, player.posY, player.posZ));
            }
        }
    }
    
    public boolean is_fucked(final EntityPlayer player) {
        final BlockPos pos = new BlockPos(player.posX, player.posY - 1.0, player.posZ);
        return WurstplusCrystalUtil.canPlaceCrystal(pos.south()) || (WurstplusCrystalUtil.canPlaceCrystal(pos.south().south()) && WurstplusFuckedDetector.mc.world.getBlockState(pos.add(0, 1, 1)).getBlock() == Blocks.AIR) || (WurstplusCrystalUtil.canPlaceCrystal(pos.east()) || (WurstplusCrystalUtil.canPlaceCrystal(pos.east().east()) && WurstplusFuckedDetector.mc.world.getBlockState(pos.add(1, 1, 0)).getBlock() == Blocks.AIR)) || (WurstplusCrystalUtil.canPlaceCrystal(pos.west()) || (WurstplusCrystalUtil.canPlaceCrystal(pos.west().west()) && WurstplusFuckedDetector.mc.world.getBlockState(pos.add(-1, 1, 0)).getBlock() == Blocks.AIR)) || (WurstplusCrystalUtil.canPlaceCrystal(pos.north()) || (WurstplusCrystalUtil.canPlaceCrystal(pos.north().north()) && WurstplusFuckedDetector.mc.world.getBlockState(pos.add(0, 1, -1)).getBlock() == Blocks.AIR));
    }
    
    @Override
    public void render(final WurstplusEventRender event) {
        if (this.render_mode.in("Pretty")) {
            this.outline = true;
            this.solid = true;
        }
        if (this.render_mode.in("Solid")) {
            this.outline = false;
            this.solid = true;
        }
        if (this.render_mode.in("Outline")) {
            this.outline = true;
            this.solid = false;
        }
        for (final BlockPos render_block : this.fucked_players) {
            if (render_block == null) {
                return;
            }
            if (this.solid) {
                TravisRenderHelp.prepare("quads");
                TravisRenderHelp.draw_cube(TravisRenderHelp.get_buffer_build(), render_block.getX(), render_block.getY(), render_block.getZ(), 1.0f, 1.0f, 1.0f, this.r.get_value(1), this.g.get_value(1), this.b.get_value(1), this.a.get_value(1), "all");
                TravisRenderHelp.release();
            }
            if (!this.outline) {
                continue;
            }
            TravisRenderHelp.prepare("lines");
            TravisRenderHelp.draw_cube_line(TravisRenderHelp.get_buffer_build(), render_block.getX(), render_block.getY(), render_block.getZ(), 1.0f, 1.0f, 1.0f, this.r.get_value(1), this.g.get_value(1), this.b.get_value(1), this.a.get_value(1), "all");
            TravisRenderHelp.release();
        }
    }
}
