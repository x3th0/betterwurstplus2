package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.entity.player.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.server.*;
import java.util.function.*;
import joptsimple.internal.*;
import java.util.concurrent.atomic.*;
import com.google.common.util.concurrent.*;
import javax.annotation.*;
import me.travis.wurstplus.wurstplusmod.util.forgehax.*;
import net.minecraft.entity.*;
import com.mojang.authlib.*;
import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.text.*;
import java.util.*;
import net.minecraft.item.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.travis.draw.*;
import me.travis.wurstplus.*;
import net.minecraft.client.renderer.*;

public class WurstplusLogSpots extends WurstplusModule
{
    WurstplusSetting range;
    private List<WurstplusLogInfo> logged_spots;
    private final List<EntityPlayer> last_tick_entities;
    private boolean halt;
    private String last_logged;
    int r;
    int g;
    int b;
    @EventHandler
    private Listener<WurstplusEventPacket.ReceivePacket> listener;
    
    public WurstplusLogSpots() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.range = this.create("Range", "LogSpotsRange", 256, 1, 512);
        this.logged_spots = new ArrayList<WurstplusLogInfo>();
        this.last_tick_entities = new ArrayList<EntityPlayer>();
        this.halt = false;
        this.last_logged = "";
        final SPacketPlayerListItem packet;
        final String name;
        final UUID id;
        final AtomicInteger retries;
        final SPacketPlayerListItem sPacketPlayerListItem;
        this.listener = new Listener<WurstplusEventPacket.ReceivePacket>(event -> {
            if (event.get_packet() instanceof SPacketPlayerListItem) {
                packet = (SPacketPlayerListItem)event.get_packet();
                if (SPacketPlayerListItem.Action.ADD_PLAYER.equals((Object)packet.getAction()) || SPacketPlayerListItem.Action.REMOVE_PLAYER.equals((Object)packet.getAction())) {
                    packet.getEntries().stream().filter(Objects::nonNull).filter(data -> !Strings.isNullOrEmpty(data.getProfile().getName()) || data.getProfile().getId() != null).forEach(data -> {
                        name = data.getProfile().getName();
                        id = data.getProfile().getId();
                        retries = new AtomicInteger(2);
                        PlayerInfoHelper.registerWithCallback(id, name, (FutureCallback<PlayerInfo>)new FutureCallback<PlayerInfo>() {
                            final /* synthetic */ SPacketPlayerListItem val$packet;
                            final /* synthetic */ SPacketPlayerListItem.AddPlayerData val$data;
                            final /* synthetic */ AtomicInteger val$retries;
                            final /* synthetic */ String val$name;
                            
                            public void onSuccess(@Nullable final PlayerInfo result) {
                                WurstplusLogSpots.this.event_manager(this.val$packet.getAction(), result, this.val$data.getProfile());
                            }
                            
                            public void onFailure(final Throwable t) {
                                if (this.val$retries.getAndDecrement() > 0) {
                                    PlayerInfoHelper.registerWithCallback(this.val$data.getProfile().getId(), this.val$name, (FutureCallback<PlayerInfo>)this);
                                }
                                else {
                                    t.printStackTrace();
                                    PlayerInfoHelper.generateOfflineWithCallback(this.val$name, (FutureCallback<PlayerInfo>)this);
                                }
                            }
                        });
                    });
                }
            }
            return;
        }, (Predicate<WurstplusEventPacket.ReceivePacket>[])new Predicate[0]);
        this.name = "Log Spots";
        this.tag = "LogSpots";
        this.description = "ez log";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public void update() {
        if (this.halt) {
            return;
        }
        if (WurstplusLogSpots.mc.world == null) {
            this.logged_spots.clear();
            return;
        }
        if (!this.logged_spots.isEmpty()) {
            try {
                this.logged_spots.removeIf(spot -> WurstplusLogSpots.mc.player.getDistance(spot.get_entity()) >= this.range.get_value(1));
            }
            catch (Exception ex) {}
        }
        this.last_logged = "";
        this.last_tick_entities.clear();
        for (final Entity e : WurstplusLogSpots.mc.world.getLoadedEntityList()) {
            if (e instanceof EntityPlayer) {
                this.last_tick_entities.add((EntityPlayer)e);
            }
        }
        this.check_spots();
    }
    
    public void check_spots() {
        final List<String> known_names = new ArrayList<String>();
        final List<WurstplusLogInfo> players = new ArrayList<WurstplusLogInfo>();
        for (final WurstplusLogInfo info : this.logged_spots) {
            if (!known_names.contains(info.get_name())) {
                players.add(info);
                known_names.add(info.get_name());
            }
        }
        this.logged_spots = players;
    }
    
    private void event_manager(final SPacketPlayerListItem.Action action, final PlayerInfo info, final GameProfile profile) {
        if (info == null) {
            return;
        }
        if (info.getName().equals(this.last_logged)) {
            return;
        }
        if (this.halt) {
            return;
        }
        this.last_logged = info.getName();
        if (action == SPacketPlayerListItem.Action.ADD_PLAYER) {
            if (info.getName().equals(WurstplusLogSpots.mc.player.getName())) {
                return;
            }
            for (final WurstplusLogInfo i : this.logged_spots) {
                if (i.get_name().equals(info.getName())) {
                    WurstplusMessage.send_client_message("my man " + ChatFormatting.GREEN + info.getName() + ChatFormatting.RESET + " has just come back!");
                    this.logged_spots.remove(i);
                }
            }
        }
        else if (action == SPacketPlayerListItem.Action.REMOVE_PLAYER) {
            for (final EntityPlayer player : this.last_tick_entities) {
                if (info.getName().equals(player.getName())) {
                    final EntityPlayer entity = WurstplusLogSpots.mc.world.getPlayerEntityByUUID(info.getId());
                    final String date = new SimpleDateFormat("k:mm").format(new Date());
                    this.logged_spots.add(new WurstplusLogInfo((Entity)entity, player.getName(), date, player.getHealth() + player.getAbsorptionAmount(), player.getHeldEquipment(), player.getArmorInventoryList().iterator(), player.getRenderBoundingBox()));
                    final String pos = "x" + Math.round(player.posX) + " y" + Math.round(player.posY) + " z" + Math.round(player.posZ);
                    WurstplusMessage.send_client_message("mr. " + ChatFormatting.RED + info.getName() + ChatFormatting.RESET + " has just logged out at " + pos);
                }
            }
        }
    }
    
    @Override
    public void render(final WurstplusEventRender event) {
        try {
            if (!this.logged_spots.isEmpty()) {
                synchronized (this.logged_spots) {
                    this.halt = true;
                    for (final WurstplusLogInfo logged_spot : this.logged_spots) {
                        if (WurstplusLogSpots.mc.player.getDistance(logged_spot.get_entity()) < 500.0f) {
                            TravisRenderHelp.prepare("lines");
                            TravisRenderHelp.draw_cube_line(TravisRenderHelp.get_buffer_build(), (float)logged_spot.get_bb().minX, (float)logged_spot.get_bb().minY, (float)logged_spot.get_bb().minZ, 0.6f, 2.0f, 0.6f, this.r, this.g, this.b, 225, "all");
                            TravisRenderHelp.release();
                            final double x = this.interpolate(logged_spot.get_entity().lastTickPosX, logged_spot.get_entity().posX, event.get_partial_ticks()) - WurstplusLogSpots.mc.getRenderManager().renderPosX;
                            final double y = this.interpolate(logged_spot.get_entity().lastTickPosY, logged_spot.get_entity().posY, event.get_partial_ticks()) - WurstplusLogSpots.mc.getRenderManager().renderPosY;
                            final double z = this.interpolate(logged_spot.get_entity().lastTickPosZ, logged_spot.get_entity().posZ, event.get_partial_ticks()) - WurstplusLogSpots.mc.getRenderManager().renderPosZ;
                            this.renderNameTag(logged_spot, x, y, z, event.get_partial_ticks());
                        }
                    }
                    this.halt = false;
                }
            }
        }
        catch (Exception e) {
            WurstplusMessage.send_client_error_message("Logout spots error: " + e);
            this.logged_spots.clear();
        }
    }
    
    @Override
    protected void enable() {
        this.r = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorR").get_value(1);
        this.g = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorG").get_value(1);
        this.b = Wurstplus.get_setting_manager().get_setting_with_tag("HUD", "HUDStringsColorB").get_value(1);
        this.logged_spots.clear();
        this.halt = false;
    }
    
    @Override
    protected void disable() {
        this.logged_spots.clear();
    }
    
    private void renderNameTag(final WurstplusLogInfo info, final double x, final double yi, final double z, final float delta) {
        final double y = yi + 0.7;
        final Entity camera = WurstplusLogSpots.mc.getRenderViewEntity();
        assert camera != null;
        final double originalPositionX = camera.posX;
        final double originalPositionY = camera.posY;
        final double originalPositionZ = camera.posZ;
        camera.posX = this.interpolate(camera.prevPosX, camera.posX, delta);
        camera.posY = this.interpolate(camera.prevPosY, camera.posY, delta);
        camera.posZ = this.interpolate(camera.prevPosZ, camera.posZ, delta);
        final String displayTag1 = info.get_name() + " XYZ: " + Math.round(info.get_entity().getPosition().getX()) + ", " + Math.round(info.get_entity().getPosition().getY()) + ", " + Math.round(info.get_entity().getPosition().getZ());
        final String displayTag2 = Math.round(info.get_health()) + "hp";
        final StringBuilder displayTag3 = new StringBuilder("Items: ");
        for (final ItemStack stack : info.get_held_items()) {
            displayTag3.append(stack.getDisplayName()).append(" ");
        }
        final double distance = camera.getDistance(x + WurstplusLogSpots.mc.getRenderManager().viewerPosX, y + WurstplusLogSpots.mc.getRenderManager().viewerPosY, z + WurstplusLogSpots.mc.getRenderManager().viewerPosZ);
        double scale = (0.0018 + 5.0 * (distance * 0.3)) / 1000.0;
        if (distance <= 8.0) {
            scale = 0.0245;
        }
        GlStateManager.pushMatrix();
        RenderHelper.enableStandardItemLighting();
        GlStateManager.enablePolygonOffset();
        GlStateManager.doPolygonOffset(1.0f, -1500000.0f);
        GlStateManager.disableLighting();
        GlStateManager.translate((float)x, (float)y + 1.4f, (float)z);
        GlStateManager.rotate(-WurstplusLogSpots.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(WurstplusLogSpots.mc.getRenderManager().playerViewX, (WurstplusLogSpots.mc.gameSettings.thirdPersonView == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-scale, -scale, scale);
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.enableBlend();
        GlStateManager.disableBlend();
        WurstplusLogSpots.mc.fontRenderer.drawStringWithShadow(displayTag1, (float)(-WurstplusLogSpots.mc.fontRenderer.getStringWidth(displayTag1) / 2), -12.0f, toRGBA(this.r, this.g, this.b, 255));
        WurstplusLogSpots.mc.fontRenderer.drawStringWithShadow(displayTag2, (float)(-WurstplusLogSpots.mc.fontRenderer.getStringWidth(displayTag2) / 2), 0.0f, toRGBA(this.r, this.g, this.b, 255));
        WurstplusLogSpots.mc.fontRenderer.drawStringWithShadow(displayTag3.toString(), (float)(-WurstplusLogSpots.mc.fontRenderer.getStringWidth(displayTag3.toString()) / 2), 12.0f, toRGBA(this.r, this.g, this.b, 255));
        camera.posX = originalPositionX;
        camera.posY = originalPositionY;
        camera.posZ = originalPositionZ;
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.disablePolygonOffset();
        GlStateManager.doPolygonOffset(1.0f, 1500000.0f);
        GlStateManager.popMatrix();
    }
    
    private double interpolate(final double previous, final double current, final float delta) {
        return previous + (current - previous) * delta;
    }
    
    public static int toRGBA(final int r, final int g, final int b, final int a) {
        return (r << 16) + (g << 8) + b + (a << 24);
    }
}
