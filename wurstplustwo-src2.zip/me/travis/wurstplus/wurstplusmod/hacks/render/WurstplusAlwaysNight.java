package me.travis.wurstplus.wurstplusmod.hacks.render;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import java.util.function.*;

public class WurstplusAlwaysNight extends WurstplusModule
{
    @EventHandler
    private Listener<WurstplusEventRender> on_render;
    
    public WurstplusAlwaysNight() {
        super(WurstplusCategory.WURSTPLUS_RENDER);
        this.on_render = new Listener<WurstplusEventRender>(event -> {
            if (WurstplusAlwaysNight.mc.world == null) {
                return;
            }
            else {
                WurstplusAlwaysNight.mc.world.setWorldTime(18000L);
                return;
            }
        }, (Predicate<WurstplusEventRender>[])new Predicate[0]);
        this.name = "Always Night";
        this.tag = "AlwaysNight";
        this.description = "see even less";
        this.release("Wurst+2 - WURSTPLUS - Wurst+2");
    }
    
    @Override
    public void update() {
        if (WurstplusAlwaysNight.mc.world == null) {
            return;
        }
        WurstplusAlwaysNight.mc.world.setWorldTime(18000L);
    }
}
