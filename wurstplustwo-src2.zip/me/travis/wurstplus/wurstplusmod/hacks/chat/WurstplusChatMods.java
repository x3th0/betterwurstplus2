package me.travis.wurstplus.wurstplusmod.hacks.chat;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.server.*;
import net.minecraft.util.text.*;
import java.text.*;
import java.util.*;
import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.util.function.*;

public final class WurstplusChatMods extends WurstplusModule
{
    WurstplusSetting timestamps;
    WurstplusSetting dateformat;
    WurstplusSetting name_highlight;
    @EventHandler
    private Listener<WurstplusEventPacket.ReceivePacket> PacketEvent;
    
    public WurstplusChatMods() {
        super(WurstplusCategory.WURSTPLUS_CHAT);
        this.timestamps = this.create("Timestamps", "ChatModsTimeStamps", true);
        this.dateformat = this.create("Date Format", "ChatModsDateFormat", "24HR", this.combobox("24HR", "12HR"));
        this.name_highlight = this.create("Name Highlight", "ChatModsNameHighlight", true);
        final SPacketChat packet;
        final TextComponentString component;
        String date;
        String text;
        this.PacketEvent = new Listener<WurstplusEventPacket.ReceivePacket>(event -> {
            if (event.get_packet() instanceof SPacketChat) {
                packet = (SPacketChat)event.get_packet();
                if (packet.getChatComponent() instanceof TextComponentString) {
                    component = (TextComponentString)packet.getChatComponent();
                    if (this.timestamps.get_value(true)) {
                        date = "";
                        if (this.dateformat.in("12HR")) {
                            date = new SimpleDateFormat("h:mm a").format(new Date());
                        }
                        if (this.dateformat.in("24HR")) {
                            date = new SimpleDateFormat("k:mm").format(new Date());
                        }
                        component.text = "�7[" + date + "]�r " + component.text;
                    }
                    text = component.getFormattedText();
                    if (!text.contains("combat for")) {
                        if (this.name_highlight.get_value(true) && WurstplusChatMods.mc.player != null && text.toLowerCase().contains(WurstplusChatMods.mc.player.getName().toLowerCase())) {
                            text = text.replaceAll("(?i)" + WurstplusChatMods.mc.player.getName(), ChatFormatting.GOLD + WurstplusChatMods.mc.player.getName() + ChatFormatting.RESET);
                        }
                        event.cancel();
                        WurstplusMessage.client_message(text);
                    }
                }
            }
            return;
        }, (Predicate<WurstplusEventPacket.ReceivePacket>[])new Predicate[0]);
        this.name = "Chat Modifications";
        this.tag = "ChatModifications";
        this.description = "Try count how many messages sent in one minute!";
        this.release("Wurst+2 - module - Wurst+2");
    }
}
