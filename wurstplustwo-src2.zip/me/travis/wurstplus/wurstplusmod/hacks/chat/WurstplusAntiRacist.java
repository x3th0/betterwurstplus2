package me.travis.wurstplus.wurstplusmod.hacks.chat;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import java.util.*;
import net.minecraft.entity.player.*;

public class WurstplusAntiRacist extends WurstplusModule
{
    WurstplusSetting delay;
    List<String> chants;
    Random r;
    int tick_delay;
    
    public WurstplusAntiRacist() {
        super(WurstplusCategory.WURSTPLUS_CHAT);
        this.delay = this.create("Delay", "AntiRacistDelay", 10, 0, 100);
        this.chants = new ArrayList<String>();
        this.r = new Random();
        this.name = "Anti Racist";
        this.tag = "AntiRacist";
        this.description = "you just got nae nae'd by wurst+... 2";
        this.release("Wurst+2 - module - Wurst+2");
    }
    
    @Override
    protected void enable() {
        this.tick_delay = 0;
        this.chants.add("<player> you fucking racist");
        this.chants.add("RIP GEORGE FLOYD");
        this.chants.add("#BLM");
        this.chants.add("#ICANTBREATHE");
        this.chants.add("#NOJUSTICENOPEACE");
        this.chants.add("IM NOT BLACK BUT I STAND WITH YOU");
        this.chants.add("END RACISM, JOIN EMPERIUM");
        this.chants.add("DEFUND THE POLICE");
        this.chants.add("<player> I HOPE YOU POSTED YOUR BLACK SQUARE");
        this.chants.add("RESPECT BLM");
        this.chants.add("IF YOURE NOT WITH US, YOURE AGAINST US");
        this.chants.add("DEREK CHAUVIN WAS A RACIST");
    }
    
    @Override
    public void update() {
        ++this.tick_delay;
        if (this.tick_delay < this.delay.get_value(1) * 10) {
            return;
        }
        final String s = this.chants.get(this.r.nextInt(this.chants.size()));
        final String name = this.get_random_name();
        if (name == WurstplusAntiRacist.mc.player.getName()) {
            return;
        }
        WurstplusAntiRacist.mc.player.sendChatMessage(s.replace("<player>", name));
        this.tick_delay = 0;
    }
    
    public String get_random_name() {
        final List<EntityPlayer> players = (List<EntityPlayer>)WurstplusAntiRacist.mc.world.playerEntities;
        return players.get(this.r.nextInt(players.size())).getName();
    }
}
