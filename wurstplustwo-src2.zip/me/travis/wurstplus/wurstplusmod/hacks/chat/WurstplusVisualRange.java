package me.travis.wurstplus.wurstplusmod.hacks.chat;

import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.entity.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class WurstplusVisualRange extends WurstplusModule
{
    private List<String> people;
    
    public WurstplusVisualRange() {
        super(WurstplusCategory.WURSTPLUS_CHAT);
        this.name = "Visual Range";
        this.tag = "VisualRange";
        this.description = "Add who joins to visual range.";
        this.release("Wurst+2 - module - Wurst+2");
    }
    
    public void enable() {
        this.people = new ArrayList<String>();
    }
    
    @Override
    public void update() {
        if (WurstplusVisualRange.mc.world == null | WurstplusVisualRange.mc.player == null) {
            return;
        }
        final List<String> peoplenew = new ArrayList<String>();
        final List<EntityPlayer> playerEntities = (List<EntityPlayer>)WurstplusVisualRange.mc.world.playerEntities;
        for (final Entity e : playerEntities) {
            if (e.getName().equals(WurstplusVisualRange.mc.player.getName())) {
                continue;
            }
            peoplenew.add(e.getName());
        }
        if (peoplenew.size() > 0) {
            for (final String name : peoplenew) {
                if (!this.people.contains(name)) {
                    if (WurstplusFriendManager.isFriend(name)) {
                        WurstplusMessage.send_client_message("I see an epic dude called " + ChatFormatting.RESET + ChatFormatting.GREEN + name + ChatFormatting.RESET + " :D");
                    }
                    else {
                        WurstplusMessage.send_client_message("I see a dude called " + ChatFormatting.RESET + ChatFormatting.RED + name + ChatFormatting.RESET + ". Yuk");
                    }
                    this.people.add(name);
                }
            }
        }
    }
}
