package me.travis.wurstplus.wurstplusmod.hacks.chat;

import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.server.*;
import net.minecraft.world.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.util.function.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class WurstplusTotempop extends WurstplusModule
{
    public static final HashMap<String, Integer> totem_pop_counter;
    public static ChatFormatting red;
    public static ChatFormatting green;
    public static ChatFormatting gold;
    public static ChatFormatting grey;
    public static ChatFormatting bold;
    public static ChatFormatting reset;
    @EventHandler
    private final Listener<WurstplusEventPacket.ReceivePacket> packet_event;
    
    public WurstplusTotempop() {
        super(WurstplusCategory.WURSTPLUS_CHAT);
        final SPacketEntityStatus packet;
        final Entity entity;
        int count;
        this.packet_event = new Listener<WurstplusEventPacket.ReceivePacket>(event -> {
            if (event.get_packet() instanceof SPacketEntityStatus) {
                packet = (SPacketEntityStatus)event.get_packet();
                if (packet.getOpCode() == 35) {
                    entity = packet.getEntity((World)WurstplusTotempop.mc.world);
                    count = 1;
                    if (WurstplusTotempop.totem_pop_counter.containsKey(entity.getName())) {
                        count = WurstplusTotempop.totem_pop_counter.get(entity.getName());
                        WurstplusTotempop.totem_pop_counter.put(entity.getName(), ++count);
                    }
                    else {
                        WurstplusTotempop.totem_pop_counter.put(entity.getName(), count);
                    }
                    if (entity != WurstplusTotempop.mc.player) {
                        if (WurstplusFriendManager.isFriend(entity.getName())) {
                            WurstplusMessage.send_client_message(WurstplusTotempop.red + "" + WurstplusTotempop.bold + " TotemPop " + WurstplusTotempop.reset + WurstplusTotempop.grey + " > " + WurstplusTotempop.reset + "dude, " + WurstplusTotempop.bold + WurstplusTotempop.green + entity.getName() + WurstplusTotempop.reset + " has popped " + WurstplusTotempop.bold + count + WurstplusTotempop.reset + " totems. you should go help them");
                        }
                        else {
                            WurstplusMessage.send_client_message(WurstplusTotempop.red + "" + WurstplusTotempop.bold + " TotemPop " + WurstplusTotempop.reset + WurstplusTotempop.grey + " > " + WurstplusTotempop.reset + "dude, " + WurstplusTotempop.bold + WurstplusTotempop.red + entity.getName() + WurstplusTotempop.reset + " has popped " + WurstplusTotempop.bold + count + WurstplusTotempop.reset + " totems. what a loser");
                        }
                    }
                }
            }
            return;
        }, (Predicate<WurstplusEventPacket.ReceivePacket>[])new Predicate[0]);
        this.name = "Totem Pop Counter";
        this.tag = "TotemPopCounter";
        this.description = "dude idk wurst+ is just outdated";
        this.release("Wurst+2 - module - Wurst+2");
    }
    
    @Override
    public void update() {
        for (final EntityPlayer player : WurstplusTotempop.mc.world.playerEntities) {
            if (!WurstplusTotempop.totem_pop_counter.containsKey(player.getName())) {
                continue;
            }
            if (!player.isDead && player.getHealth() > 0.0f) {
                continue;
            }
            final int count = WurstplusTotempop.totem_pop_counter.get(player.getName());
            WurstplusTotempop.totem_pop_counter.remove(player.getName());
            if (player == WurstplusTotempop.mc.player) {
                continue;
            }
            if (WurstplusFriendManager.isFriend(player.getName())) {
                WurstplusMessage.send_client_message(WurstplusTotempop.red + "" + WurstplusTotempop.bold + " TotemPop " + WurstplusTotempop.reset + WurstplusTotempop.grey + " > " + WurstplusTotempop.reset + "dude, " + WurstplusTotempop.bold + WurstplusTotempop.green + player.getName() + WurstplusTotempop.reset + " just fucking DIED after popping " + WurstplusTotempop.bold + count + WurstplusTotempop.reset + " totems. RIP :pray:");
            }
            else {
                WurstplusMessage.send_client_message(WurstplusTotempop.red + "" + WurstplusTotempop.bold + " TotemPop " + WurstplusTotempop.reset + WurstplusTotempop.grey + " > " + WurstplusTotempop.reset + "dude, " + WurstplusTotempop.bold + WurstplusTotempop.red + player.getName() + WurstplusTotempop.reset + " just fucking DIED after popping " + WurstplusTotempop.bold + count + WurstplusTotempop.reset + " totems");
            }
        }
    }
    
    static {
        totem_pop_counter = new HashMap<String, Integer>();
        WurstplusTotempop.red = ChatFormatting.RED;
        WurstplusTotempop.green = ChatFormatting.GREEN;
        WurstplusTotempop.gold = ChatFormatting.GOLD;
        WurstplusTotempop.grey = ChatFormatting.GRAY;
        WurstplusTotempop.bold = ChatFormatting.BOLD;
        WurstplusTotempop.reset = ChatFormatting.RESET;
    }
}
