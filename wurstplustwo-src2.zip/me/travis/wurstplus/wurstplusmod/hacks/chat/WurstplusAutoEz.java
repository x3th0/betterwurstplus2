package me.travis.wurstplus.wurstplusmod.hacks.chat;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import java.util.concurrent.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import net.minecraftforge.event.entity.living.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import java.util.function.*;
import net.minecraft.entity.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import java.util.*;

public class WurstplusAutoEz extends WurstplusModule
{
    int delay_count;
    WurstplusSetting discord;
    WurstplusSetting custom;
    private static final ConcurrentHashMap targeted_players;
    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> send_listener;
    @EventHandler
    private Listener<LivingDeathEvent> living_death_listener;
    
    public WurstplusAutoEz() {
        super(WurstplusCategory.WURSTPLUS_CHAT);
        this.delay_count = 0;
        this.discord = this.create("Discord", "EzDiscord", false);
        this.custom = this.create("Custom", "EzCustom", false);
        final CPacketUseEntity cPacketUseEntity;
        final Entity target_entity;
        this.send_listener = new Listener<WurstplusEventPacket.SendPacket>(event -> {
            if (WurstplusAutoEz.mc.player == null) {
                return;
            }
            else {
                if (event.get_packet() instanceof CPacketUseEntity) {
                    cPacketUseEntity = (CPacketUseEntity)event.get_packet();
                    if (cPacketUseEntity.getAction().equals((Object)CPacketUseEntity.Action.ATTACK)) {
                        target_entity = cPacketUseEntity.getEntityFromWorld((World)WurstplusAutoEz.mc.world);
                        if (target_entity instanceof EntityPlayer) {
                            add_target(target_entity.getName());
                        }
                    }
                }
                return;
            }
        }, (Predicate<WurstplusEventPacket.SendPacket>[])new Predicate[0]);
        final EntityLivingBase e;
        final EntityPlayer player;
        this.living_death_listener = new Listener<LivingDeathEvent>(event -> {
            if (WurstplusAutoEz.mc.player == null) {
                return;
            }
            else {
                e = event.getEntityLiving();
                if (e == null) {
                    return;
                }
                else {
                    if (e instanceof EntityPlayer) {
                        player = (EntityPlayer)e;
                        if (player.getHealth() <= 0.0f && WurstplusAutoEz.targeted_players.containsKey(player.getName())) {
                            this.announce(player.getName());
                        }
                    }
                    return;
                }
            }
        }, (Predicate<LivingDeathEvent>[])new Predicate[0]);
        this.name = "Auto Ez";
        this.tag = "AutoEz";
        this.description = "you just got nae nae'd by wurst+... 2";
        this.release("Wurst+2 - module - Wurst+2");
    }
    
    @Override
    public void update() {
        for (final Entity entity : WurstplusAutoEz.mc.world.getLoadedEntityList()) {
            if (entity instanceof EntityPlayer) {
                final EntityPlayer player = (EntityPlayer)entity;
                if (player.getHealth() > 0.0f || !WurstplusAutoEz.targeted_players.containsKey(player.getName())) {
                    continue;
                }
                this.announce(player.getName());
            }
        }
        WurstplusAutoEz.targeted_players.forEach((name, timeout) -> {
            if (timeout <= 0) {
                WurstplusAutoEz.targeted_players.remove(name);
            }
            else {
                WurstplusAutoEz.targeted_players.put(name, timeout - 1);
            }
            return;
        });
        ++this.delay_count;
    }
    
    public void announce(final String name) {
        if (this.delay_count < 150) {
            return;
        }
        this.delay_count = 0;
        WurstplusAutoEz.targeted_players.remove(name);
        String message = "";
        if (this.custom.get_value(true)) {
            message += WurstplusEzMessageManager.message.replace("[", "").replace("]", "");
        }
        else {
            message += "you just got nae nae'd by wurst+2";
        }
        if (this.discord.get_value(true)) {
            message += " - discord.gg/wurst";
        }
        WurstplusAutoEz.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(message));
    }
    
    public static void add_target(final String name) {
        if (!Objects.equals(name, WurstplusAutoEz.mc.player.getName())) {
            WurstplusAutoEz.targeted_players.put(name, 20);
        }
    }
    
    static {
        targeted_players = new ConcurrentHashMap();
    }
}
