package me.travis.wurstplus.wurstplusmod.hacks.chat;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusClearChat extends WurstplusModule
{
    public WurstplusClearChat() {
        super(WurstplusCategory.WURSTPLUS_CHAT);
        this.name = "Clear Chatbox";
        this.tag = "ClearChatbox";
        this.description = "Removes the default minecraft chat outline.";
        this.release("Wurst+2 - module - Wurst+2");
    }
}
