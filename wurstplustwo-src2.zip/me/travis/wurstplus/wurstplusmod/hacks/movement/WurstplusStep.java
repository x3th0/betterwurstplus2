package me.travis.wurstplus.wurstplusmod.hacks.movement;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.util.math.*;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import java.util.*;

public class WurstplusStep extends WurstplusModule
{
    WurstplusSetting mode;
    private boolean step_flag;
    
    public WurstplusStep() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.mode = this.create("Mode", "StepMode", "Normal", this.combobox("Normal", "Reverse"));
        this.step_flag = true;
        this.name = "Step";
        this.tag = "Step";
        this.description = "Move up block big";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    protected void enable() {
        this.step_flag = true;
    }
    
    @Override
    public void update() {
        if (!WurstplusStep.mc.player.collidedHorizontally && this.mode.in("Normal")) {
            return;
        }
        if (!WurstplusStep.mc.player.onGround || WurstplusStep.mc.player.isOnLadder() || WurstplusStep.mc.player.isInWater() || WurstplusStep.mc.player.isInLava() || WurstplusStep.mc.player.movementInput.jump || WurstplusStep.mc.player.noClip) {
            return;
        }
        if (WurstplusStep.mc.player.moveForward == 0.0f && WurstplusStep.mc.player.moveStrafing == 0.0f) {
            return;
        }
        final double n = this.get_n_normal();
        if (this.mode.in("Normal")) {
            if (n < 0.0 || n > 2.0) {
                return;
            }
            if (n == 2.0) {
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.42, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.78, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.63, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.51, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.9, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.21, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.45, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.43, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.setPosition(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 2.0, WurstplusStep.mc.player.posZ);
            }
            if (n == 1.5) {
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.41999998688698, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.7531999805212, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.00133597911214, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.16610926093821, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.24918707874468, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.1707870772188, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.setPosition(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.0, WurstplusStep.mc.player.posZ);
            }
            if (n == 1.0) {
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.41999998688698, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 0.7531999805212, WurstplusStep.mc.player.posZ, WurstplusStep.mc.player.onGround));
                WurstplusStep.mc.player.setPosition(WurstplusStep.mc.player.posX, WurstplusStep.mc.player.posY + 1.0, WurstplusStep.mc.player.posZ);
            }
        }
        if (this.mode.in("Reverse")) {
            WurstplusStep.mc.player.motionY = -1.0;
        }
    }
    
    public boolean can_collide(final AxisAlignedBB aabb) {
        for (int x = MathHelper.floor(WurstplusStep.mc.player.getEntityBoundingBox().minX); x < MathHelper.floor(WurstplusStep.mc.player.getEntityBoundingBox().maxX); ++x) {
            for (int z = MathHelper.floor(WurstplusStep.mc.player.getEntityBoundingBox().minZ); z < MathHelper.floor(WurstplusStep.mc.player.getEntityBoundingBox().maxZ); ++z) {
                final Block block = WurstplusStep.mc.world.getBlockState(new BlockPos((double)x, aabb.minY, (double)z)).getBlock();
                if (block.material.isReplaceable()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public double get_n_normal() {
        WurstplusStep.mc.player.stepHeight = 0.5f;
        double max_y = -1.0;
        final AxisAlignedBB grow = WurstplusStep.mc.player.getEntityBoundingBox().offset(0.0, 0.05, 0.0).grow(0.05);
        if (!WurstplusStep.mc.world.getCollisionBoxes((Entity)WurstplusStep.mc.player, grow.offset(0.0, 2.0, 0.0)).isEmpty()) {
            return 100.0;
        }
        for (final AxisAlignedBB aabb : WurstplusStep.mc.world.getCollisionBoxes((Entity)WurstplusStep.mc.player, grow)) {
            if (aabb.maxY > max_y) {
                max_y = aabb.maxY;
            }
        }
        return max_y - WurstplusStep.mc.player.posY;
    }
}
