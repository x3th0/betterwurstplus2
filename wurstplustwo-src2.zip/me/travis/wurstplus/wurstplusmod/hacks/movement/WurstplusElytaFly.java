package me.travis.wurstplus.wurstplusmod.hacks.movement;

import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.inventory.*;
import net.minecraft.init.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import java.util.function.*;
import net.minecraft.network.play.client.*;
import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.util.*;
import net.minecraft.client.entity.*;

public class WurstplusElytaFly extends WurstplusModule
{
    WurstplusSetting mode;
    WurstplusSetting accelerate;
    WurstplusSetting cancel_in_water;
    WurstplusSetting instant_fly;
    WurstplusSetting pitch_spoof;
    WurstplusSetting speed;
    WurstplusSetting down_speed;
    WurstplusSetting glide_speed;
    WurstplusSetting up_speed;
    WurstplusSetting accelerate_timer;
    WurstplusSetting rotation_pitch;
    WurstplusSetting cancel_at_height;
    private WurstplusTimer acceleration_timer;
    private WurstplusTimer acceleration_reset_timer;
    private WurstplusTimer instant_fly_timer;
    private boolean send_message;
    @EventHandler
    private Listener<WurstplusEventPlayerTravel> on_travel;
    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> packet_event;
    
    public WurstplusElytaFly() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.mode = this.create("Mode", "ElytaFlyMode", "Normal", this.combobox("Normal", "Tarzan", "Superior", "Packet", "Control"));
        this.accelerate = this.create("Accelerate", "ElytraFlyAccelerate", true);
        this.cancel_in_water = this.create("Cancel In Water", "ElytraFlyCancelInWater", true);
        this.instant_fly = this.create("Instant Fly", "ElytraFlyInstant", true);
        this.pitch_spoof = this.create("Pitch Spoof", "ElytraFlyPitchSpoof", false);
        this.speed = this.create("Speed", "ElytraFlySpeed", 1.8, 0.0, 5.0);
        this.down_speed = this.create("Down Speed", "ElytraFlyDownSpeed", 1.8, 0.0, 5.0);
        this.glide_speed = this.create("Glide Speed", "ElytraFlyGlideSpeed", 1, 0, 10);
        this.up_speed = this.create("Up Speed", "ElytraFlyUpSpeed", 2, 0, 10);
        this.accelerate_timer = this.create("Acceleration Timer", "ElytraFlyAccelerationTimer", 1000, 0, 10000);
        this.rotation_pitch = this.create("Rotation Pitch", "ElytraFlyRotationPitch", 0, -90, 90);
        this.cancel_at_height = this.create("Cancel Height", "ElytraFlyCancelHeight", 5, 0, 10);
        this.acceleration_timer = new WurstplusTimer();
        this.acceleration_reset_timer = new WurstplusTimer();
        this.instant_fly_timer = new WurstplusTimer();
        this.send_message = false;
        this.on_travel = new Listener<WurstplusEventPlayerTravel>(event -> {
            if (WurstplusElytaFly.mc.player == null) {
                return;
            }
            else if (WurstplusElytaFly.mc.player.getItemStackFromSlot(EntityEquipmentSlot.CHEST).getItem() != Items.ELYTRA) {
                return;
            }
            else if (!WurstplusElytaFly.mc.player.isElytraFlying()) {
                if (!WurstplusElytaFly.mc.player.onGround && this.instant_fly.get_value(true)) {
                    if (!(!this.instant_fly_timer.passedMs(1000L))) {
                        this.instant_fly_timer.reset();
                        WurstplusElytaFly.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusElytaFly.mc.player, CPacketEntityAction.Action.START_FALL_FLYING));
                    }
                }
                return;
            }
            else {
                if (this.mode.in("Packet")) {
                    this.handle_normal_elytra(event);
                }
                if (this.mode.in("Superior")) {
                    this.handle_immediate_elytra(event);
                }
                if (this.mode.in("Control")) {
                    this.handle_control_mode(event);
                }
                return;
            }
        }, (Predicate<WurstplusEventPlayerTravel>[])new Predicate[0]);
        final CPacketPlayer.PositionRotation rotation;
        this.packet_event = new Listener<WurstplusEventPacket.SendPacket>(event -> {
            if (event.get_packet() instanceof CPacketPlayer && this.pitch_spoof.get_value(true)) {
                if (!(!WurstplusElytaFly.mc.player.isElytraFlying())) {
                    if (event.get_packet() instanceof CPacketPlayer.PositionRotation && this.pitch_spoof.get_value(true)) {
                        rotation = (CPacketPlayer.PositionRotation)event.get_packet();
                        WurstplusElytaFly.mc.getConnection().sendPacket((Packet)new CPacketPlayer.Position(rotation.x, rotation.y, rotation.z, rotation.onGround));
                        event.cancel();
                    }
                    else if (event.get_packet() instanceof CPacketPlayer.Rotation && this.pitch_spoof.get_value(true)) {
                        event.cancel();
                    }
                }
            }
            return;
        }, (Predicate<WurstplusEventPacket.SendPacket>[])new Predicate[0]);
        this.name = "Elytra Fly";
        this.tag = "ElytraFly";
        this.description = "ZOOOOOOOOooooooooooooooooooom";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    public void handle_normal_elytra(final WurstplusEventPlayerTravel travel) {
        final double y_height = WurstplusElytaFly.mc.player.posY;
        if (y_height <= this.cancel_at_height.get_value(1)) {
            if (!this.send_message) {
                WurstplusMessage.send_client_error_message("you too low atm bro");
                this.send_message = true;
            }
            return;
        }
        final boolean is_move_key_down = WurstplusElytaFly.mc.player.movementInput.moveForward > 0.0f || WurstplusElytaFly.mc.player.movementInput.moveStrafe > 0.0f;
        final boolean cancel_in_water = !WurstplusElytaFly.mc.player.isInWater() && !WurstplusElytaFly.mc.player.isInLava();
        if (WurstplusElytaFly.mc.player.movementInput.jump) {
            travel.cancel();
            this.accelerate();
            return;
        }
        if (is_move_key_down) {
            if ((WurstplusElytaFly.mc.player.rotationPitch <= this.rotation_pitch.get_value(1) || this.mode.in("Tarzan")) && cancel_in_water && this.cancel_in_water.get_value(true)) {
                if (this.accelerate.get_value(true) && this.acceleration_timer.passedMs(this.accelerate_timer.get_value(1))) {
                    this.accelerate();
                }
                return;
            }
        }
        travel.cancel();
        this.accelerate();
    }
    
    public void handle_control_mode(final WurstplusEventPlayerTravel travel) {
        final double[] dir = WurstplusMathUtil.directionSpeed(this.speed.get_value(1));
        if (WurstplusElytaFly.mc.player.movementInput.moveStrafe != 0.0f || WurstplusElytaFly.mc.player.movementInput.moveForward != 0.0f) {
            WurstplusElytaFly.mc.player.motionX = dir[0];
            WurstplusElytaFly.mc.player.motionZ = dir[1];
            final EntityPlayerSP player = WurstplusElytaFly.mc.player;
            player.motionX -= WurstplusElytaFly.mc.player.motionX * (Math.abs(WurstplusElytaFly.mc.player.rotationPitch) + 90.0f) / 90.0 - WurstplusElytaFly.mc.player.motionX;
            final EntityPlayerSP player2 = WurstplusElytaFly.mc.player;
            player2.motionZ -= WurstplusElytaFly.mc.player.motionZ * (Math.abs(WurstplusElytaFly.mc.player.rotationPitch) + 90.0f) / 90.0 - WurstplusElytaFly.mc.player.motionZ;
        }
        else {
            WurstplusElytaFly.mc.player.motionX = 0.0;
            WurstplusElytaFly.mc.player.motionZ = 0.0;
        }
        WurstplusElytaFly.mc.player.motionY = -WurstplusMathUtil.degToRad(WurstplusElytaFly.mc.player.rotationPitch) * WurstplusElytaFly.mc.player.movementInput.moveForward;
        WurstplusElytaFly.mc.player.prevLimbSwingAmount = 0.0f;
        WurstplusElytaFly.mc.player.limbSwingAmount = 0.0f;
        WurstplusElytaFly.mc.player.limbSwing = 0.0f;
        travel.cancel();
    }
    
    public void handle_immediate_elytra(final WurstplusEventPlayerTravel travel) {
        if (!WurstplusElytaFly.mc.player.movementInput.jump) {
            WurstplusElytaFly.mc.player.setVelocity(0.0, 0.0, 0.0);
            travel.cancel();
            final double[] dir = WurstplusMathUtil.directionSpeed(this.speed.get_value(1));
            if (WurstplusElytaFly.mc.player.movementInput.moveStrafe != 0.0f || WurstplusElytaFly.mc.player.movementInput.moveForward != 0.0f) {
                WurstplusElytaFly.mc.player.motionX = dir[0];
                WurstplusElytaFly.mc.player.motionY = -(this.glide_speed.get_value(1) / 10000.0f);
                WurstplusElytaFly.mc.player.motionZ = dir[1];
            }
            if (WurstplusElytaFly.mc.player.movementInput.sneak) {
                WurstplusElytaFly.mc.player.motionY = -this.down_speed.get_value(1);
            }
            WurstplusElytaFly.mc.player.prevLimbSwingAmount = 0.0f;
            WurstplusElytaFly.mc.player.limbSwingAmount = 0.0f;
            WurstplusElytaFly.mc.player.limbSwing = 0.0f;
            return;
        }
        final double motion_sq = Math.sqrt(WurstplusElytaFly.mc.player.motionX * WurstplusElytaFly.mc.player.motionX + WurstplusElytaFly.mc.player.motionZ * WurstplusElytaFly.mc.player.motionZ);
        if (motion_sq > 1.0) {
            return;
        }
        final double[] dir2 = WurstplusMathUtil.directionSpeedNoForward(this.speed.get_value(1));
        WurstplusElytaFly.mc.player.motionX = dir2[0];
        WurstplusElytaFly.mc.player.motionY = -(this.glide_speed.get_value(1) / 10000.0f);
        WurstplusElytaFly.mc.player.motionZ = dir2[1];
        travel.cancel();
    }
    
    public void accelerate() {
        if (this.acceleration_reset_timer.passedMs(this.accelerate_timer.get_value(1))) {
            this.acceleration_reset_timer.reset();
            this.acceleration_timer.reset();
            this.send_message = false;
        }
        final float l_Speed = this.speed.get_value(1);
        final double[] dir = WurstplusMathUtil.directionSpeed(l_Speed);
        WurstplusElytaFly.mc.player.motionY = -(this.glide_speed.get_value(1) / 10000.0f);
        if (WurstplusElytaFly.mc.player.movementInput.moveStrafe != 0.0f || WurstplusElytaFly.mc.player.movementInput.moveForward != 0.0f) {
            WurstplusElytaFly.mc.player.motionX = dir[0];
            WurstplusElytaFly.mc.player.motionZ = dir[1];
        }
        else {
            WurstplusElytaFly.mc.player.motionX = 0.0;
            WurstplusElytaFly.mc.player.motionZ = 0.0;
        }
        if (WurstplusElytaFly.mc.player.movementInput.sneak) {
            WurstplusElytaFly.mc.player.motionY = -this.down_speed.get_value(1);
        }
        WurstplusElytaFly.mc.player.prevLimbSwingAmount = 0.0f;
        WurstplusElytaFly.mc.player.limbSwingAmount = 0.0f;
        WurstplusElytaFly.mc.player.limbSwing = 0.0f;
    }
}
