package me.travis.wurstplus.wurstplusmod.hacks.movement;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;

public class WurstplusSprint extends WurstplusModule
{
    WurstplusSetting mode;
    
    public WurstplusSprint() {
        super(WurstplusCategory.WURSTPLUS_MOVEMENT);
        this.mode = this.create("Spoof Speed", "SprintSpoofSpeed", false);
        this.name = "Sprint";
        this.tag = "Sprint";
        this.description = "ZOOOOOOOOM";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public void update() {
    }
}
