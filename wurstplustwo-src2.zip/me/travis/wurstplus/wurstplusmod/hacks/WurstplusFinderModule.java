package me.travis.wurstplus.wurstplusmod.hacks;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.events.*;

public class WurstplusFinderModule extends WurstplusModule
{
    public WurstplusFinderModule() {
        super(WurstplusCategory.WURSTPLUS_HIDDEN);
        this.name = "Wurst+2";
        this.tag = "Wurst+2";
        this.description = "epic goods";
        this.release("Wurst+2 - WURSTPLUS - Wurst+2");
    }
    
    public void enable() {
    }
    
    public void disable() {
    }
    
    @Override
    public void update() {
    }
    
    @Override
    public void render() {
    }
    
    @Override
    public void render(final WurstplusEventRender funtion_for_get_world_event_with_tessallator) {
    }
}
