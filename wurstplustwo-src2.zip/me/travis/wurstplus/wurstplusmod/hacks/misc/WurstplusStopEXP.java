package me.travis.wurstplus.wurstplusmod.hacks.misc;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.network.play.client.*;
import java.util.function.*;
import java.util.*;
import net.minecraft.item.*;

public class WurstplusStopEXP extends WurstplusModule
{
    WurstplusSetting helmet_boot_percent;
    WurstplusSetting chest_leggings_percent;
    private int counter;
    private boolean should_cancel;
    @EventHandler
    private Listener<WurstplusEventPacket.SendPacket> packet_event;
    
    public WurstplusStopEXP() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.helmet_boot_percent = this.create("Helment Boots %", "StopEXHelmet", 80, 0, 100);
        this.chest_leggings_percent = this.create("Chest Leggins %", "StopEXChest", 100, 0, 100);
        this.counter = 0;
        this.should_cancel = false;
        this.packet_event = new Listener<WurstplusEventPacket.SendPacket>(event -> {
            if (event.get_packet() instanceof CPacketPlayerTryUseItem && this.should_cancel) {
                event.cancel();
            }
            return;
        }, (Predicate<WurstplusEventPacket.SendPacket>[])new Predicate[0]);
        this.name = "Stop EXP";
        this.tag = "StopEXP";
        this.description = "jumpy has a good idea??";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public void update() {
        this.counter = 0;
        for (final Map.Entry<Integer, ItemStack> armor_slot : this.get_armor().entrySet()) {
            ++this.counter;
            if (armor_slot.getValue().isEmpty()) {
                continue;
            }
            final ItemStack stack = armor_slot.getValue();
            final double max_dam = stack.getMaxDamage();
            final double dam_left = stack.getMaxDamage() - stack.getItemDamage();
            final double percent = dam_left / max_dam * 100.0;
            if (this.counter == 1 || this.counter == 4) {
                if (percent >= this.helmet_boot_percent.get_value(1)) {
                    if (this.is_holding_exp()) {
                        this.should_cancel = true;
                    }
                    else {
                        this.should_cancel = false;
                    }
                }
                else {
                    this.should_cancel = false;
                }
            }
            if (this.counter != 2 && this.counter != 3) {
                continue;
            }
            if (percent >= this.chest_leggings_percent.get_value(1)) {
                if (this.is_holding_exp()) {
                    this.should_cancel = true;
                }
                else {
                    this.should_cancel = false;
                }
            }
            else {
                this.should_cancel = false;
            }
        }
    }
    
    private Map<Integer, ItemStack> get_armor() {
        return this.get_inv_slots(5, 8);
    }
    
    private Map<Integer, ItemStack> get_inv_slots(int current, final int last) {
        final Map<Integer, ItemStack> full_inv_slots = new HashMap<Integer, ItemStack>();
        while (current <= last) {
            full_inv_slots.put(current, (ItemStack)WurstplusStopEXP.mc.player.inventoryContainer.getInventory().get(current));
            ++current;
        }
        return full_inv_slots;
    }
    
    public boolean is_holding_exp() {
        return WurstplusStopEXP.mc.player.getHeldItemMainhand().getItem() instanceof ItemExpBottle || WurstplusStopEXP.mc.player.getHeldItemOffhand().getItem() instanceof ItemExpBottle;
    }
}
