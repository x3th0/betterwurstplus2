package me.travis.wurstplus.wurstplusmod.hacks.misc;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.block.*;

public class WurstplusAutoWither extends WurstplusModule
{
    WurstplusSetting range;
    private int head_slot;
    private int sand_slot;
    
    public WurstplusAutoWither() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.range = this.create("Range", "WitherRange", 4, 0, 6);
        this.name = "Auto Wither";
        this.tag = "AutoWither";
        this.description = "makes withers";
        this.release("Wurst+2 - WURSTPLUS - Wurst+2");
    }
    
    @Override
    protected void enable() {
    }
    
    public boolean has_blocks() {
        int count = 0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusAutoWither.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() instanceof ItemBlock) {
                final Block block = ((ItemBlock)stack.getItem()).getBlock();
                if (block instanceof BlockSoulSand) {
                    this.sand_slot = i;
                    ++count;
                    break;
                }
            }
        }
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = WurstplusAutoWither.mc.player.inventory.getStackInSlot(i);
            if (stack.getItem() == Items.SKULL && stack.getItemDamage() == 1) {
                this.head_slot = i;
                ++count;
                break;
            }
        }
        return count == 2;
    }
}
