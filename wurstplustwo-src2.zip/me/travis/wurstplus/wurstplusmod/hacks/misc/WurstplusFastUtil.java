package me.travis.wurstplus.wurstplusmod.hacks.misc;

import me.travis.wurstplus.wurstplusmod.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.settings.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import net.minecraft.item.*;

public class WurstplusFastUtil extends WurstplusModule
{
    WurstplusSetting fast_place;
    WurstplusSetting fast_break;
    WurstplusSetting crystal;
    WurstplusSetting exp;
    
    public WurstplusFastUtil() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.fast_place = this.create("Place", "WurstplusFastPlace", false);
        this.fast_break = this.create("Break", "WurstplusFastBreak", false);
        this.crystal = this.create("Crystal", "WurstplusFastCrystal", true);
        this.exp = this.create("EXP", "WurstplusFastExp", true);
        this.name = "Fast Util";
        this.tag = "FastUtil";
        this.description = "Fast util for events and things in Minecraft.";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public void update() {
        final Item main = WurstplusFastUtil.mc.player.getHeldItemMainhand().getItem();
        final Item off = WurstplusFastUtil.mc.player.getHeldItemOffhand().getItem();
        final boolean main_exp = main instanceof ItemExpBottle;
        final boolean off_exp = off instanceof ItemExpBottle;
        final boolean main_cry = main instanceof ItemEndCrystal;
        final boolean off_cry = off instanceof ItemEndCrystal;
        if ((main_exp | off_exp) && this.exp.get_value(true)) {
            WurstplusFastUtil.mc.rightClickDelayTimer = 0;
        }
        if ((main_cry | off_cry) && this.crystal.get_value(true)) {
            WurstplusFastUtil.mc.rightClickDelayTimer = 0;
        }
        if (!(main_exp | off_exp | main_cry | off_cry) && this.fast_place.get_value(true)) {
            WurstplusFastUtil.mc.rightClickDelayTimer = 0;
        }
        if (this.fast_break.get_value(true)) {
            WurstplusFastUtil.mc.playerController.blockHitDelay = 0;
        }
    }
}
