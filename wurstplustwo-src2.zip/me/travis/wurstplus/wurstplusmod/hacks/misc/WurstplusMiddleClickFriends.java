package me.travis.wurstplus.wurstplusmod.hacks.misc;

import com.mojang.realmsclient.gui.*;
import me.travis.wurstplus.wurstplusmod.hacks.*;
import org.lwjgl.input.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.player.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import me.travis.wurstplus.wurstplusmod.*;
import net.minecraft.entity.*;

public class WurstplusMiddleClickFriends extends WurstplusModule
{
    private boolean clicked;
    public static ChatFormatting red;
    public static ChatFormatting green;
    public static ChatFormatting bold;
    public static ChatFormatting reset;
    
    public WurstplusMiddleClickFriends() {
        super(WurstplusCategory.WURSTPLUS_MISC);
        this.clicked = false;
        this.name = "Middleclick Friends";
        this.tag = "MiddleclickFriends";
        this.description = "you press button and the world becomes a better place :D";
        this.release("Wurst+2 - Module - Wurst+2");
    }
    
    @Override
    public void update() {
        if (WurstplusMiddleClickFriends.mc.currentScreen != null) {
            return;
        }
        if (!Mouse.isButtonDown(2)) {
            this.clicked = false;
            return;
        }
        if (!this.clicked) {
            this.clicked = true;
            final RayTraceResult result = WurstplusMiddleClickFriends.mc.objectMouseOver;
            if (result == null || result.typeOfHit != RayTraceResult.Type.ENTITY) {
                return;
            }
            if (!(result.entityHit instanceof EntityPlayer)) {
                return;
            }
            final Entity player = result.entityHit;
            if (WurstplusFriendManager.isFriend(player.getName())) {
                final WurstplusFriendManager.Friend f = WurstplusFriendManager.friends.stream().filter(friend -> friend.getUsername().equalsIgnoreCase(player.getName())).findFirst().get();
                WurstplusFriendManager.friends.remove(f);
                WurstplusMessage.send_client_message("Player " + WurstplusMiddleClickFriends.red + WurstplusMiddleClickFriends.bold + player.getName() + WurstplusMiddleClickFriends.reset + " is now not your friend :(");
            }
            else {
                final WurstplusFriendManager.Friend f = WurstplusFriendManager.get_friend_object(player.getName());
                WurstplusFriendManager.friends.add(f);
                WurstplusMessage.send_client_message("Player " + WurstplusMiddleClickFriends.green + WurstplusMiddleClickFriends.bold + player.getName() + WurstplusMiddleClickFriends.reset + " is now your friend :D");
            }
        }
    }
    
    static {
        WurstplusMiddleClickFriends.red = ChatFormatting.RED;
        WurstplusMiddleClickFriends.green = ChatFormatting.GREEN;
        WurstplusMiddleClickFriends.bold = ChatFormatting.BOLD;
        WurstplusMiddleClickFriends.reset = ChatFormatting.RESET;
    }
}
