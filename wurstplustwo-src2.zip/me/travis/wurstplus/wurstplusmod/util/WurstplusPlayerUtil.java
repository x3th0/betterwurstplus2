package me.travis.wurstplus.wurstplusmod.util;

import net.minecraft.client.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;
import net.minecraft.util.math.*;
import net.minecraft.client.entity.*;

public class WurstplusPlayerUtil
{
    private static Minecraft mc;
    
    public static int GetItemSlot(final Item input) {
        if (WurstplusPlayerUtil.mc.player == null) {
            return 0;
        }
        for (int i = 0; i < WurstplusPlayerUtil.mc.player.inventoryContainer.getInventory().size(); ++i) {
            if (i != 0 && i != 5 && i != 6 && i != 7) {
                if (i != 8) {
                    final ItemStack s = (ItemStack)WurstplusPlayerUtil.mc.player.inventoryContainer.getInventory().get(i);
                    if (!s.isEmpty()) {
                        if (s.getItem() == input) {
                            return i;
                        }
                    }
                }
            }
        }
        return -1;
    }
    
    public static int GetRecursiveItemSlot(final Item input) {
        if (WurstplusPlayerUtil.mc.player == null) {
            return 0;
        }
        for (int i = WurstplusPlayerUtil.mc.player.inventoryContainer.getInventory().size() - 1; i > 0; --i) {
            if (i != 0 && i != 5 && i != 6 && i != 7) {
                if (i != 8) {
                    final ItemStack s = (ItemStack)WurstplusPlayerUtil.mc.player.inventoryContainer.getInventory().get(i);
                    if (!s.isEmpty()) {
                        if (s.getItem() == input) {
                            return i;
                        }
                    }
                }
            }
        }
        return -1;
    }
    
    public static int GetItemSlotNotHotbar(final Item input) {
        if (WurstplusPlayerUtil.mc.player == null) {
            return 0;
        }
        for (int i = 9; i < 36; ++i) {
            final Item item = WurstplusPlayerUtil.mc.player.inventory.getStackInSlot(i).getItem();
            if (item == input) {
                return i;
            }
        }
        return -1;
    }
    
    public static int GetItemCount(final Item input) {
        if (WurstplusPlayerUtil.mc.player == null) {
            return 0;
        }
        int items = 0;
        for (int i = 0; i < 45; ++i) {
            final ItemStack stack = WurstplusPlayerUtil.mc.player.inventory.getStackInSlot(i);
            if (stack.getItem() == input) {
                items += stack.getCount();
            }
        }
        return items;
    }
    
    public static boolean CanSeeBlock(final BlockPos p_Pos) {
        return WurstplusPlayerUtil.mc.player != null && WurstplusPlayerUtil.mc.world.rayTraceBlocks(new Vec3d(WurstplusPlayerUtil.mc.player.posX, WurstplusPlayerUtil.mc.player.posY + WurstplusPlayerUtil.mc.player.getEyeHeight(), WurstplusPlayerUtil.mc.player.posZ), new Vec3d((double)p_Pos.getX(), (double)p_Pos.getY(), (double)p_Pos.getZ()), false, true, false) == null;
    }
    
    public static boolean isCurrentViewEntity() {
        return WurstplusPlayerUtil.mc.getRenderViewEntity() == WurstplusPlayerUtil.mc.player;
    }
    
    public static boolean IsEating() {
        return WurstplusPlayerUtil.mc.player != null && WurstplusPlayerUtil.mc.player.getHeldItemMainhand().getItem() instanceof ItemFood && WurstplusPlayerUtil.mc.player.isHandActive();
    }
    
    public static int GetItemInHotbar(final Item p_Item) {
        for (int l_I = 0; l_I < 9; ++l_I) {
            final ItemStack l_Stack = WurstplusPlayerUtil.mc.player.inventory.getStackInSlot(l_I);
            if (l_Stack != ItemStack.EMPTY && l_Stack.getItem() == p_Item) {
                return l_I;
            }
        }
        return -1;
    }
    
    public static BlockPos GetLocalPlayerPosFloored() {
        return new BlockPos(Math.floor(WurstplusPlayerUtil.mc.player.posX), Math.floor(WurstplusPlayerUtil.mc.player.posY), Math.floor(WurstplusPlayerUtil.mc.player.posZ));
    }
    
    public static float GetHealthWithAbsorption() {
        return WurstplusPlayerUtil.mc.player.getHealth() + WurstplusPlayerUtil.mc.player.getAbsorptionAmount();
    }
    
    public static boolean IsPlayerInHole() {
        final BlockPos blockPos = GetLocalPlayerPosFloored();
        final IBlockState blockState = WurstplusPlayerUtil.mc.world.getBlockState(blockPos);
        if (blockState.getBlock() != Blocks.AIR) {
            return false;
        }
        if (WurstplusPlayerUtil.mc.world.getBlockState(blockPos.up()).getBlock() != Blocks.AIR) {
            return false;
        }
        if (WurstplusPlayerUtil.mc.world.getBlockState(blockPos.down()).getBlock() == Blocks.AIR) {
            return false;
        }
        final BlockPos[] touchingBlocks = { blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west() };
        int validHorizontalBlocks = 0;
        for (final BlockPos touching : touchingBlocks) {
            final IBlockState touchingState = WurstplusPlayerUtil.mc.world.getBlockState(touching);
            if (touchingState.getBlock() != Blocks.AIR && touchingState.isFullBlock()) {
                ++validHorizontalBlocks;
            }
        }
        return validHorizontalBlocks >= 4;
    }
    
    public static boolean IsPlayerTrapped() {
        final BlockPos l_PlayerPos = GetLocalPlayerPosFloored();
        final BlockPos[] array;
        final BlockPos[] l_TrapPositions = array = new BlockPos[] { l_PlayerPos.down(), l_PlayerPos.up().up(), l_PlayerPos.north(), l_PlayerPos.south(), l_PlayerPos.east(), l_PlayerPos.west(), l_PlayerPos.north().up(), l_PlayerPos.south().up(), l_PlayerPos.east().up(), l_PlayerPos.west().up() };
        for (final BlockPos l_Pos : array) {
            final IBlockState l_State = WurstplusPlayerUtil.mc.world.getBlockState(l_Pos);
            if (l_State.getBlock() != Blocks.OBSIDIAN && WurstplusPlayerUtil.mc.world.getBlockState(l_Pos).getBlock() != Blocks.BEDROCK) {
                return false;
            }
        }
        return true;
    }
    
    public static FacingDirection GetFacing() {
        switch (MathHelper.floor(WurstplusPlayerUtil.mc.player.rotationYaw * 8.0f / 360.0f + 0.5) & 0x7) {
            case 0:
            case 1: {
                return FacingDirection.South;
            }
            case 2:
            case 3: {
                return FacingDirection.West;
            }
            case 4:
            case 5: {
                return FacingDirection.North;
            }
            case 6:
            case 7: {
                return FacingDirection.East;
            }
            default: {
                return FacingDirection.North;
            }
        }
    }
    
    public static void PacketFacePitchAndYaw(final float p_Pitch, final float p_Yaw) {
        final boolean l_IsSprinting = WurstplusPlayerUtil.mc.player.isSprinting();
        if (l_IsSprinting != WurstplusPlayerUtil.mc.player.serverSprintState) {
            if (l_IsSprinting) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusPlayerUtil.mc.player, CPacketEntityAction.Action.START_SPRINTING));
            }
            else {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusPlayerUtil.mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
            }
            WurstplusPlayerUtil.mc.player.serverSprintState = l_IsSprinting;
        }
        final boolean l_IsSneaking = WurstplusPlayerUtil.mc.player.isSneaking();
        if (l_IsSneaking != WurstplusPlayerUtil.mc.player.serverSneakState) {
            if (l_IsSneaking) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusPlayerUtil.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            }
            else {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusPlayerUtil.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            }
            WurstplusPlayerUtil.mc.player.serverSneakState = l_IsSneaking;
        }
        if (isCurrentViewEntity()) {
            final AxisAlignedBB axisalignedbb = WurstplusPlayerUtil.mc.player.getEntityBoundingBox();
            final double l_PosXDifference = WurstplusPlayerUtil.mc.player.posX - WurstplusPlayerUtil.mc.player.lastReportedPosX;
            final double l_PosYDifference = axisalignedbb.minY - WurstplusPlayerUtil.mc.player.lastReportedPosY;
            final double l_PosZDifference = WurstplusPlayerUtil.mc.player.posZ - WurstplusPlayerUtil.mc.player.lastReportedPosZ;
            final double l_YawDifference = p_Yaw - WurstplusPlayerUtil.mc.player.lastReportedYaw;
            final double l_RotationDifference = p_Pitch - WurstplusPlayerUtil.mc.player.lastReportedPitch;
            final EntityPlayerSP player = WurstplusPlayerUtil.mc.player;
            ++player.positionUpdateTicks;
            boolean l_MovedXYZ = l_PosXDifference * l_PosXDifference + l_PosYDifference * l_PosYDifference + l_PosZDifference * l_PosZDifference > 9.0E-4 || WurstplusPlayerUtil.mc.player.positionUpdateTicks >= 20;
            final boolean l_MovedRotation = l_YawDifference != 0.0 || l_RotationDifference != 0.0;
            if (WurstplusPlayerUtil.mc.player.isRiding()) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(WurstplusPlayerUtil.mc.player.motionX, -999.0, WurstplusPlayerUtil.mc.player.motionZ, p_Yaw, p_Pitch, WurstplusPlayerUtil.mc.player.onGround));
                l_MovedXYZ = false;
            }
            else if (l_MovedXYZ && l_MovedRotation) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer.PositionRotation(WurstplusPlayerUtil.mc.player.posX, axisalignedbb.minY, WurstplusPlayerUtil.mc.player.posZ, p_Yaw, p_Pitch, WurstplusPlayerUtil.mc.player.onGround));
            }
            else if (l_MovedXYZ) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(WurstplusPlayerUtil.mc.player.posX, axisalignedbb.minY, WurstplusPlayerUtil.mc.player.posZ, WurstplusPlayerUtil.mc.player.onGround));
            }
            else if (l_MovedRotation) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(p_Yaw, p_Pitch, WurstplusPlayerUtil.mc.player.onGround));
            }
            else if (WurstplusPlayerUtil.mc.player.prevOnGround != WurstplusPlayerUtil.mc.player.onGround) {
                WurstplusPlayerUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer(WurstplusPlayerUtil.mc.player.onGround));
            }
            if (l_MovedXYZ) {
                WurstplusPlayerUtil.mc.player.lastReportedPosX = WurstplusPlayerUtil.mc.player.posX;
                WurstplusPlayerUtil.mc.player.lastReportedPosY = axisalignedbb.minY;
                WurstplusPlayerUtil.mc.player.lastReportedPosZ = WurstplusPlayerUtil.mc.player.posZ;
                WurstplusPlayerUtil.mc.player.positionUpdateTicks = 0;
            }
            if (l_MovedRotation) {
                WurstplusPlayerUtil.mc.player.lastReportedYaw = p_Yaw;
                WurstplusPlayerUtil.mc.player.lastReportedPitch = p_Pitch;
            }
            WurstplusPlayerUtil.mc.player.prevOnGround = WurstplusPlayerUtil.mc.player.onGround;
        }
    }
    
    static {
        WurstplusPlayerUtil.mc = Minecraft.getMinecraft();
    }
    
    public enum FacingDirection
    {
        North, 
        South, 
        East, 
        West;
    }
}
