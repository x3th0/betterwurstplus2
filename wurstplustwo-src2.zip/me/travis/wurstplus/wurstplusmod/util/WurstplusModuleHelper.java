package me.travis.wurstplus.wurstplusmod.util;

import net.minecraft.client.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import java.util.function.*;

public class WurstplusModuleHelper
{
    public Minecraft mc;
    public BlockPos pos;
    public Integer totems;
    public String holeType;
    
    public WurstplusModuleHelper() {
        this.mc = Minecraft.getMinecraft();
    }
    
    public Boolean getPlayerPos() {
        try {
            this.pos = new BlockPos(Math.floor(this.mc.player.posX), Math.floor(this.mc.player.posY), Math.floor(this.mc.player.posZ));
            return false;
        }
        catch (Exception e) {
            return true;
        }
    }
    
    public String getHoleType() {
        if (this.getPlayerPos()) {
            return "�4 0";
        }
        this.getPlayerPos();
        if (this.mc.world.getBlockState(this.pos.add(0, -1, 0)).getBlock() == Blocks.BEDROCK && this.mc.world.getBlockState(this.pos.add(1, 0, 0)).getBlock() == Blocks.BEDROCK && this.mc.world.getBlockState(this.pos.add(0, 0, 1)).getBlock() == Blocks.BEDROCK && this.mc.world.getBlockState(this.pos.add(-1, 0, 0)).getBlock() == Blocks.BEDROCK && this.mc.world.getBlockState(this.pos.add(0, 0, -1)).getBlock() == Blocks.BEDROCK) {
            return this.holeType = "�a Safe";
        }
        if ((this.mc.world.getBlockState(this.pos.add(0, -1, 0)).getBlock() == Blocks.BEDROCK | this.mc.world.getBlockState(this.pos.add(0, -1, 0)).getBlock() == Blocks.OBSIDIAN) && (this.mc.world.getBlockState(this.pos.add(1, 0, 0)).getBlock() == Blocks.BEDROCK | this.mc.world.getBlockState(this.pos.add(1, 0, 0)).getBlock() == Blocks.OBSIDIAN) && (this.mc.world.getBlockState(this.pos.add(0, 0, 1)).getBlock() == Blocks.BEDROCK | this.mc.world.getBlockState(this.pos.add(0, 0, 1)).getBlock() == Blocks.OBSIDIAN) && (this.mc.world.getBlockState(this.pos.add(-1, 0, 0)).getBlock() == Blocks.BEDROCK | this.mc.world.getBlockState(this.pos.add(-1, 0, 0)).getBlock() == Blocks.OBSIDIAN) && (this.mc.world.getBlockState(this.pos.add(0, 0, -1)).getBlock() == Blocks.BEDROCK | this.mc.world.getBlockState(this.pos.add(0, 0, -1)).getBlock() == Blocks.OBSIDIAN)) {
            return this.holeType = "�3 Unsafe";
        }
        return this.holeType = "�4 None";
    }
    
    public String getFps() {
        final Minecraft mc = this.mc;
        final int fps = Minecraft.getDebugFPS();
        if (fps >= 60) {
            return "�a" + Integer.toString(fps);
        }
        if (fps >= 30) {
            return "�3" + Integer.toString(fps);
        }
        return "�4" + Integer.toString(fps);
    }
    
    public String getPing() {
        try {
            final int ping = this.mc.getConnection().getPlayerInfo(this.mc.player.getUniqueID()).getResponseTime();
            if (ping <= 50) {
                return "�a" + Integer.toString(ping);
            }
            if (ping <= 150) {
                return "�3" + Integer.toString(ping);
            }
            return "�4" + Integer.toString(ping);
        }
        catch (Exception e) {
            return "oh no";
        }
    }
    
    public String getTotems() {
        try {
            this.totems = this.offhand() + this.mc.player.inventory.mainInventory.stream().filter(itemStack -> itemStack.getItem() == Items.TOTEM_OF_UNDYING).mapToInt(ItemStack::func_190916_E).sum();
            if (this.totems > 1) {
                return "�a " + this.totems;
            }
            return "�4 " + this.totems;
        }
        catch (Exception e) {
            return "0";
        }
    }
    
    public Integer offhand() {
        if (this.mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) {
            return 1;
        }
        return 0;
    }
}
