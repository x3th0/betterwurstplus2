package me.travis.wurstplus.wurstplusmod.util;

import java.util.*;

public final class WurstplusTimeUtil
{
    public static Calendar c;
    
    public static Integer get_hour() {
        return Calendar.getInstance().get(11);
    }
    
    public static Integer get_day() {
        return Calendar.getInstance().get(5);
    }
    
    public static Integer get_month() {
        return Calendar.getInstance().get(2);
    }
    
    public static Integer get_minuite() {
        return Calendar.getInstance().get(12);
    }
    
    public static Integer get_second() {
        return Calendar.getInstance().get(13);
    }
    
    static {
        WurstplusTimeUtil.c = Calendar.getInstance();
    }
}
