package me.travis.wurstplus.wurstplusmod.util;

import java.util.*;
import com.google.common.collect.*;
import java.net.*;
import org.apache.commons.io.*;
import org.json.simple.*;
import java.io.*;
import org.json.simple.parser.*;

public class WurstplusNetworkUtil
{
    private final Map<String, String> uuidNameCache;
    
    public WurstplusNetworkUtil() {
        this.uuidNameCache = (Map<String, String>)Maps.newConcurrentMap();
    }
    
    public String resolveName(String uuid) {
        uuid = uuid.replace("-", "");
        if (this.uuidNameCache.containsKey(uuid)) {
            return this.uuidNameCache.get(uuid);
        }
        final String url = "https://api.mojang.com/user/profiles/" + uuid + "/names";
        try {
            final String nameJson = IOUtils.toString(new URL(url));
            if (nameJson != null && nameJson.length() > 0) {
                final JSONArray jsonArray = (JSONArray)JSONValue.parseWithException(nameJson);
                if (jsonArray != null) {
                    final JSONObject latestName = jsonArray.get(jsonArray.size() - 1);
                    if (latestName != null) {
                        return latestName.get("name").toString();
                    }
                }
            }
        }
        catch (IOException ex) {}
        catch (ParseException ex2) {}
        return null;
    }
}
