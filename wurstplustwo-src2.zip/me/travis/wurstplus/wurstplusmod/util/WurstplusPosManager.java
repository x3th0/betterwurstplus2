package me.travis.wurstplus.wurstplusmod.util;

import net.minecraft.client.*;

public class WurstplusPosManager
{
    private static double x;
    private static double y;
    private static double z;
    private static boolean onground;
    private static final Minecraft mc;
    
    public static void updatePosition() {
        WurstplusPosManager.x = WurstplusPosManager.mc.player.posX;
        WurstplusPosManager.y = WurstplusPosManager.mc.player.posY;
        WurstplusPosManager.z = WurstplusPosManager.mc.player.posZ;
        WurstplusPosManager.onground = WurstplusPosManager.mc.player.onGround;
    }
    
    public static void restorePosition() {
        WurstplusPosManager.mc.player.posX = WurstplusPosManager.x;
        WurstplusPosManager.mc.player.posY = WurstplusPosManager.y;
        WurstplusPosManager.mc.player.posZ = WurstplusPosManager.z;
        WurstplusPosManager.mc.player.onGround = WurstplusPosManager.onground;
    }
    
    static {
        mc = Minecraft.getMinecraft();
    }
}
