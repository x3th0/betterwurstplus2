package me.travis.wurstplus.wurstplusmod.util;

import net.minecraft.entity.*;
import net.minecraft.client.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import java.util.stream.*;
import net.minecraft.entity.player.*;
import java.util.*;

public class WurstplusOnlineFriends
{
    public static List<Entity> entities;
    
    public static List<Entity> getFriends() {
        WurstplusOnlineFriends.entities.clear();
        WurstplusOnlineFriends.entities.addAll((Collection<? extends Entity>)Minecraft.getMinecraft().world.playerEntities.stream().filter(entityPlayer -> WurstplusFriendManager.isFriend(entityPlayer.getName())).collect(Collectors.toList()));
        return WurstplusOnlineFriends.entities;
    }
    
    static {
        WurstplusOnlineFriends.entities = new ArrayList<Entity>();
    }
}
