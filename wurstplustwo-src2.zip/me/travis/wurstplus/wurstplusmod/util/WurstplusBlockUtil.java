package me.travis.wurstplus.wurstplusmod.util;

import net.minecraft.client.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.client.entity.*;
import net.minecraft.init.*;
import java.util.*;

public class WurstplusBlockUtil
{
    private static final Minecraft mc;
    public static List<Block> emptyBlocks;
    public static List<Block> rightclickableBlocks;
    
    public static boolean canSeeBlock(final BlockPos p_Pos) {
        return WurstplusBlockUtil.mc.player != null && WurstplusBlockUtil.mc.world.rayTraceBlocks(new Vec3d(WurstplusBlockUtil.mc.player.posX, WurstplusBlockUtil.mc.player.posY + WurstplusBlockUtil.mc.player.getEyeHeight(), WurstplusBlockUtil.mc.player.posZ), new Vec3d((double)p_Pos.getX(), (double)p_Pos.getY(), (double)p_Pos.getZ()), false, true, false) == null;
    }
    
    public static void placeCrystalOnBlock(final BlockPos pos, final EnumHand hand) {
        final RayTraceResult result = WurstplusBlockUtil.mc.world.rayTraceBlocks(new Vec3d(WurstplusBlockUtil.mc.player.posX, WurstplusBlockUtil.mc.player.posY + WurstplusBlockUtil.mc.player.getEyeHeight(), WurstplusBlockUtil.mc.player.posZ), new Vec3d(pos.getX() + 0.5, pos.getY() - 0.5, pos.getZ() + 0.5));
        final EnumFacing facing = (result == null || result.sideHit == null) ? EnumFacing.UP : result.sideHit;
        WurstplusBlockUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0f, 0.0f, 0.0f));
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos pos, final boolean shouldCheck, final float height) {
        return !shouldCheck || WurstplusBlockUtil.mc.world.rayTraceBlocks(new Vec3d(WurstplusBlockUtil.mc.player.posX, WurstplusBlockUtil.mc.player.posY + WurstplusBlockUtil.mc.player.getEyeHeight(), WurstplusBlockUtil.mc.player.posZ), new Vec3d((double)pos.getX(), (double)(pos.getY() + height), (double)pos.getZ()), false, true, false) == null;
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos pos, final boolean shouldCheck) {
        return rayTracePlaceCheck(pos, shouldCheck, 1.0f);
    }
    
    public static boolean rayTracePlaceCheck(final BlockPos pos) {
        return rayTracePlaceCheck(pos, true);
    }
    
    public static void openBlock(final BlockPos pos) {
        final EnumFacing[] values;
        final EnumFacing[] facings = values = EnumFacing.values();
        for (final EnumFacing f : values) {
            final Block neighborBlock = WurstplusBlockUtil.mc.world.getBlockState(pos.offset(f)).getBlock();
            if (WurstplusBlockUtil.emptyBlocks.contains(neighborBlock)) {
                WurstplusBlockUtil.mc.playerController.processRightClickBlock(WurstplusBlockUtil.mc.player, WurstplusBlockUtil.mc.world, pos, f.getOpposite(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
                return;
            }
        }
    }
    
    public static boolean placeBlock(final BlockPos pos, final int slot, final boolean rotate, final boolean rotateBack) {
        if (isBlockEmpty(pos)) {
            if (slot != WurstplusBlockUtil.mc.player.inventory.currentItem) {
                WurstplusBlockUtil.mc.player.inventory.currentItem = slot;
            }
            final EnumFacing[] values;
            final EnumFacing[] facings = values = EnumFacing.values();
            for (final EnumFacing f : values) {
                final Block neighborBlock = WurstplusBlockUtil.mc.world.getBlockState(pos.offset(f)).getBlock();
                final Vec3d vec = new Vec3d(pos.getX() + 0.5 + f.getXOffset() * 0.5, pos.getY() + 0.5 + f.getYOffset() * 0.5, pos.getZ() + 0.5 + f.getZOffset() * 0.5);
                if (!WurstplusBlockUtil.emptyBlocks.contains(neighborBlock) && WurstplusBlockUtil.mc.player.getPositionEyes(WurstplusBlockUtil.mc.getRenderPartialTicks()).distanceTo(vec) <= 4.25) {
                    final float[] rot = { WurstplusBlockUtil.mc.player.rotationYaw, WurstplusBlockUtil.mc.player.rotationPitch };
                    if (rotate) {
                        rotatePacket(vec.x, vec.y, vec.z);
                    }
                    if (WurstplusBlockUtil.rightclickableBlocks.contains(neighborBlock)) {
                        WurstplusBlockUtil.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusBlockUtil.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                    }
                    WurstplusBlockUtil.mc.playerController.processRightClickBlock(WurstplusBlockUtil.mc.player, WurstplusBlockUtil.mc.world, pos.offset(f), f.getOpposite(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
                    if (WurstplusBlockUtil.rightclickableBlocks.contains(neighborBlock)) {
                        WurstplusBlockUtil.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)WurstplusBlockUtil.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                    }
                    if (rotateBack) {
                        WurstplusBlockUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(rot[0], rot[1], WurstplusBlockUtil.mc.player.onGround));
                    }
                    return true;
                }
            }
        }
        return false;
    }
    
    public static boolean isBlockEmpty(final BlockPos pos) {
        if (WurstplusBlockUtil.emptyBlocks.contains(WurstplusBlockUtil.mc.world.getBlockState(pos).getBlock())) {
            final AxisAlignedBB box = new AxisAlignedBB(pos);
            for (final Entity e : WurstplusBlockUtil.mc.world.loadedEntityList) {
                if (e instanceof EntityLivingBase && box.intersects(e.getEntityBoundingBox())) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    public static boolean canPlaceBlock(final BlockPos pos) {
        if (isBlockEmpty(pos)) {
            final EnumFacing[] values;
            final EnumFacing[] facings = values = EnumFacing.values();
            for (final EnumFacing f : values) {
                if (!WurstplusBlockUtil.emptyBlocks.contains(WurstplusBlockUtil.mc.world.getBlockState(pos.offset(f)).getBlock()) && WurstplusBlockUtil.mc.player.getPositionEyes(WurstplusBlockUtil.mc.getRenderPartialTicks()).distanceTo(new Vec3d(pos.getX() + 0.5 + f.getXOffset() * 0.5, pos.getY() + 0.5 + f.getYOffset() * 0.5, pos.getZ() + 0.5 + f.getZOffset() * 0.5)) <= 4.25) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static EnumFacing getClosestFacing(final BlockPos pos) {
        return EnumFacing.DOWN;
    }
    
    public static void rotateClient(final double x, final double y, final double z) {
        final double diffX = x - WurstplusBlockUtil.mc.player.posX;
        final double diffY = y - (WurstplusBlockUtil.mc.player.posY + WurstplusBlockUtil.mc.player.getEyeHeight());
        final double diffZ = z - WurstplusBlockUtil.mc.player.posZ;
        final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        final EntityPlayerSP player = WurstplusBlockUtil.mc.player;
        player.rotationYaw += MathHelper.wrapDegrees(yaw - WurstplusBlockUtil.mc.player.rotationYaw);
        final EntityPlayerSP player2 = WurstplusBlockUtil.mc.player;
        player2.rotationPitch += MathHelper.wrapDegrees(pitch - WurstplusBlockUtil.mc.player.rotationPitch);
    }
    
    public static void rotatePacket(final double x, final double y, final double z) {
        final double diffX = x - WurstplusBlockUtil.mc.player.posX;
        final double diffY = y - (WurstplusBlockUtil.mc.player.posY + WurstplusBlockUtil.mc.player.getEyeHeight());
        final double diffZ = z - WurstplusBlockUtil.mc.player.posZ;
        final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        WurstplusBlockUtil.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(yaw, pitch, WurstplusBlockUtil.mc.player.onGround));
    }
    
    static {
        mc = Minecraft.getMinecraft();
        WurstplusBlockUtil.emptyBlocks = Arrays.asList(Blocks.AIR, Blocks.FLOWING_LAVA, Blocks.LAVA, Blocks.FLOWING_WATER, Blocks.WATER, Blocks.VINE, Blocks.SNOW_LAYER, Blocks.TALLGRASS, Blocks.FIRE);
        WurstplusBlockUtil.rightclickableBlocks = Arrays.asList(Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.ENDER_CHEST, Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX, Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX, Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.SILVER_SHULKER_BOX, Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX, Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX, Blocks.BLACK_SHULKER_BOX, Blocks.ANVIL, Blocks.WOODEN_BUTTON, Blocks.STONE_BUTTON, Blocks.UNPOWERED_COMPARATOR, Blocks.UNPOWERED_REPEATER, Blocks.POWERED_REPEATER, Blocks.POWERED_COMPARATOR, Blocks.OAK_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.BIRCH_FENCE_GATE, Blocks.JUNGLE_FENCE_GATE, Blocks.DARK_OAK_FENCE_GATE, Blocks.ACACIA_FENCE_GATE, Blocks.BREWING_STAND, Blocks.DISPENSER, Blocks.DROPPER, Blocks.LEVER, Blocks.NOTEBLOCK, Blocks.JUKEBOX, Blocks.BEACON, Blocks.BED, Blocks.FURNACE, Blocks.OAK_DOOR, Blocks.SPRUCE_DOOR, Blocks.BIRCH_DOOR, Blocks.JUNGLE_DOOR, Blocks.ACACIA_DOOR, Blocks.DARK_OAK_DOOR, Blocks.CAKE, Blocks.ENCHANTING_TABLE, Blocks.DRAGON_EGG, Blocks.HOPPER, Blocks.REPEATING_COMMAND_BLOCK, Blocks.COMMAND_BLOCK, Blocks.CHAIN_COMMAND_BLOCK, Blocks.CRAFTING_TABLE);
    }
}
