package me.travis.wurstplus.wurstplusmod.util.forgehax;

import net.minecraftforge.fml.relauncher.*;
import net.minecraft.client.renderer.*;

@SideOnly(Side.CLIENT)
public class Tessellator
{
    private final BufferBuilder buffer;
    private final WorldVertexBufferUploader vboUploader;
    private static final Tessellator INSTANCE;
    
    public static Tessellator getInstance() {
        return Tessellator.INSTANCE;
    }
    
    public Tessellator(final int bufferSize) {
        this.vboUploader = new WorldVertexBufferUploader();
        this.buffer = new BufferBuilder(bufferSize);
    }
    
    public void draw() {
        this.buffer.finishDrawing();
        this.vboUploader.draw(this.buffer);
    }
    
    public BufferBuilder getBuffer() {
        return this.buffer;
    }
    
    static {
        INSTANCE = new Tessellator(2097152);
    }
}
