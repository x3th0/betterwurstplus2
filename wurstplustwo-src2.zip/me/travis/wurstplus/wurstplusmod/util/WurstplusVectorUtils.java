package me.travis.wurstplus.wurstplusmod.util;

public class WurstplusVectorUtils
{
}
