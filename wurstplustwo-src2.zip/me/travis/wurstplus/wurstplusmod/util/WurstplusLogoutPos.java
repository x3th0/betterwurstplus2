package me.travis.wurstplus.wurstplusmod.util;

import java.util.*;
import net.minecraft.util.math.*;

public class WurstplusLogoutPos
{
    final UUID id;
    final String name;
    final Vec3d maxs;
    final Vec3d mins;
    
    public WurstplusLogoutPos(final UUID uuid, final String name, final Vec3d maxs, final Vec3d mins) {
        this.id = uuid;
        this.name = name;
        this.maxs = maxs;
        this.mins = mins;
    }
    
    public UUID get_id() {
        return this.id;
    }
    
    public String get_name() {
        return this.name;
    }
    
    public Vec3d get_maxs() {
        return this.maxs;
    }
    
    public Vec3d get_mins() {
        return this.mins;
    }
    
    public Vec3d get_top_vec() {
        return new Vec3d((this.get_mins().x + this.get_maxs().x) / 2.0, this.get_maxs().y, (this.get_mins().z + this.get_maxs().z) / 2.0);
    }
}
