package me.travis.wurstplus.wurstplusmod.util;

import net.minecraft.entity.*;
import net.minecraft.item.*;
import java.util.*;
import net.minecraft.util.math.*;

public class WurstplusLogInfo
{
    private Entity entity;
    private String name;
    private String time;
    private double health;
    private Iterable<ItemStack> held_items;
    private Iterator<ItemStack> armor;
    private AxisAlignedBB bb;
    
    public WurstplusLogInfo(final Entity entity, final String name, final String time, final double health, final Iterable<ItemStack> held_items, final Iterator<ItemStack> armor, final AxisAlignedBB bb) {
        this.entity = entity;
        this.name = name;
        this.time = time;
        this.health = health;
        this.held_items = held_items;
        this.armor = armor;
        this.bb = bb;
    }
    
    public String get_name() {
        return this.name;
    }
    
    public double get_health() {
        return this.health;
    }
    
    public Iterable<ItemStack> get_held_items() {
        return this.held_items;
    }
    
    public Iterator<ItemStack> get_armor() {
        return this.armor;
    }
    
    public String get_time() {
        return this.time;
    }
    
    public Entity get_entity() {
        return this.entity;
    }
    
    public AxisAlignedBB get_bb() {
        return this.bb;
    }
}
