package me.travis.wurstplus.wurstplusmod.util;

public class WurstplusColourUtils
{
    public static int rgb_to_hex(final int r, final int g, final int b) {
        return to_hex(r) + to_hex(g) + to_hex(b);
    }
    
    public static int to_hex(int n) {
        n = Math.max(0, Math.min(n, 255));
        return "0123456789ABCDEF".charAt((n - n % 16) / 16) + "0123456789ABCDEF".charAt(n % 16);
    }
}
