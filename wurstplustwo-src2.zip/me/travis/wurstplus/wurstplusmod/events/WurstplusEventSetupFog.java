package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;

public class WurstplusEventSetupFog extends WurstplusEventCancellable
{
    public int start_coords;
    public float partial_ticks;
    
    public WurstplusEventSetupFog(final int coords, final float ticks) {
        this.start_coords = coords;
        this.partial_ticks = ticks;
    }
}
