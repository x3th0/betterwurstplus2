package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;

public class WurstplusEventPlayerJump extends WurstplusEventCancellable
{
    public double motion_x;
    public double motion_y;
    
    public WurstplusEventPlayerJump(final double motion_x, final double motion_y) {
        this.motion_x = motion_x;
        this.motion_y = motion_y;
    }
}
