package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;

public class WurstplusEventPlayerTravel extends WurstplusEventCancellable
{
    public float Strafe;
    public float Vertical;
    public float Forward;
    
    public WurstplusEventPlayerTravel(final float p_Strafe, final float p_Vertical, final float p_Forward) {
        this.Strafe = p_Strafe;
        this.Vertical = p_Vertical;
        this.Forward = p_Forward;
    }
}
