package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;
import net.minecraft.entity.*;

public class WurstplusEventEntityRemoved extends WurstplusEventCancellable
{
    private final Entity entity;
    
    public WurstplusEventEntityRemoved(final Entity entity) {
        this.entity = entity;
    }
    
    public Entity get_entity() {
        return this.entity;
    }
}
