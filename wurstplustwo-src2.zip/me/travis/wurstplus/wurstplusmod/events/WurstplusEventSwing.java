package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;
import net.minecraft.util.*;

public class WurstplusEventSwing extends WurstplusEventCancellable
{
    public EnumHand hand;
    
    public WurstplusEventSwing(final EnumHand hand) {
        this.hand = hand;
    }
}
