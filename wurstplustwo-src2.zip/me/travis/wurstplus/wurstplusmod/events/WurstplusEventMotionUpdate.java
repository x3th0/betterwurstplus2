package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;

public class WurstplusEventMotionUpdate extends WurstplusEventCancellable
{
    public int stage;
    
    public WurstplusEventMotionUpdate(final int stage) {
        this.stage = stage;
    }
}
