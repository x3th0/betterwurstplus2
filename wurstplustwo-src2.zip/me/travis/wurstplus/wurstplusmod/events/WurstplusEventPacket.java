package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;
import net.minecraft.network.*;

public class WurstplusEventPacket extends WurstplusEventCancellable
{
    private final Packet packet;
    
    public WurstplusEventPacket(final Packet packet) {
        this.packet = packet;
    }
    
    public Packet get_packet() {
        return this.packet;
    }
    
    public static class ReceivePacket extends WurstplusEventPacket
    {
        public ReceivePacket(final Packet packet) {
            super(packet);
        }
    }
    
    public static class SendPacket extends WurstplusEventPacket
    {
        public SendPacket(final Packet packet) {
            super(packet);
        }
    }
}
