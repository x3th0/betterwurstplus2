package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;

public class WurstplusBlockEvent extends WurstplusEventCancellable
{
    public BlockPos pos;
    public EnumFacing facing;
    private int stage;
    
    public WurstplusBlockEvent(final int stage, final BlockPos pos, final EnumFacing facing) {
        this.pos = pos;
        this.facing = facing;
        this.stage = stage;
    }
    
    public void set_stage(final int stage) {
        this.stage = stage;
    }
    
    public int get_stage() {
        return this.stage;
    }
}
