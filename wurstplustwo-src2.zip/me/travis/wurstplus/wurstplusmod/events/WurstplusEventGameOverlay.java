package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;
import net.minecraft.client.gui.*;

public class WurstplusEventGameOverlay extends WurstplusEventCancellable
{
    public float partial_ticks;
    private ScaledResolution scaled_resolution;
    
    public WurstplusEventGameOverlay(final float partial_ticks, final ScaledResolution scaled_resolution) {
        this.partial_ticks = partial_ticks;
        this.scaled_resolution = scaled_resolution;
    }
    
    public ScaledResolution get_scaled_resoltion() {
        return this.scaled_resolution;
    }
}
