package me.travis.wurstplus.wurstplusmod.events;

import me.travis.wurstplus.external.*;
import net.minecraft.client.gui.*;

public class WurstplusEventGUIScreen extends WurstplusEventCancellable
{
    private final GuiScreen guiscreen;
    
    public WurstplusEventGUIScreen(final GuiScreen screen) {
        this.guiscreen = screen;
    }
    
    public GuiScreen get_guiscreen() {
        return this.guiscreen;
    }
}
