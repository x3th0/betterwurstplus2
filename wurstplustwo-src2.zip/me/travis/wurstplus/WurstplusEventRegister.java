package me.travis.wurstplus;

import net.minecraftforge.common.*;
import me.travis.wurstplus.wurstplusmod.manager.*;

public class WurstplusEventRegister
{
    public static void register_command_manager(final WurstplusCommandManager manager) {
        MinecraftForge.EVENT_BUS.register((Object)manager);
    }
    
    public static void register_module_manager(final WurstplusEventManager manager) {
        MinecraftForge.EVENT_BUS.register((Object)manager);
    }
}
