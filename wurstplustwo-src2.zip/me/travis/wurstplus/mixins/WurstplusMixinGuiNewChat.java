package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import me.travis.wurstplus.*;
import net.minecraft.client.gui.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ GuiNewChat.class })
public abstract class WurstplusMixinGuiNewChat
{
    @Redirect(method = { "drawChat" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V", ordinal = 0))
    private void overrideChatBackgroundColour(final int left, final int top, final int right, final int bottom, final int color) {
        if (!Wurstplus.get_module_manager().get_module_with_tag("ClearChatbox").is_active()) {
            Gui.drawRect(left, top, right, bottom, color);
        }
    }
}
