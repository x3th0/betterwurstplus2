package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.wurstplus.external.*;
import org.spongepowered.asm.mixin.injection.*;
import net.minecraft.entity.*;

@Mixin({ Entity.class })
public abstract class WurstplusMixinEntity
{
    @Shadow
    public double motionX;
    @Shadow
    public double motionY;
    @Shadow
    public double motionZ;
    
    @Redirect(method = { "applyEntityCollision" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;addVelocity(DDD)V"))
    public void velocity(final Entity entity, final double x, final double y, final double z) {
        final WurstplusEventEntity.WurstplusEventColision event = new WurstplusEventEntity.WurstplusEventColision(entity, x, y, z);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event);
        if (event.isCancelled()) {
            return;
        }
        entity.motionX += x;
        entity.motionY += y;
        entity.motionZ += z;
        entity.isAirBorne = true;
    }
    
    @Shadow
    public void move(final MoverType type, final double x, final double y, final double z) {
    }
}
