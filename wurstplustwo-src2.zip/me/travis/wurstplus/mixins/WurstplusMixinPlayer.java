package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.entity.player.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.wurstplus.external.*;
import net.minecraft.entity.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ EntityPlayer.class })
public class WurstplusMixinPlayer extends WurstplusMixinEntity
{
    @Inject(method = { "travel" }, at = { @At("HEAD") }, cancellable = true)
    public void travel(final float strafe, final float vertical, final float forward, final CallbackInfo info) {
        final WurstplusEventPlayerTravel event_packet = new WurstplusEventPlayerTravel(strafe, vertical, forward);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event_packet);
        if (event_packet.isCancelled()) {
            this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
            info.cancel();
        }
    }
}
