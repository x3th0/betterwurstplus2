package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.wurstplus.external.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ World.class })
public class WurstplusMixinWorld
{
    @Inject(method = { "onEntityRemoved" }, at = { @At("HEAD") }, cancellable = true)
    public void onEntityRemoved(final Entity event_packet, final CallbackInfo p_Info) {
        final WurstplusEventEntityRemoved l_Event = new WurstplusEventEntityRemoved(event_packet);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(l_Event);
    }
}
