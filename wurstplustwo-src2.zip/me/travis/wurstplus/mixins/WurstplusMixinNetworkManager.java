package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import io.netty.channel.*;
import net.minecraft.network.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import org.spongepowered.asm.mixin.injection.*;
import me.travis.wurstplus.external.*;

@Mixin({ NetworkManager.class })
public class WurstplusMixinNetworkManager
{
    @Inject(method = { "channelRead0" }, at = { @At("HEAD") }, cancellable = true)
    private void receive(final ChannelHandlerContext context, final Packet<?> packet, final CallbackInfo callback) {
        final WurstplusEventPacket event_packet = new WurstplusEventPacket.ReceivePacket(packet);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event_packet);
        if (event_packet.isCancelled()) {
            callback.cancel();
        }
    }
    
    @Inject(method = { "sendPacket(Lnet/minecraft/network/Packet;)V" }, at = { @At("HEAD") }, cancellable = true)
    private void send(final Packet<?> packet, final CallbackInfo callback) {
        final WurstplusEventPacket event_packet = new WurstplusEventPacket.SendPacket(packet);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event_packet);
        if (event_packet.isCancelled()) {
            callback.cancel();
        }
    }
    
    @Inject(method = { "exceptionCaught" }, at = { @At("HEAD") }, cancellable = true)
    private void exception(final ChannelHandlerContext exc, final Throwable exc_, final CallbackInfo callback) {
        if (exc_ instanceof Exception && WurstplusNoPacketKick.is_active()) {
            callback.cancel();
        }
    }
}
