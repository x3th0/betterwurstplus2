package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import me.travis.wurstplus.external.*;
import me.travis.wurstplus.*;
import net.minecraft.crash.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ Minecraft.class })
public class WurstplusMixinMinecraft
{
    @Inject(method = { "displayGuiScreen" }, at = { @At("HEAD") })
    private void displayGuiScreen(final GuiScreen guiScreenIn, final CallbackInfo info) {
        final WurstplusEventGUIScreen guiscreen = new WurstplusEventGUIScreen(guiScreenIn);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(guiscreen);
    }
    
    @Inject(method = { "shutdown" }, at = { @At("HEAD") })
    private void shutdown(final CallbackInfo info) {
        Wurstplus.send_client_log("The client were saved.");
        Wurstplus.get_config_manager().save_values();
        Wurstplus.get_config_manager().save_binds();
        Wurstplus.get_config_manager().save_client();
        Wurstplus.get_config_manager().save_log();
    }
    
    @Redirect(method = { "run" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"))
    private void crash(final Minecraft minecraft, final CrashReport crash) {
        Wurstplus.send_client_log("The client were saved before crash.");
        Wurstplus.send_client_log(crash.getCrashCause() + ": " + crash.getDescription());
        Wurstplus.get_config_manager().save_log();
    }
}
