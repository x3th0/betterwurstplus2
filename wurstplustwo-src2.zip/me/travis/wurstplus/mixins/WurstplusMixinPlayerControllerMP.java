package me.travis.wurstplus.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.block.state.*;
import net.minecraft.entity.player.*;
import net.minecraft.world.*;
import net.minecraft.util.math.*;
import me.travis.wurstplus.*;
import net.minecraft.util.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import me.travis.wurstplus.external.*;
import me.travis.wurstplus.wurstplusmod.events.*;
import org.spongepowered.asm.mixin.injection.*;

@Mixin({ PlayerControllerMP.class })
public class WurstplusMixinPlayerControllerMP
{
    @Redirect(method = { "onPlayerDamageBlock" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/block/state/IBlockState;getPlayerRelativeBlockHardness(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)F"))
    private float onPlayerDamageBlockSpeed(final IBlockState state, final EntityPlayer player, final World world, final BlockPos pos) {
        return state.getPlayerRelativeBlockHardness(player, world, pos) * (Wurstplus.get_event_handler().get_tick_rate() / 20.0f);
    }
    
    @Inject(method = { "onPlayerDamageBlock" }, at = { @At("HEAD") }, cancellable = true)
    public void onPlayerDamageBlock(final BlockPos posBlock, final EnumFacing directionFacing, final CallbackInfoReturnable<Boolean> info) {
        final WurstplusEventDamageBlock event_packet = new WurstplusEventDamageBlock(posBlock, directionFacing);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event_packet);
        if (event_packet.isCancelled()) {
            info.setReturnValue(false);
            info.cancel();
        }
        final WurstplusBlockEvent event = new WurstplusBlockEvent(4, posBlock, directionFacing);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event);
    }
    
    @Inject(method = { "clickBlock" }, at = { @At("HEAD") }, cancellable = true)
    private void clickBlockHook(final BlockPos pos, final EnumFacing face, final CallbackInfoReturnable<Boolean> info) {
        final WurstplusBlockEvent event = new WurstplusBlockEvent(3, pos, face);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.post(event);
    }
}
