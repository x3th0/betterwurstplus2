package me.travis.wurstplus;

import net.minecraftforge.fml.common.*;
import me.travis.wurstplus.wurstplusmod.manager.*;
import me.travis.wurstplus.wurstplusmod.guiscreen.*;
import me.travis.travis.*;
import com.mojang.realmsclient.gui.*;
import net.minecraftforge.fml.common.event.*;
import me.travis.wurstplus.external.*;
import org.lwjgl.opengl.*;
import org.apache.logging.log4j.*;
import me.travis.wurstplus.wurstplusmod.*;
import java.util.*;
import java.text.*;
import net.minecraft.client.*;
import me.travis.travis.task.*;

@Mod(modid = "wurstplus", version = "1.0")
public class Wurstplus
{
    @Mod.Instance
    private static Wurstplus MASTER;
    public static final String WURSTPLUS_NAME = "Wurst+ 2";
    public static final String WURSTPLUS_VERSION = "1.0";
    public static final String WURSTPLUS_SPACE = " ";
    public static final String WURSTPLUS_SIGN = " ";
    public static final int WURSTPLUS_KEY_GUI = 54;
    public static final int WURSTPLUS_KEY_DELETE = 211;
    public static final int WURSTPLUS_KEY_GUI_ESCAPE = 1;
    public static Logger wurstplus_register_log;
    public static WurstplusCommandManager command_manager;
    public static WurstplusSettingManager setting_manager;
    public static WurstplusConfigManager config_manager;
    public static WurstplusModuleManager module_manager;
    public static WurstplusEventManager event_manager;
    public static WurstplusHUDManager hud_manager;
    public static WurstplusFriendManager friend_manager;
    public static WurstplusEnemyManager enemy_manager;
    public static WurstplusDrawnManager drawn_manager;
    public static WurstplusDiscordManager discord_manager;
    public static WurstplusGUI click_gui;
    public static WurstplusHUD click_hud;
    public static Travis travis;
    public static ChatFormatting g;
    public static ChatFormatting r;
    
    @Mod.EventHandler
    public void WurstplusStarting(final FMLInitializationEvent event) {
        this.init_log("Wurst+ 2");
        send_minecraft_log("Loading packages initializing in main class. [Wurstplus.class]");
        WurstplusEventHandler.INSTANCE = new WurstplusEventHandler();
        Wurstplus.setting_manager = new WurstplusSettingManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.command_manager = new WurstplusCommandManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.config_manager = new WurstplusConfigManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.module_manager = new WurstplusModuleManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.event_manager = new WurstplusEventManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.friend_manager = new WurstplusFriendManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.enemy_manager = new WurstplusEnemyManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.drawn_manager = new WurstplusDrawnManager("<4><3><4><4><2><4><5><9><4><3><1>");
        Wurstplus.discord_manager = new WurstplusDiscordManager();
        Wurstplus.hud_manager = new WurstplusHUDManager("000000000000000000000000000000000");
        WurstplusDiscordManager.start();
        send_minecraft_log("Managers are initialed.");
        Display.setTitle("Wurst+ 2");
        Wurstplus.click_gui = new WurstplusGUI();
        Wurstplus.click_hud = new WurstplusHUD();
        send_minecraft_log("GUI and HUD initialed.");
        Wurstplus.travis = new Travis("Travis");
        send_minecraft_log("Travis framework initialed.");
        WurstplusEventRegister.register_command_manager(Wurstplus.command_manager);
        WurstplusEventRegister.register_module_manager(Wurstplus.event_manager);
        send_minecraft_log("Events registered.");
        send_minecraft_log("Client started.");
        Wurstplus.config_manager.load();
        if (Wurstplus.module_manager.get_module_with_tag("GUI").is_active()) {
            Wurstplus.module_manager.get_module_with_tag("GUI").set_active(false);
        }
        if (Wurstplus.module_manager.get_module_with_tag("HUD").is_active()) {
            Wurstplus.module_manager.get_module_with_tag("HUD").set_active(false);
        }
    }
    
    public void init_log(final String name) {
        Wurstplus.wurstplus_register_log = LogManager.getLogger(name);
        send_minecraft_log("...");
    }
    
    public static void dev(final String message) {
        WurstplusMessage.send_client_message(message);
    }
    
    public static Wurstplus get_instance() {
        return Wurstplus.MASTER;
    }
    
    public static void send_minecraft_log(final String log) {
        Wurstplus.wurstplus_register_log.info(log);
    }
    
    public static void send_client_log(final String log) {
        final Date hora = new Date();
        final String data = new SimpleDateFormat("HH:mm:ss:").format(hora);
        get_instance();
        Wurstplus.config_manager.send_log("<Wurst+ 2><" + data + "> " + log);
    }
    
    public static String get_name() {
        return "Wurst+ 2";
    }
    
    public static String get_version() {
        return "1.0";
    }
    
    public static String get_actual_user() {
        String player_requested = "NA";
        if (Minecraft.getMinecraft().player != null) {
            player_requested = Minecraft.getMinecraft().player.getName();
        }
        return player_requested;
    }
    
    public static WurstplusCommandManager get_command_manager() {
        return Wurstplus.command_manager;
    }
    
    public static WurstplusConfigManager get_config_manager() {
        return Wurstplus.config_manager;
    }
    
    public static WurstplusModuleManager get_module_manager() {
        return Wurstplus.module_manager;
    }
    
    public static WurstplusSettingManager get_setting_manager() {
        return Wurstplus.setting_manager;
    }
    
    public static WurstplusFriendManager get_friend_manager() {
        return Wurstplus.friend_manager;
    }
    
    public static WurstplusDrawnManager get_drawn_manager() {
        return Wurstplus.drawn_manager;
    }
    
    public static WurstplusHUDManager get_hud_manager() {
        return Wurstplus.hud_manager;
    }
    
    public static WurstplusEventHandler get_event_handler() {
        return WurstplusEventHandler.INSTANCE;
    }
    
    public static Travis get_travis() {
        return Wurstplus.travis;
    }
    
    public static String smoth(final String base) {
        return TravisFont.smoth(base);
    }
    
    static {
        Wurstplus.g = ChatFormatting.DARK_GRAY;
        Wurstplus.r = ChatFormatting.RESET;
    }
}
