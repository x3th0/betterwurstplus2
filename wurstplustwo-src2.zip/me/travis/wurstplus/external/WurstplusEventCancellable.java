package me.travis.wurstplus.external;

import me.zero.alpine.fork.event.type.*;
import net.minecraft.client.*;

public class WurstplusEventCancellable extends Cancellable
{
    private Era era_switch;
    private final float partial_ticks;
    
    public WurstplusEventCancellable() {
        this.era_switch = Era.EVENT_PRE;
        this.partial_ticks = Minecraft.getMinecraft().getRenderPartialTicks();
    }
    
    public Era get_era() {
        return this.era_switch;
    }
    
    public float get_partial_ticks() {
        return this.partial_ticks;
    }
    
    public enum Era
    {
        EVENT_PRE, 
        EVENT_PERI, 
        EVENT_POST;
    }
}
