package me.travis.wurstplus.external;

public class WurstplusNoPacketKick
{
    private static WurstplusNoPacketKick INSTANCE;
    
    public WurstplusNoPacketKick() {
        WurstplusNoPacketKick.INSTANCE = this;
    }
    
    public static boolean is_active() {
        final WurstplusNoPacketKick instance = WurstplusNoPacketKick.INSTANCE;
        return is_active();
    }
}
