package me.travis.wurstplus.external;

import me.travis.wurstplus.wurstplusmod.events.*;
import me.zero.alpine.fork.listener.*;
import net.minecraft.network.play.server.*;
import java.util.function.*;
import net.minecraft.util.math.*;
import java.util.*;

public class WurstplusEventHandler implements Listenable
{
    public static WurstplusEventHandler INSTANCE;
    static final float[] tick_rates;
    private long last_update_tick;
    private int next_index;
    @EventHandler
    private Listener<WurstplusEventPacket.ReceivePacket> receive_event_packet;
    
    public WurstplusEventHandler() {
        this.next_index = 0;
        this.receive_event_packet = new Listener<WurstplusEventPacket.ReceivePacket>(event -> {
            if (event.get_packet() instanceof SPacketTimeUpdate) {
                WurstplusEventHandler.INSTANCE.update_time();
            }
            return;
        }, (Predicate<WurstplusEventPacket.ReceivePacket>[])new Predicate[0]);
        WurstplusEventBus.ZERO_ALPINE_EVENT_BUS.subscribe(this);
        this.reset_tick();
    }
    
    public float get_tick_rate() {
        float num_ticks = 0.0f;
        float sum_ticks = 0.0f;
        for (final float ticks : WurstplusEventHandler.tick_rates) {
            if (ticks > 0.0f) {
                sum_ticks += ticks;
                ++num_ticks;
            }
        }
        return MathHelper.clamp(sum_ticks / num_ticks, 0.0f, 20.0f);
    }
    
    public void reset_tick() {
        this.next_index = 0;
        this.last_update_tick = -1L;
        Arrays.fill(WurstplusEventHandler.tick_rates, 0.0f);
    }
    
    public void update_time() {
        if (this.last_update_tick != -1L) {
            final float time = (System.currentTimeMillis() - this.last_update_tick) / 1000.0f;
            WurstplusEventHandler.tick_rates[this.next_index % WurstplusEventHandler.tick_rates.length] = MathHelper.clamp(20.0f / time, 0.0f, 20.0f);
            ++this.next_index;
        }
        this.last_update_tick = System.currentTimeMillis();
    }
    
    static {
        tick_rates = new float[20];
    }
}
