package me.travis.wurstplus.external;

import me.zero.alpine.fork.bus.*;

public class WurstplusEventBus
{
    public static final EventBus ZERO_ALPINE_EVENT_BUS;
    
    static {
        ZERO_ALPINE_EVENT_BUS = new EventManager();
    }
}
