package me.zero.alpine.fork.event;

public enum EventState
{
    PRE, 
    POST;
}
