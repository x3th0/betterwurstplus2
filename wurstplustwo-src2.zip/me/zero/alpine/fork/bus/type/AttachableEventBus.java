package me.zero.alpine.fork.bus.type;

import me.zero.alpine.fork.bus.*;

public interface AttachableEventBus extends EventBus
{
    void attach(final EventBus p0);
    
    void detach(final EventBus p0);
}
