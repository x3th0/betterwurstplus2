package me.zero.alpine.fork.listener;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface EventHandler {
}
