package org.spongepowered.asm.mixin.transformer;

class MixinPreProcessorAccessor extends MixinPreProcessorInterface
{
    public MixinPreProcessorAccessor(final MixinInfo mixin, final MixinInfo.MixinClassNode classNode) {
        super(mixin, classNode);
    }
}
