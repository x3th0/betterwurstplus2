package org.spongepowered.asm.mixin.transformer.ext;

import java.io.*;

public interface IDecompiler
{
    void decompile(final File p0);
}
