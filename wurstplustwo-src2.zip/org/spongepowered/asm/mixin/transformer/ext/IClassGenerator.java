package org.spongepowered.asm.mixin.transformer.ext;

public interface IClassGenerator
{
    byte[] generate(final String p0);
}
