package org.json.simple;

import java.io.*;

public interface JSONStreamAware
{
    void writeJSONString(final Writer p0) throws IOException;
}
